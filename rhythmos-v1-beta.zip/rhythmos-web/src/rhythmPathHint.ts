// rhythmPathHint.ts

export function getStageHint(stage: string): string {
    const map: Record<string, string> = {
      initial: "You're just beginning. Consistency is more important than speed.",
      middle: "You're in the rhythm now. Keep moving — you're building real momentum.",
      final: "You're near the finish line. One final push to complete this goal.",
      complete: "This journey is complete. You’ve done something worth being proud of."
    };
  
    return map[stage] || '';
  }