// outputRouter.ts (updated with explanation source)

import { RhythmSignatureMap } from './rhythmSignature';
import { generateCRE } from './creGenerator';
import { getCREStylePreference } from './creStylePreference';
import { getBestVariantByTask, detectCREOverrideSource } from './creStrategySort';

export function generateCREOutput({
  trend,
  stage,
  taskType,
  signature
}: {
  trend: string;
  stage: string;
  taskType: 'minimal' | 'light' | 'normal' | 'challenge';
  signature: RhythmSignatureMap;
}): { cre: string; tone: string; variant: string; source: 'preset' | 'signature' } {
  const override = localStorage.getItem('creStyleOverride');
  const tone = override && override !== 'skip' ? override : getCREStylePreference(signature).tone;
  const variant = getBestVariantByTask()[taskType] || 'base';
  const source = detectCREOverrideSource();

  const cre = generateCRE({ trend, stage, taskType, signature, override: tone, variant });
  return { cre, tone, variant, source };
}



