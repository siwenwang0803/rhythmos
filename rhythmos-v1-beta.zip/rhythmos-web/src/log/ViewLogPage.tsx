import { getRecentRhythmLogs, getRhythmTrend } from '../rhythmLog';

const recentLog = getRecentRhythmLogs(5);
const currentTrend = getRhythmTrend(recentLog);

import React, { useEffect, useState } from 'react';

interface FeedbackLogEntry {
  inputText: string;
  feedbackType: string;
  score: number;
  rhythmState: string;
  creStrategyMessage: string;
  timestamp: string;
}

const ViewLogPage: React.FC = () => {
  const [log, setLog] = useState<FeedbackLogEntry[]>([]);

  useEffect(() => {
    const raw = localStorage.getItem('rhythmFeedbackLog');
    if (raw) {
      const parsed = JSON.parse(raw);
      parsed.sort((a: FeedbackLogEntry, b: FeedbackLogEntry) =>
        new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
      );
      setLog(parsed);
    }
  }, []);

  const handleDownload = () => {
    const blob = new Blob([JSON.stringify(log, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'rhythm_log.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleClear = () => {
    localStorage.removeItem('rhythmFeedbackLog');
    localStorage.removeItem('rhythmScore');
    localStorage.removeItem('recentActions');
    setLog([]);
  };

  const handleClearEntryIntent = () => {
    localStorage.removeItem('entryIntentLog');
    window.location.reload();
  };

  return (
    <div className="min-h-screen px-6 py-10 max-w-3xl mx-auto text-left">
      <h1 className="text-2xl font-bold mb-6">📘 Rhythm Log</h1>
      <p className="text-sm text-gray-600 mb-4">
  🌡️ Current Rhythm Trend: <strong>{currentTrend}</strong>
</p>


      {log.length === 0 ? (
        <p className="text-gray-500 italic">No rhythm feedback log found.</p>
      ) : (
        <div className="space-y-4">
          {log.map((entry, index) => (
            <div key={index} className="p-4 bg-white border rounded-xl shadow-sm">
              <p className="text-sm text-gray-500 mb-1">{new Date(entry.timestamp).toLocaleString()}</p>
              <p><strong>Emotion:</strong> {entry.inputText}</p>
              <p><strong>Feedback:</strong> {entry.feedbackType}</p>
              <p><strong>Score:</strong> {entry.score} ({entry.rhythmState})</p>
              <p><strong>CRE Advice:</strong> {entry.creStrategyMessage}</p>
            </div>
          ))}

          <div className="mt-6 flex flex-col sm:flex-row gap-4">
            <button
              onClick={handleDownload}
              className="px-4 py-2 bg-blue-500 text-white rounded-xl text-sm"
            >
              ⬇️ Download Log
            </button>

            <button
              onClick={handleClear}
              className="px-4 py-2 bg-red-100 text-red-600 rounded-xl text-sm"
            >
              🗑️ Clear Rhythm Feedback Log
            </button>

            <button
              onClick={handleClearEntryIntent}
              className="px-4 py-2 bg-red-100 text-red-600 rounded-xl text-sm"
            >
              🧹 Clear Entry Intent Log
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ViewLogPage;
