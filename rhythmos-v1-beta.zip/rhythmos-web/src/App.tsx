// App.tsx (with CREPreviewPanel route)

import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import HomePage from './components/HomePage';
import EntryIntentPage from './components/EntryIntentPage';
import UserInputPage from './components/UserInputPage';
import ExportLogPage from './components/ExportLogPage';
import TryRhythmPage from './try/TryRhythmPage';
import ViewLogPage from './log/ViewLogPage';
import GoalDetailPage from './pages/GoalDetailPage';
import GoalOverviewPage from './pages/GoalOverviewPage';
import CREStyleProfilePage from './pages/CREStyleProfilePage';
import CREPreviewPanel from './components/CREPreviewPanel';
import CREBatchGenerator from './pages/CREBatchGenerator';
import GoalPathView from './pages/GoalPathView';
import GoalInputPage from './pages/GoalInputPage'; // ✅ 根据实际路径确认
import GrowthMapPage from './pages/GrowthMapPage';
import Login from './pages/Login'
import OnboardingFlow from './pages/OnboardingFlow'
import LandingPage from './pages/LandingPage'
import LaunchPrepPage from './pages/LaunchPrepPage'
import BetaSignup from './pages/BetaSignup'
import SettingsPage from './pages/SettingsPage'
import SystemExportPage from './pages/SystemExportPage'
import SystemSummaryPage from './pages/SystemSummaryPage'
import TestGuide from './pages/TestGuide'
import RhythmCheckinPage from './pages/RhythmCheckinPage'
import ExperienceMapPage from './pages/ExperienceMapPage'
import PersonaReportPage from './pages/PersonaReportPage'
import RhythmJournalPage from './pages/RhythmJournalPage'
import JournalLogPage from './pages/JournalLogPage'
import PersonaArchivePage from './pages/PersonaArchivePage'
import CRELibraryPage from './pages/CRELibraryPage'
import CREStudioPage from './pages/CREStudioPage'
import CREExportPage from './pages/CREExportPage'
import CREImportPage from './pages/CREImportPage'
import CRETrainingReplayPage from './pages/CRETrainingReplayPage'
import JourneyPage from './pages/JourneyPage'
import SharePage from './pages/SharePage'

<Route path="/cre-studio" element={<CREStudioPage />} />


function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/intent" element={<EntryIntentPage />} />
        <Route path="/input" element={<UserInputPage />} />
        <Route path="/log" element={<ExportLogPage />} />
        <Route path="/view-log" element={<ViewLogPage />} />
        <Route path="/try" element={<TryRhythmPage />} />
        <Route path="/goals" element={<GoalOverviewPage />} />
        <Route path="/goal-input" element={<GoalInputPage />} />
        <Route path="/goals/:id" element={<GoalDetailPage />} />
        <Route path="/profile" element={<CREStyleProfilePage />} />
        <Route path="/cre-preview" element={<CREPreviewPanel />} />
        <Route path="/cre-batch" element={<CREBatchGenerator />} />
        <Route path="/growth-map" element={<GrowthMapPage />} />
        <Route path="/goal-path" element={<GoalPathView goal="prepare for mock interview" />} />
        <Route path="/login" element={<Login />} />
        <Route path="/onboarding" element={<OnboardingFlow />} />
        <Route path="/" element={<LandingPage />} />
        <Route path="/launch" element={<LaunchPrepPage />} />
        <Route path="/beta" element={<BetaSignup />} />
        <Route path="/settings" element={<SettingsPage />} />
        <Route path="/export" element={<SystemExportPage />} />
        <Route path="/summary" element={<SystemSummaryPage />} />
        <Route path="/test" element={<TestGuide />} />
        <Route path="/rhythm" element={<RhythmCheckinPage />} />
        <Route path="/map" element={<ExperienceMapPage />} />
        <Route path="/persona" element={<PersonaReportPage />} />
        <Route path="/journal" element={<RhythmJournalPage />} />
        <Route path="/journal-log" element={<JournalLogPage />} />
        <Route path="/archive" element={<PersonaArchivePage />} />
        <Route path="/cre-library" element={<CRELibraryPage />} />
        <Route path="/cre-studio" element={<CREStudioPage />} />
        <Route path="/cre-export" element={<CREExportPage />} />
        <Route path="/cre-import" element={<CREImportPage />} />
        <Route path="/cre-replay" element={<CRETrainingReplayPage />} />
        <Route path="/journey" element={<JourneyPage />} />
        <Route path="/share" element={<SharePage />} />


      </Routes>
    </Router>
  );
}

export default App;

