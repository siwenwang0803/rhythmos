// creRatingExport.ts

export function generateCRETrainingData() {
    const sampleRaw = localStorage.getItem('creSampleRatings');
    const helpRaw = localStorage.getItem('creHelpfulnessRatings');
  
    const samples = sampleRaw ? JSON.parse(sampleRaw) : [];
    const feedback = helpRaw ? JSON.parse(helpRaw) : [];
  
    const joined = samples.map((s: any) => {
      const f = feedback.find((h: any) => h.cre === s.cre && h.taskType === s.taskType);
      return {
        ...s,
        helpful: f ? f.helpful : 'unknown'
      };
    });
  
    const avgScore = joined.length
      ? parseFloat((joined.reduce((sum, j) => sum + j.score, 0) / joined.length).toFixed(2))
      : 0;
  
    const mostHelpful = joined
      .filter((j) => j.helpful === 'yes')
      .map((j) => j.tone + '-' + j.variant);
  
    const freqMap: Record<string, number> = {};
    mostHelpful.forEach((key) => {
      if (!freqMap[key]) freqMap[key] = 0;
      freqMap[key]++;
    });
  
    const bestVariant = Object.entries(freqMap).sort((a, b) => b[1] - a[1])[0]?.[0] || 'unknown';
  
    return {
      summary: {
        bestVariant,
        averageScore: avgScore,
        totalSamples: joined.length
      },
      samples: joined
    };
  }
  
  export function downloadCRETrainingData() {
    const data = generateCRETrainingData();
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'cre_training_data.json';
    a.click();
    URL.revokeObjectURL(url);
  }
  