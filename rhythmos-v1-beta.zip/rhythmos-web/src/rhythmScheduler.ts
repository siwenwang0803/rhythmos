// rhythmScheduler.ts

export function getNextTaskMode(
    trend: string,
    stage: string,
    progress: number
  ): 'goal' | 'micro' | 'pause' {
    if (progress >= 100) return 'pause';
  
    if (trend === 'collapsed' || trend === 'frozen') {
      return stage === 'initial' ? 'micro' : 'pause';
    }
  
    if (trend === 'wavy') {
      if (stage === 'initial') return 'micro';
      if (progress < 40) return 'micro';
      return 'goal';
    }
  
    if (trend === 'stable') {
      return 'goal';
    }
  
    if (trend === 'rising') {
      return stage === 'final' ? 'goal' : 'goal';
    }
  
    return 'micro';
  }
  