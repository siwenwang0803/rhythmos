// signatureManualUpdate.ts

import { RhythmSignatureMap } from './rhythmSignature';

export function updateManualSignature(
  trend: string,
  difficulty: 'minimal' | 'light' | 'normal' | 'challenge',
  score: number
) {
  const raw = localStorage.getItem('rhythmSignature');
  const data: RhythmSignatureMap = raw ? JSON.parse(raw) : {};

  const persona = 'Manual';

  if (!data[trend]) data[trend] = {};
  if (!data[trend][persona]) {
    data[trend][persona] = {
      total: 0,
      complete: 0,
      tried: 0,
      skipped: 0,
      avgScore: 0,
      scoreSum: 0,
    };
  }

  const entry = data[trend][persona];
  entry.total++;
  entry.complete++; // manual = always a completion
  entry.scoreSum += score;
  entry.avgScore = parseFloat((entry.scoreSum / entry.total).toFixed(2));

  localStorage.setItem('rhythmSignature', JSON.stringify(data));
}
