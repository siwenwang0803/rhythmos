// creGenerator.ts (with template variants)

import { getBestVariantByTask } from './creStrategySort';
import { RhythmSignatureMap } from './rhythmSignature';
import { getCREStylePreference } from './creStylePreference';

export function generateCRE({
  trend,
  stage,
  taskType,
  signature,
  override,
  variant
}: {
  trend: string;
  stage: string;
  taskType: 'minimal' | 'light' | 'normal' | 'challenge';
  signature: RhythmSignatureMap;
  override?: string;
  variant?: 'base' | 'metaphorical' | 'concise' | 'expansive';
}): string {
  const tone = override || getCREStylePreference(signature).tone;
  const bestVariants = getBestVariantByTask();
  const variantUsed = variant || bestVariants[taskType] || 'base';


  const templates: Record<string, Record<string, Record<string, Record<string, string>>>> = {
    gentle: {
      initial: {
        minimal: {
          base: 'You’re allowed to begin softly. One breath is enough.',
          metaphorical: 'Like the first ripple in a still pond, let this moment begin.',
          concise: 'Breathe. Begin.',
          expansive: 'Even a single moment of pause is enough to call your rhythm back into motion.'
        },
        light: {
          base: 'A small start is still a start. I’m with you.',
          metaphorical: 'The smallest song begins with one note.',
          concise: 'Start small. Stay kind.',
          expansive: 'This beginning doesn’t need force. Just presence, and a little willingness.'
        },
        normal: {
          base: 'Even a simple rhythm can carry momentum.',
          metaphorical: 'You’re not building a wall, just laying one brick.',
          concise: 'Steady. Start now.',
          expansive: 'Rhythm doesn’t begin when you’re ready. It begins when you begin.'
        },
        challenge: {
          base: 'Let’s not push. Let’s feel into it together.',
          metaphorical: 'Even the strongest waves rise gently first.',
          concise: 'Don’t force. Flow.',
          expansive: 'You’re not being asked to conquer this—only to meet it from where you are.'
        }
      }
      // middle and final variants omitted for brevity (add similarly)
    },
    motivated: {
      initial: {
        minimal: {
          base: 'Let’s get started—small but steady!',
          metaphorical: 'Plant the seed, and trust it will rise.',
          concise: 'Begin now.',
          expansive: 'This first action, no matter how small, begins the chain of momentum.'
        },
        light: {
          base: 'Start light. Let it build.',
          metaphorical: 'You’re lighting the fuse. Let’s go.',
          concise: 'Light, then go.',
          expansive: 'Every big rhythm starts with one confident beat. This is yours.'
        },
        normal: {
          base: 'You’re ready. Let’s begin.',
          metaphorical: 'You’re standing on the launchpad. Hit ignition.',
          concise: 'Ready. Go.',
          expansive: 'Let this first motion carry your full potential forward.'
        },
        challenge: {
          base: 'You’ve got energy—let’s ride the wave!',
          metaphorical: 'The mountain meets you. Start your climb.',
          concise: 'Climb now.',
          expansive: 'You’re not here to hesitate. You’re here to rise.'
        }
      }
    },
    visionary: {
      initial: {
        minimal: {
          base: 'Even this breath is part of your future.',
          metaphorical: 'The stars are made from sparks. Begin with yours.',
          concise: 'Inhale legacy.',
          expansive: 'Every quiet beginning rewrites the path of the cosmos—this one included.'
        },
        light: {
          base: 'Every beginning echoes beyond today.',
          metaphorical: 'This note begins a symphony no one’s heard yet.',
          concise: 'Echo forward.',
          expansive: 'What starts here may change what comes after. Begin it with presence.'
        },
        normal: {
          base: 'This step is not small—it’s necessary.',
          metaphorical: 'Lay the first stone in your cathedral.',
          concise: 'Necessary. Now.',
          expansive: 'You weren’t born to repeat. This is your divergence point.'
        },
        challenge: {
          base: 'You’re not here to repeat. You’re here to reshape.',
          metaphorical: 'You are the architect of what hasn’t existed yet.',
          concise: 'Disrupt. Begin.',
          expansive: 'This is not resistance. It’s recalibration. Lead it.'
        }
      }
    },
    directive: {
      initial: {
        minimal: {
          base: 'Start now. One breath, then move.',
          metaphorical: 'Flip the switch. Begin.',
          concise: 'Now.',
          expansive: 'No waiting. No planning. Just take the breath, and move your hand.'
        },
        light: {
          base: 'Write one line. That’s it.',
          metaphorical: 'Tip the first domino.',
          concise: 'Line one. Go.',
          expansive: 'This isn’t about mastery. It’s about action. Begin with one line.'
        },
        normal: {
          base: 'Open the tab. Begin the task.',
          metaphorical: 'Turn the key in the ignition.',
          concise: 'Open. Begin.',
          expansive: 'No more delay. Open the door to execution—step through now.'
        },
        challenge: {
          base: '10 minutes. Start the hardest part first.',
          metaphorical: 'Face the dragon. First strike.',
          concise: 'Strike now.',
          expansive: 'Put your full force into the first 10 minutes. That’s how legends begin.'
        }
      }
    }
  };

  return (
    templates[tone]?.[stage]?.[taskType]?.[variantUsed] ||
    templates[tone]?.[stage]?.[taskType]?.base ||
    'Let’s find a rhythm that works for you.'
  );
}
