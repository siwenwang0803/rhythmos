// rhythmStrategy.ts (updated with preferred persona logic)

import { getPreferredPersona } from './personaMatcher';
import { getRhythmSignature } from './rhythmSignature';

export interface RhythmStrategy {
  persona: string;
  tone: 'soft' | 'light' | 'neutral' | 'deep';
  taskType: 'minimal' | 'light' | 'normal' | 'challenge';
  suggestion: string;
}

export function getStrategyFromTrend(trend: string): RhythmStrategy {
  const signature = getRhythmSignature();
  const preferred = getPreferredPersona(trend, signature);

  switch (trend) {
    case 'collapsed':
    case 'frozen':
      return {
        persona: preferred || 'Aurelia',
        tone: 'soft',
        taskType: 'minimal',
        suggestion: "Let’s take one breath together."
      };
    case 'wavy':
      return {
        persona: preferred || 'Rhea',
        tone: 'soft',
        taskType: 'light',
        suggestion: "Let’s try something small, no pressure."
      };
    case 'stable':
      return {
        persona: preferred || 'Lucis',
        tone: 'light',
        taskType: 'normal',
        suggestion: "Keep the rhythm steady. I’m here."
      };
    case 'rising':
      return {
        persona: preferred || 'Caelum',
        tone: 'deep',
        taskType: 'challenge',
        suggestion: "Let’s ride this wave. You’re ready for more."
      };
    default:
      return {
        persona: 'Lucis',
        tone: 'neutral',
        taskType: 'light',
        suggestion: "Let’s start from where we are."
      };
  }
}

export function getTaskByType(taskType: string): string {
  switch (taskType) {
    case 'minimal':
      return "Take one deep breath.";
    case 'light':
      return "Write one word that feels real.";
    case 'normal':
      return "Write one sentence about how you feel.";
    case 'challenge':
      return "Set a 10-minute timer and start your core task.";
    default:
      return "Just sit with me for a moment.";
  }
}
  