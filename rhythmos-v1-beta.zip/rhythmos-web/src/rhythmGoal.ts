export interface RhythmGoal {
    id: string;
    title: string;
    createdAt: string;
    status: 'active' | 'completed' | 'archived';
    notes?: string;
  }
  
  export function saveRhythmGoal(goal: Omit<RhythmGoal, 'id' | 'createdAt'>) {
    const raw = localStorage.getItem('rhythmGoals');
    const goals: RhythmGoal[] = raw ? JSON.parse(raw) : [];
  
    const newGoal: RhythmGoal = {
      ...goal,
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString(),
    };
  
    goals.push(newGoal);
    localStorage.setItem('rhythmGoals', JSON.stringify(goals));
  }
  
  export function getRhythmGoals(): RhythmGoal[] {
    const raw = localStorage.getItem('rhythmGoals');
    return raw ? JSON.parse(raw) : [];
  }
  
  export function updateGoalStatus(id: string, status: RhythmGoal['status']) {
    const raw = localStorage.getItem('rhythmGoals');
    if (!raw) return;
  
    const goals: RhythmGoal[] = JSON.parse(raw);
    const index = goals.findIndex(g => g.id === id);
    if (index !== -1) {
      goals[index].status = status;
      localStorage.setItem('rhythmGoals', JSON.stringify(goals));
    }
  }
  
  export function clearAllGoals() {
    localStorage.removeItem('rhythmGoals');
  }