// creStylePreference.ts

import { RhythmSignatureMap } from './rhythmSignature';

export function getCREStylePreference(signature: RhythmSignatureMap): {
  prefersLong: boolean;
  prefersMetaphor: boolean;
  tone: 'gentle' | 'directive' | 'motivated' | 'visionary';
} {
  let total = 0;
  let avg = 0;
  let dominantPersona = 'Lucis';
  const personaScore: Record<string, number> = {};

  for (const trend in signature) {
    for (const persona in signature[trend]) {
      const entry = signature[trend][persona];
      total += entry.total;
      avg += entry.avgScore * entry.total;
      if (!personaScore[persona]) personaScore[persona] = 0;
      personaScore[persona] += entry.avgScore * entry.total;
    }
  }

  avg = total > 0 ? avg / total : 0;

  const sorted = Object.entries(personaScore).sort((a, b) => b[1] - a[1]);
  if (sorted.length > 0) dominantPersona = sorted[0][0];

  const prefersLong = avg > 3.2;
  const prefersMetaphor = dominantPersona === 'Caelum' || dominantPersona === 'Aurelia';

  let tone: 'gentle' | 'directive' | 'motivated' | 'visionary' = 'gentle';
  if (avg >= 4.2) tone = 'visionary';
  else if (avg >= 3.5) tone = 'motivated';
  else if (avg >= 2.5) tone = 'directive';

  return {
    prefersLong,
    prefersMetaphor,
    tone,
  };
}
