// creStyleUsage.ts (with migration suggestion)

import { RhythmSignatureMap } from './rhythmSignature';
import { getCREStylePreference } from './creStylePreference';

export function getCREStyleUsage(signature: RhythmSignatureMap): {
  toneCounts: Record<string, number>;
  mostUsed: string;
  mostEffective: string;
} {
  const tones = ['gentle', 'directive', 'motivated', 'visionary'];
  const toneCounts: Record<string, number> = {
    gentle: 0,
    directive: 0,
    motivated: 0,
    visionary: 0,
  };

  const avgMap: Record<string, number[]> = {
    gentle: [],
    directive: [],
    motivated: [],
    visionary: [],
  };

  for (const trend in signature) {
    for (const persona in signature[trend]) {
      const entry = signature[trend][persona];
      const pref = getCREStylePreference({ [trend]: { [persona]: entry } });
      toneCounts[pref.tone]++;
      avgMap[pref.tone].push(entry.avgScore);
    }
  }

  const mostUsed = tones.sort((a, b) => toneCounts[b] - toneCounts[a])[0];

  const mostEffective = tones
    .map((tone) => ({
      tone,
      avg:
        avgMap[tone].length > 0
          ? avgMap[tone].reduce((sum, x) => sum + x, 0) / avgMap[tone].length
          : 0,
    }))
    .sort((a, b) => b.avg - a.avg)[0].tone;

  return {
    toneCounts,
    mostUsed,
    mostEffective,
  };
}

export function getStyleMigrationTrend(
  signature: RhythmSignatureMap
): {
  current: string;
  emerging?: string;
  shouldSwitch: boolean;
  confidence: number;
} {
  const tones = ['gentle', 'directive', 'motivated', 'visionary'];
  const recentImpact: Record<string, number> = {
    gentle: 0,
    directive: 0,
    motivated: 0,
    visionary: 0,
  };

  for (const trend in signature) {
    for (const persona in signature[trend]) {
      const entry = signature[trend][persona];
      const pref = getCREStylePreference({ [trend]: { [persona]: entry } });
      recentImpact[pref.tone] += entry.avgScore * entry.total;
    }
  }

  const sorted = Object.entries(recentImpact).sort((a, b) => b[1] - a[1]);
  const [current, emerging] = sorted.map(([tone]) => tone);
  const shouldSwitch = sorted.length > 1 && sorted[0][1] - sorted[1][1] < 4;

  const confidence = sorted.length > 1
    ? parseFloat((100 * (sorted[1][1] / (sorted[0][1] + 0.01))).toFixed(2))
    : 0;

  return {
    current,
    emerging: sorted[1]?.[0],
    shouldSwitch,
    confidence,
  };
}
export function getCREStyleUsageDistribution() {
    const raw = localStorage.getItem('creSampleRatings');
    const helpRaw = localStorage.getItem('creHelpfulnessRatings');
  
    const ratings = raw ? JSON.parse(raw) : [];
    const feedback = helpRaw ? JSON.parse(helpRaw) : [];
  
    const toneCount: Record<string, number> = {};
    const variantCount: Record<string, number> = {};
    let overrideCount = 0;
    let signatureCount = 0;
  
    ratings.forEach((r: any) => {
      toneCount[r.tone] = (toneCount[r.tone] || 0) + 1;
      variantCount[r.variant] = (variantCount[r.variant] || 0) + 1;
    });
  
    feedback.forEach((f: any) => {
      if (f.source === 'preset') overrideCount++;
      else signatureCount++;
    });
  
    return {
      toneCount,
      variantCount,
      overrideCount,
      signatureCount
    };
  }


