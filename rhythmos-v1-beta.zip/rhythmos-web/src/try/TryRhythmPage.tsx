import React from 'react';
import { useNavigate } from 'react-router-dom';

const TryRhythmPage: React.FC = () => {
  const navigate = useNavigate();

  const feedbackLog = JSON.parse(localStorage.getItem('rhythmFeedbackLog') || '[]');
  const latestEntry = feedbackLog.length > 0 ? feedbackLog[feedbackLog.length - 1] : null;

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-6 text-center">
      <h1 className="text-3xl font-bold mb-4">👋 Welcome to your first rhythm experience</h1>
      <p className="text-gray-600 text-lg max-w-xl">
        This is a gentle place to begin syncing with your inner rhythm.
        You’ll tell me how you feel, I’ll offer a rhythm suggestion, and we’ll walk through it together.
      </p>

      <button
        onClick={() => navigate('/input')}
        className="mt-8 px-6 py-3 bg-blue-500 text-white rounded-xl text-lg shadow"
      >
        🌱 Start My First Rhythm</button>

      {latestEntry ? (
        <div className="mt-10 p-4 max-w-xl w-full bg-gray-50 border rounded-xl text-left">
          <h2 className="text-lg font-semibold mb-2">🕒 Your Last Rhythm Log</h2>
          <p><strong>Emotion:</strong> {latestEntry.inputText}</p>
          <p><strong>Feedback:</strong> {latestEntry.feedbackType}</p>
          <p><strong>Score:</strong> {latestEntry.score} ({latestEntry.rhythmState})</p>
          <p><strong>CRE Advice:</strong> {latestEntry.creStrategyMessage}</p>
        </div>
      ) : (
        <p className="mt-8 text-sm text-gray-500 italic">
          You haven't started your rhythm journey yet. Let's begin.
        </p>
      )}
    </div>
  );
};

export default TryRhythmPage;
