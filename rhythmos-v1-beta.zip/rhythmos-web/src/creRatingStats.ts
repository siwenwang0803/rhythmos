// creRatingStats.ts

export function getCRERatingStats() {
    const raw = localStorage.getItem('creSampleRatings');
    const ratings = raw ? JSON.parse(raw) : [];
  
    const summary: Record<string, { total: number; sum: number; avg: number }> = {};
  
    ratings.forEach((entry: any) => {
      const key = `${entry.tone}-${entry.variant}-${entry.taskType}`;
      if (!summary[key]) summary[key] = { total: 0, sum: 0, avg: 0 };
      summary[key].total++;
      summary[key].sum += entry.score;
    });
  
    for (const key in summary) {
      const { total, sum } = summary[key];
      summary[key].avg = total > 0 ? parseFloat((sum / total).toFixed(2)) : 0;
    }
  
    return summary;
  }
  // creRatingStats.ts (append below getCRERatingStats)

export function getCREStyleTimeSeries(): { date: string; tone: string; count: number }[] {
    const raw = localStorage.getItem('creSampleRatings')
    const ratings = raw ? JSON.parse(raw) : []
  
    const countMap: Record<string, Record<string, number>> = {}
  
    ratings.forEach((entry: any) => {
      const date = new Date(entry.timestamp).toISOString().split('T')[0]
      const tone = entry.tone || 'unknown'
  
      if (!countMap[date]) countMap[date] = {}
      if (!countMap[date][tone]) countMap[date][tone] = 0
      countMap[date][tone] += 1
    })
  
    const series: { date: string; tone: string; count: number }[] = []
  
    for (const date in countMap) {
      for (const tone in countMap[date]) {
        series.push({ date, tone, count: countMap[date][tone] })
      }
    }
  
    return series
  }
  