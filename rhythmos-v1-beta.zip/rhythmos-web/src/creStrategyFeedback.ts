// creStrategyFeedback.ts (with tip generator + exportable summary)

import { generateCREWeightedSet } from './creWeightedSet';

export function generateCREVariantTips(): string[] {
  const weighted = generateCREWeightedSet();
  const tips: string[] = [];

  for (const taskType in weighted) {
    const top = weighted[taskType][0];
    if (!top) continue;

    const label = `🧩 ${taskType.charAt(0).toUpperCase() + taskType.slice(1)}`;
    tips.push(`${label}: You seem to respond best to '${top.variant}' style (Avg ${top.avg})`);
  }

  return tips;
}

export function exportCREStrategyTips(): void {
  const weighted = generateCREWeightedSet();
  const summary = Object.entries(weighted).map(([taskType, list]) => {
    const top = list[0];
    return {
      taskType,
      bestVariant: top?.variant || 'unknown',
      avg: top?.avg || 0,
      total: top?.total || 0
    };
  });

  const output = {
    summary,
    generatedAt: new Date().toISOString()
  };

  const blob = new Blob([JSON.stringify(output, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'cre_strategy_tips.json';
  a.click();
  URL.revokeObjectURL(url);
}


