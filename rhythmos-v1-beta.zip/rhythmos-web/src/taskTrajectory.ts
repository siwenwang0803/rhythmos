// taskTrajectory.ts (with task behavior tracker + CRE output update)

import { RhythmSignatureMap } from './rhythmSignature';
import { generateCREOutput } from './outputRouter';

export function getTaskTypeTrajectory(): ('minimal' | 'light' | 'normal' | 'challenge')[] {
  return ['minimal', 'light', 'normal', 'challenge'];
}

export function getNextTaskType(
  current: 'minimal' | 'light' | 'normal' | 'challenge',
  feedback: 'done' | 'tried' | 'skipped'
): 'minimal' | 'light' | 'normal' | 'challenge' {
  const levels = getTaskTypeTrajectory();
  const index = levels.indexOf(current);

  if (feedback === 'done') {
    return levels[Math.min(index + 1, levels.length - 1)];
  } else if (feedback === 'tried') {
    return current;
  } else {
    return levels[Math.max(index - 1, 0)];
  }
}

export function getTaskGrowthRecord(): {
  current: 'minimal' | 'light' | 'normal' | 'challenge';
  history: string[];
} {
  const raw = localStorage.getItem('taskGrowthHistory');
  const parsed = raw ? JSON.parse(raw) : { current: 'minimal', history: [] };
  return parsed;
}

export function updateTaskGrowthRecord(
  feedback: 'done' | 'tried' | 'skipped'
): 'minimal' | 'light' | 'normal' | 'challenge' {
  const currentRecord = getTaskGrowthRecord();
  const next = getNextTaskType(currentRecord.current, feedback);
  const updated = {
    current: next,
    history: [...currentRecord.history, `${new Date().toISOString()}: ${currentRecord.current} → ${feedback} → ${next}`]
  };
  localStorage.setItem('taskGrowthHistory', JSON.stringify(updated));
  return next;
}

export function updateCREFromFeedback(
  feedback: 'done' | 'tried' | 'skipped',
  trend: string,
  stage: string,
  signature: RhythmSignatureMap
): {
  nextTaskType: 'minimal' | 'light' | 'normal' | 'challenge';
  cre: string;
} {
  const nextTaskType = updateTaskGrowthRecord(feedback);
  const cre = generateCREOutput({ trend, stage, taskType: nextTaskType, signature });
  return { nextTaskType, cre };
}
