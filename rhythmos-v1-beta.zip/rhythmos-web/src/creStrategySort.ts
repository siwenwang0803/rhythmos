// creStrategySort.ts (updated to support override source explanation)

export function getBestVariantByTask(): Record<string, string> {
    const raw = localStorage.getItem('creSampleRatings');
    const ratings = raw ? JSON.parse(raw) : [];
  
    const scoreMap: Record<string, Record<string, number[]>> = {};
  
    ratings.forEach((entry: any) => {
      const { taskType, variant, score } = entry;
      if (!scoreMap[taskType]) scoreMap[taskType] = {};
      if (!scoreMap[taskType][variant]) scoreMap[taskType][variant] = [];
      scoreMap[taskType][variant].push(score);
    });
  
    const bestVariants: Record<string, string> = {};
  
    for (const taskType in scoreMap) {
      const variants = scoreMap[taskType];
      const avgList = Object.entries(variants)
        .filter(([_, scores]) => scores.length >= 3)
        .map(([v, scores]) => {
          const avg = scores.reduce((sum, s) => sum + s, 0) / scores.length;
          return { variant: v, avg };
        });
      avgList.sort((a, b) => b.avg - a.avg);
      bestVariants[taskType] = avgList[0]?.variant || 'base';
    }
  
    return bestVariants;
  }
  
  export function detectCREOverrideSource(): 'preset' | 'signature' {
    const override = localStorage.getItem('creStyleOverride');
    if (override && override !== 'skip') return 'preset';
    return 'signature';
  }
  // generateCREWeightedSet: returns all variants with avg score + sample size

export function generateCREWeightedSet(): Record<string, { variant: string; avg: number; count: number }[]> {
    const raw = localStorage.getItem('creSampleRatings');
    const ratings = raw ? JSON.parse(raw) : [];
  
    const scoreMap: Record<string, Record<string, number[]>> = {};
  
    ratings.forEach((entry: any) => {
      const { taskType, variant, score } = entry;
      if (!scoreMap[taskType]) scoreMap[taskType] = {};
      if (!scoreMap[taskType][variant]) scoreMap[taskType][variant] = [];
      scoreMap[taskType][variant].push(score);
    });
  
    const weightedSet: Record<string, { variant: string; avg: number; count: number }[]> = {};
  
    for (const taskType in scoreMap) {
      const variants = scoreMap[taskType];
      const scored = Object.entries(variants).map(([variant, scores]) => {
        const avg = scores.reduce((sum, s) => sum + s, 0) / scores.length;
        return { variant, avg, count: scores.length };
      });
      scored.sort((a, b) => b.avg - a.avg);
      weightedSet[taskType] = scored;
    }
  
    return weightedSet;
  }
  
  