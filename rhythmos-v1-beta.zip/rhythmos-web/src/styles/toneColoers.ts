// styles/toneColors.ts

export const toneColors: Record<string, string> = {
    directive: 'bg-blue-500 text-white',
    gentle: 'bg-green-400 text-black',
    motivated: 'bg-orange-400 text-black',
    visionary: 'bg-purple-500 text-white',
    unknown: 'bg-gray-300 text-black'
  }
  
  export const toneBorderColors: Record<string, string> = {
    directive: 'border-blue-500',
    gentle: 'border-green-400',
    motivated: 'border-orange-400',
    visionary: 'border-purple-500',
    unknown: 'border-gray-300'
  }
  