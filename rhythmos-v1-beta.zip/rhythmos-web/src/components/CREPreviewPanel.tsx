// CREPreviewPanel.tsx (with ratings + helpfulness + training data export)

import React, { useState } from 'react';
import { generateCRE } from '../creGenerator';
import { RhythmSignatureMap } from '../rhythmSignature';
import { getTaskTypeTrajectory } from '../taskTrajectory';
import { getCREExplanation } from '../creExplanation';
import CREStyleRatingTable from './CREStyleRatingTable';
import { downloadCRETrainingData } from '../creRatingExport';
import { generateCREOutput } from '../outputRouter';
import CREVariantRankingTable from './CREVariantRankingTable';
import { generateCREVariantTips } from '../creStrategyFeedback';
import { exportCREStrategyTips } from '../creStrategyFeedback';
import CREVariantTrendChart from './CREVariantTrendChart';
import CREUsageBarChart from './CREUsageBarChart';
import CREGrowthPathChart from './CREGrowthPathChart';
import CREFeedbackTrainer from '../components/CREFeedbackTrainer';


const tones = ['gentle', 'directive', 'motivated', 'visionary'] as const;
const variants = ['base', 'metaphorical', 'concise', 'expansive'] as const;
const stages = ['initial', 'middle', 'final'] as const;

const CREPreviewPanel: React.FC = () => {
  const [tone, setTone] = useState('gentle');
  const [variant, setVariant] = useState<'base' | 'metaphorical' | 'concise' | 'expansive'>('base');
  const [stage, setStage] = useState<'initial' | 'middle' | 'final'>('initial');
  const [signature] = useState({} as RhythmSignatureMap);
  const variantTips = generateCREVariantTips();

  const handleRate = (cre: string, taskType: string, score: number) => {
    const raw = localStorage.getItem('creSampleRatings');
    const ratings = raw ? JSON.parse(raw) : [];
    ratings.push({ cre, tone, variant, stage, taskType, score, timestamp: new Date().toISOString() });
    localStorage.setItem('creSampleRatings', JSON.stringify(ratings));
    alert(`Rated: ${score} ⭐`);
  };

  const handleHelpfulness = (cre: string, taskType: string, value: 'yes' | 'no' | 'skip') => {
    const raw = localStorage.getItem('creHelpfulnessRatings');
    const ratings = raw ? JSON.parse(raw) : [];
    ratings.push({ cre, tone, variant, stage, taskType, helpful: value, timestamp: new Date().toISOString() });
    localStorage.setItem('creHelpfulnessRatings', JSON.stringify(ratings));
    alert(`Marked as: ${value.toUpperCase()}`);
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h2 className="text-xl font-bold mb-4">🎛 CRE Generator Preview</h2>

      <div className="grid grid-cols-2 gap-4 mb-4">
        <div>
          <label className="text-sm font-medium">Tone</label>
          <select value={tone} onChange={(e) => setTone(e.target.value)} className="w-full border rounded p-2">
            {tones.map((t) => (
              <option key={t} value={t}>{t}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="text-sm font-medium">Variant</label>
          <select value={variant} onChange={(e) => setVariant(e.target.value as any)} className="w-full border rounded p-2">
            {variants.map((v) => (
              <option key={v} value={v}>{v}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="text-sm font-medium">Stage</label>
          <select value={stage} onChange={(e) => setStage(e.target.value as any)} className="w-full border rounded p-2">
            {stages.map((s) => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="space-y-4">
        {getTaskTypeTrajectory().map((taskType) => {
          const { cre, tone: resolvedTone, variant: resolvedVariant, source } =
          generateCREOutput({ trend: 'stable', stage, taskType, signature });        
          const explain = getCREExplanation({
            tone: resolvedTone,
            variant: resolvedVariant,
            stage,
            taskType,
            override: resolvedTone,
            source
          });
          

          return (
            <div key={taskType} className="p-4 bg-white border rounded-xl">
              <p className="text-sm text-gray-400">{tone} / {stage} / {taskType} / {variant}</p>
              <p className="text-base font-medium text-blue-800 mt-1">{cre}</p>
              <h4 className="text-sm font-semibold text-gray-700 mt-4">📣 Why this CRE?</h4>
              <p className="text-xs text-gray-500 italic mt-1">{explain}</p>
              <div className="mt-2 space-x-2">
                {[1, 2, 3, 4, 5].map((score) => (
                  <button
                    key={score}
                    onClick={() => handleRate(cre, taskType, score)}
                    className="px-2 py-1 text-sm bg-gray-100 rounded hover:bg-gray-200"
                  >
                    ⭐ {score}
                  </button>
                ))}
              </div>
              <div className="mt-2 space-x-2">
                {['yes', 'no', 'skip'].map((v) => (
                  <button
                    key={v}
                    onClick={() => handleHelpfulness(cre, taskType, v as any)}
                    className="px-2 py-1 text-sm bg-yellow-100 rounded hover:bg-yellow-200"
                  >
                    {v === 'yes' ? '👍 Helpful' : v === 'no' ? '👎 Not helpful' : '🕒 Skip'}
                  </button>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-4 space-y-2 border-t pt-4">
        <button
          onClick={() => {
            const raw = localStorage.getItem('creSampleRatings');
            const ratings = raw ? JSON.parse(raw) : [];
            const blob = new Blob([JSON.stringify(ratings, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'cre_sample_ratings.json';
            a.click();
            URL.revokeObjectURL(url);
          }}
          className="px-4 py-2 text-sm bg-blue-500 text-white rounded"
        >
          ⬇️ Export Ratings (JSON)
        </button>

        <button
          onClick={() => {
            const raw = localStorage.getItem('creHelpfulnessRatings');
            const ratings = raw ? JSON.parse(raw) : [];
            const blob = new Blob([JSON.stringify(ratings, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'cre_helpfulness_ratings.json';
            a.click();
            URL.revokeObjectURL(url);
          }}
          className="px-4 py-2 text-sm bg-yellow-600 text-white rounded"
        >
          ⬇️ Export Helpfulness (JSON)
        </button>

        <button
          onClick={downloadCRETrainingData}
          className="px-4 py-2 text-sm bg-green-700 text-white rounded"
        >
          ⬇️ Export Training Data (JSON)
        </button>
      </div>
      <hr className="my-6 border-gray-300" />
      <div className="mt-4 space-y-1">
  <h3 className="text-sm font-semibold text-gray-700 mb-1">📈 CRE Strategy Insights</h3>
  {variantTips.map((tip, idx) => (
    <p key={idx} className="text-xs text-gray-600 italic">👉 {tip}</p>
  ))}
</div>
<div className="mt-6">
  <button
    onClick={exportCREStrategyTips}
    className="px-4 py-2 text-sm bg-indigo-700 text-white rounded"
  >
    ⬇️ Export Strategy Tips (JSON)
  </button>
</div>

<div className="mt-8 p-4 border rounded-xl bg-gray-50 shadow-sm">
  <h3 className="text-md font-semibold mb-2 text-gray-700">🧪 Manual Feedback Tuning</h3>
  <p className="text-xs text-gray-500 mb-2">
    Use this panel to simulate strategy feedback and reinforce variant training manually.
  </p>
  <CREVariantRankingTable />
  <CREFeedbackTrainer />
</div>

      <CREVariantTrendChart/>
      <CREStyleRatingTable />
      <CREUsageBarChart />
      <CREGrowthPathChart />
      
    </div>
  );
};

export default CREPreviewPanel;