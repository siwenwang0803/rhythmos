// components/CREStrategySummaryMap.tsx

import React from 'react'

interface StrategyEntry {
  group: string
  topVariant: string
  avg: number
  total: number
}

interface CREStrategySummaryMapProps {
  data: StrategyEntry[]
}

const CREStrategySummaryMap: React.FC<CREStrategySummaryMapProps> = ({ data }) => {
  return (
    <div className="space-y-4">
      {data.map((entry, i) => (
        <div key={i} className="p-4 border rounded-xl bg-white shadow-sm space-y-1">
          <p className="text-sm text-gray-700 font-medium">
            <span className="text-blue-600">{entry.group}</span>
          </p>
          <p className="text-sm italic text-gray-600">“{entry.topVariant}”</p>
          <p className="text-xs text-gray-500">
            Avg score: <strong>{entry.avg}</strong> · Total ratings: <strong>{entry.total}</strong>
          </p>
        </div>
      ))}
    </div>
  )
}

export default CREStrategySummaryMap
