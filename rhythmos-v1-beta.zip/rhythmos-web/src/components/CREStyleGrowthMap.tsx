// components/CREStyleGrowthMap.tsx

import React from 'react'
import { getCREStyleTimeSeries } from '../creRatingStats'

interface TimePoint {
  date: string
  tone: string
  count: number
}

const COLORS: Record<string, string> = {
  directive: 'bg-blue-500',
  gentle: 'bg-green-500',
  motivated: 'bg-orange-500',
  visionary: 'bg-purple-500',
  unknown: 'bg-gray-400'
}

const CREStyleGrowthMap: React.FC = () => {
  const data = getCREStyleTimeSeries()

  const grouped: Record<string, Record<string, number>> = {}

  data.forEach((entry: TimePoint) => {
    if (!grouped[entry.date]) grouped[entry.date] = {}
    if (!grouped[entry.date][entry.tone]) grouped[entry.date][entry.tone] = 0
    grouped[entry.date][entry.tone] += entry.count
  })

  const rows = Object.entries(grouped).sort(([a], [b]) => a.localeCompare(b))

  return (
    <div className="space-y-4">
      {rows.map(([date, tones]) => (
        <div key={date} className="space-y-1">
          <p className="text-sm font-medium text-gray-700">{date}</p>
          <div className="flex gap-1 h-2">
            {Object.entries(tones).map(([tone, count]) => (
              <div
                key={tone}
                className={`h-4 rounded ${COLORS[tone] || COLORS.unknown}`}
                style={{ width: `${Math.max(count * 20, 40)}px` }}
                title={`${tone}: ${count}`}
              />
            ))}
          </div>
          <p className="text-xs text-gray-500 italic">
            {Object.entries(tones)
              .map(([tone, count]) => `${tone} (${count})`)
              .join(' · ')}
          </p>
        </div>
      ))}
    </div>
  )
}

export default CREStyleGrowthMap
