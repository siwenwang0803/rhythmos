// components/GoalIntentSelector.tsx

import React from 'react'
import RhythmButton from './ui/RhythmButton'

interface GoalIntentSelectorProps {
  onSelect: (template: string) => void
}

const presets = [
  {
    label: '✍️ Focused Writing',
    value: 'Write one paragraph on a topic that matters to me.'
  },
  {
    label: '📚 Study Block',
    value: 'Review one concept for 20 minutes.'
  },
  {
    label: '🧹 Environment Reset',
    value: 'Clean a small area of my workspace.'
  },
  {
    label: '🪞 Emotional Reflection',
    value: 'Journal how I feel about something unresolved.'
  },
  {
    label: '➕ Enter Custom Goal',
    value: ''
  }
]

const GoalIntentSelector: React.FC<GoalIntentSelectorProps> = ({ onSelect }) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
      {presets.map((preset) => (
        <RhythmButton
          key={preset.label}
          variant={preset.value ? 'secondary' : 'muted'}
          onClick={() => onSelect(preset.value)}
        >
          {preset.label}
        </RhythmButton>
      ))}
    </div>
  )
}

export default GoalIntentSelector
