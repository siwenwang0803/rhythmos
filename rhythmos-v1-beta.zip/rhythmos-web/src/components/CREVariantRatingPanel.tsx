// components/CREVariantRatingPanel.tsx

import React, { useState } from 'react'
import { creVariants } from '../cre/creVariantRegistry'

interface Feedback {
  tone: string
  stage: string
  taskType: string
  variant: string
  score: number
  timestamp: number
}

const CREVariantRatingPanel: React.FC = () => {
  const [ratings, setRatings] = useState<Feedback[]>([])

  const handleRate = (tone: string, stage: string, taskType: string, variant: string, score: number) => {
    const feedback: Feedback = {
      tone,
      stage,
      taskType,
      variant,
      score,
      timestamp: Date.now()
    }

    const updated = [...ratings, feedback]
    setRatings(updated)
    const existing = JSON.parse(localStorage.getItem('creSampleRatings') || '[]')
    localStorage.setItem('creSampleRatings', JSON.stringify([...existing, feedback]))
  }

  return (
    <div className="space-y-8">
      {Object.entries(creVariants).map(([tone, toneBlock]) => (
        <div key={tone} className="p-4 border rounded-xl bg-white shadow-sm">
          <h2 className="text-md font-semibold text-gray-700 mb-2">🎨 Tone: {tone}</h2>
          {Object.entries(toneBlock || {}).map(([stage, stageBlock]) => (
            <div key={stage} className="mb-3">
              <p className="text-xs text-gray-500 uppercase font-medium mb-1">Stage: {stage}</p>
              {Object.entries(stageBlock || {}).map(([taskType, variants]) => (
                <div key={taskType} className="mb-4">
                  <p className="text-xs text-gray-500 font-semibold">Task: {taskType}</p>
                  <ul className="list-disc ml-5 text-sm text-gray-700 space-y-1">
                    {variants.map((variant, i) => (
                      <li key={i}>
                        <span className="italic">{variant}</span>
                        <div className="flex gap-1 mt-1">
                          {[1, 2, 3, 4, 5].map((score) => (
                            <button
                              key={score}
                              className="px-2 py-0.5 text-xs bg-gray-100 rounded hover:bg-gray-300"
                              onClick={() => handleRate(tone, stage, taskType, variant, score)}
                            >
                              {score}
                            </button>
                          ))}
                        </div>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          ))}
        </div>
      ))}
    </div>
  )
}

export default CREVariantRatingPanel
