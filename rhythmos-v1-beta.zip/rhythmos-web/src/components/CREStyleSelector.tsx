// CREStyleSelector.tsx

import React, { useState } from 'react';

const tones = ['gentle', 'directive', 'motivated', 'visionary'];
const labels: Record<string, string> = {
  gentle: '🌸 Gentle – soft, calming, nurturing',
  directive: '🧭 Directive – focused, action-oriented',
  motivated: '⚡ Motivated – upbeat, forward-driving',
  visionary: '🌌 Visionary – deep, abstract, future-driven'
};

const CREStyleSelector: React.FC = () => {
  const current = localStorage.getItem('creStyleOverride') || 'none';
  const [selected, setSelected] = useState(current);

  const handleSelect = (tone: string) => {
    setSelected(tone);
    localStorage.setItem('creStyleOverride', tone);
  };

  return (
    <div className="mt-6">
      <h3 className="text-md font-semibold mb-2">🎛️ Choose Your Preferred CRE Style</h3>
      <div className="grid grid-cols-1 gap-3">
        {tones.map((tone) => (
          <button
            key={tone}
            onClick={() => handleSelect(tone)}
            className={`text-left px-4 py-2 rounded border ${
              selected === tone ? 'bg-blue-600 text-white' : 'bg-white text-black border-gray-300'
            }`}
          >
            {labels[tone]}
          </button>
        ))}
      </div>
      {selected && (
        <p className="text-sm text-gray-500 mt-2 italic">Selected tone: {selected}</p>
      )}
    </div>
  );
};

export default CREStyleSelector;
