// CREStyleRadarChart.tsx

import React from 'react';
import { Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, ResponsiveContainer, Tooltip } from 'recharts';

interface CREStyleRadarChartProps {
  toneCounts: Record<string, number>;
}

const CREStyleRadarChart: React.FC<CREStyleRadarChartProps> = ({ toneCounts }) => {
  const data = Object.entries(toneCounts).map(([tone, count]) => ({
    style: tone,
    value: count,
  }));

  return (
    <div className="mt-6">
      <h3 className="text-md font-semibold mb-2">🌀 CRE Style Distribution</h3>
      <ResponsiveContainer width="100%" height={300}>
        <RadarChart outerRadius={100} data={data}>
          <PolarGrid />
          <PolarAngleAxis dataKey="style" />
          <PolarRadiusAxis angle={30} domain={[0, Math.max(...data.map((d) => d.value), 1)]} />
          <Tooltip />
          <Radar name="Style Usage" dataKey="value" stroke="#8884d8" fill="#8884d8" fillOpacity={0.6} />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
};

export default CREStyleRadarChart;
