// RhythmPathView.tsx (with manual signature updater)

import React, { useState } from 'react';
import { RhythmSubtask } from '../rhythmSubtasks';
import { markSubtaskComplete } from '../taskUpdater';
import { updateRhythmScore } from '../rhythmScore';
import { updateRhythmSignature } from '../rhythmSignature';
import { evaluateManualTaskChoice } from '../manualChoiceEvaluator';
import { updateManualSignature } from '../signatureManualUpdate';

interface RhythmPathViewProps {
  subtasks: RhythmSubtask[];
  recommendedId?: string;
  trend: string;
  stage: string;
}

const RhythmPathView: React.FC<RhythmPathViewProps> = ({ subtasks, recommendedId, trend, stage }) => {
  const [feedbackMap, setFeedbackMap] = useState<Record<string, string>>({});

  if (!subtasks || subtasks.length === 0) return null;

  const handleClick = (task: RhythmSubtask) => {
    if (task.status === 'completed') return;

    markSubtaskComplete(task.id);

    const { scoreDelta, message } = evaluateManualTaskChoice(task.difficulty, trend, stage);
    updateRhythmScore('complete');
    updateRhythmSignature(trend, 'Manual', 'complete', scoreDelta);
    updateManualSignature(trend, task.difficulty, scoreDelta);

    setFeedbackMap(prev => ({ ...prev, [task.id]: message }));
    setTimeout(() => window.location.reload(), 2000);
  };

  return (
    <div className="mt-6">
      <h3 className="text-md font-semibold mb-2">🛤 Rhythm Path</h3>
      <div className="space-y-3">
        {subtasks.map((task) => {
          const isRecommended = task.id === recommendedId;
          const isCompleted = task.status === 'completed';
          const feedback = feedbackMap[task.id];

          return (
            <div
              key={task.id}
              className={`p-3 border rounded-lg flex flex-col transition duration-300 ease-in-out cursor-pointer ${
                isCompleted
                  ? 'bg-green-100 border-green-400'
                  : isRecommended
                  ? 'bg-blue-50 border-blue-400 animate-pulse'
                  : 'bg-white border-gray-200 hover:bg-gray-50'
              }`}
              onClick={() => handleClick(task)}
            >
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-sm font-medium">{task.title}</p>
                  <p className="text-xs text-gray-400">Difficulty: {task.difficulty}</p>
                </div>
                {isCompleted ? <span className="text-green-600 text-sm">✅</span> : null}
                {isRecommended && !isCompleted ? (
                  <span className="text-blue-500 text-sm font-bold">⭐</span>
                ) : null}
              </div>
              {feedback && (
                <p className="text-xs text-blue-700 italic mt-2">{feedback}</p>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default RhythmPathView;



