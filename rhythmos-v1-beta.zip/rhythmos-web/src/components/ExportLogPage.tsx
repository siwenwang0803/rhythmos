import HomePage from './components/HomePage';
import React, { useEffect, useState } from 'react';
import { getRhythmLog, exportRhythmLog } from '../rhythmLog';

const ExportLogPage: React.FC = () => {
  const [log, setLog] = useState<string | null>(null);

  useEffect(() => {
    const latest = exportRhythmLog();
    setLog(latest);
  }, []);

  const handleDownload = () => {
    if (!log) return;

    const blob = new Blob([log], { type: 'application/json' });
    const url = URL.createObjectURL(blob);

    const a = document.createElement('a');
    a.href = url;
    a.download = 'rhythm_log.json';
    a.click();

    URL.revokeObjectURL(url);
  };

  return (
    <div style={styles.container}>
      <h2>📦 Your Rhythm Log</h2>
      {!log || log === '[]' ? (
        <p>No logs recorded yet.</p>
      ) : (
        <div style={styles.logBox}>
          <pre>{log}</pre>
          <button style={styles.button} onClick={handleDownload}>
            ⬇️ Download Log as JSON
          </button>
        </div>
      )}
    </div>
  );
};

const styles: { [key: string]: React.CSSProperties } = {
  container: {
    maxWidth: 800,
    margin: '60px auto',
    fontFamily: 'sans-serif',
    textAlign: 'center'
  },
  logBox: {
    textAlign: 'left',
    backgroundColor: '#FAFAFA',
    padding: '20px',
    border: '1px solid #CCC',
    borderRadius: '8px',
    marginTop: '20px'
  },
  button: {
    marginTop: '16px',
    padding: '10px 20px',
    backgroundColor: '#4B9EFF',
    color: '#fff',
    border: 'none',
    borderRadius: '6px',
    fontSize: '14px',
    cursor: 'pointer'
  }
};

export default ExportLogPage;

