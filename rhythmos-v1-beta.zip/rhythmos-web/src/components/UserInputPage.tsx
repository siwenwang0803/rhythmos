import { getRecentRhythmLogs, getRhythmTrend } from '../rhythmLog';
import { getStrategyFromTrend, getTaskByType } from '../rhythmStrategy';
import { logFeedbackEntry } from '../rhythmLog';
import { updateRhythmSignature } from '../rhythmSignature';
import React, { useState } from 'react';
import { updateRhythmScore } from '../rhythmScore';

const personaEmojis: { [key: string]: string } = {
  Aurelia: '🌸',
  Rhea: '🤝',
  Lucis: '💬',
  Niveus: '🧊',
  Caelum: '🌌'
};

const toneColors: { [key: string]: string } = {
  soft: '#F0EAF7',
  light: '#E7F3FF',
  neutral: '#EEE',
  deep: '#DDEAF3'
};

const UserInputPage: React.FC = () => {
  const [inputText, setInputText] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [strategyMessage, setStrategyMessage] = useState<string | null>(null);

  const recentLogs = getRecentRhythmLogs(5);
  const trend = getRhythmTrend(recentLogs);
  const strategy = getStrategyFromTrend(trend);

  const handleSubmit = async () => {
    if (!inputText.trim()) return;

    setIsSubmitting(true);
    setFeedback(null);
    setStrategyMessage(null);

    setTimeout(() => {
      setIsSubmitting(false);
    }, 1000);
  };

  const handleFeedback = (type: string) => {
    setFeedback(type);

    const { score, state } = updateRhythmScore(type as "complete" | "tried" | "skipped");
    console.log("🎯 Rhythm Score:", score, "| State:", state);

    let message = '';
    switch (state) {
      case 'rising':
        message = "You're finding your rhythm. Ready to stretch a little further?";
        break;
      case 'stable':
        message = "Let’s keep steady. This pace is working.";
        break;
      case 'wavy':
        message = "We can shift the tempo. No need to rush. You’re still here.";
        break;
      case 'collapsed':
        message = "Let’s soften everything. One small breath is enough for now.";
        break;
    }

    setStrategyMessage(message);

    logFeedbackEntry({
      inputText,
      feedbackType: type,
      score,
      rhythmState: state,
      creStrategyMessage: message,
    });

    updateRhythmSignature(trend, strategy.persona, type as 'complete' | 'tried' | 'skipped', score);
  };

  return (
    <div style={styles.container}>
      <h2>How are you feeling today?</h2>
      <textarea
        placeholder="Type what’s on your mind..."
        value={inputText}
        onChange={(e) => setInputText(e.target.value)}
        rows={5}
        style={styles.textarea}
      />
      <button onClick={handleSubmit} disabled={isSubmitting || !inputText.trim()} style={styles.button}>
        {isSubmitting ? 'Thinking...' : 'Send to RhythmOS'}
      </button>

      {!isSubmitting && (
        <div style={{ ...styles.responseBox, backgroundColor: toneColors[strategy.tone] }}>
          <div style={styles.personaHeader}>
            <span style={styles.emoji}>{personaEmojis[strategy.persona]}</span>
            <span style={styles.personaName}>{strategy.persona}</span>
            <span style={{ ...styles.toneTag, backgroundColor: '#fff' }}>{strategy.tone}</span>
          </div>
          <p style={styles.creText}><strong>CRE:</strong> {strategy.suggestion}</p>
          <p style={styles.task}><strong>Task:</strong> {getTaskByType(strategy.taskType)}</p>

          {!feedback && (
            <div style={styles.feedbackButtons}>
              <p style={{ marginBottom: 8 }}>How did this task go for you?</p>
              <button onClick={() => handleFeedback('complete')} style={styles.feedbackBtnDone}>✅ I did it</button>
              <button onClick={() => handleFeedback('tried')} style={styles.feedbackBtnTry}>🕗 Tried but couldn’t</button>
              <button onClick={() => handleFeedback('skipped')} style={styles.feedbackBtnSkip}>❌ Skipped</button>
            </div>
          )}

          {feedback && (
            <div style={styles.strategyBox}>
              <p><strong>System Strategy Adjustment:</strong></p>
              {strategyMessage && <p>{strategyMessage}</p>}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

const styles: { [key: string]: React.CSSProperties } = {
  container: {
    maxWidth: 640,
    margin: '60px auto',
    textAlign: 'center',
    fontFamily: 'sans-serif',
  },
  textarea: {
    width: '100%',
    padding: '12px',
    fontSize: '16px',
    marginTop: '16px',
    borderRadius: '8px',
    border: '1px solid #ccc',
    resize: 'none',
  },
  button: {
    marginTop: '20px',
    padding: '12px 24px',
    fontSize: '16px',
    borderRadius: '8px',
    border: 'none',
    backgroundColor: '#4B9EFF',
    color: '#fff',
    cursor: 'pointer',
  },
  responseBox: {
    marginTop: '30px',
    padding: '20px',
    borderRadius: '10px',
    textAlign: 'left',
    boxShadow: '0 0 10px rgba(0,0,0,0.05)',
    transition: 'all 0.3s ease-in-out'
  },
  personaHeader: {
    display: 'flex',
    alignItems: 'center',
    gap: '10px',
    marginBottom: '12px'
  },
  emoji: {
    fontSize: '24px'
  },
  personaName: {
    fontSize: '18px',
    fontWeight: 600
  },
  toneTag: {
    fontSize: '12px',
    padding: '4px 10px',
    borderRadius: '16px',
    marginLeft: 'auto'
  },
  creText: {
    fontSize: '16px',
    marginTop: '10px'
  },
  task: {
    fontSize: '15px',
    marginTop: '8px'
  },
  feedbackButtons: {
    marginTop: '16px',
    display: 'flex',
    justifyContent: 'space-between',
    gap: '8px',
    flexWrap: 'wrap'
  },
  feedbackBtnDone: {
    backgroundColor: '#4CAF50',
    color: '#fff',
    padding: '8px 16px',
    borderRadius: '8px',
    border: 'none',
    cursor: 'pointer'
  },
  feedbackBtnTry: {
    backgroundColor: '#F0AD4E',
    color: '#fff',
    padding: '8px 16px',
    borderRadius: '8px',
    border: 'none',
    cursor: 'pointer'
  },
  feedbackBtnSkip: {
    backgroundColor: '#D9534F',
    color: '#fff',
    padding: '8px 16px',
    borderRadius: '8px',
    border: 'none',
    cursor: 'pointer'
  },
  strategyBox: {
    marginTop: '18px',
    fontStyle: 'italic',
    color: '#333'
  }
};

export default UserInputPage;
