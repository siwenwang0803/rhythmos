// CREStyleRatingTable.tsx (with export training data button)

import React from 'react';
import { getCRERatingStats } from '../creRatingStats';
import { downloadCRETrainingData } from '../creRatingExport';

const CREStyleRatingTable: React.FC = () => {
  const stats = getCRERatingStats();
  const entries = Object.entries(stats).sort((a, b) => b[1].avg - a[1].avg);

  return (
    <div className="mt-6">
      <h3 className="text-md font-semibold mb-2">⭐ CRE Style Rating Summary</h3>
      <table className="w-full text-sm text-left border">
        <thead>
          <tr className="bg-gray-100">
            <th className="p-2 border">Tone / Variant / Task</th>
            <th className="p-2 border">Avg</th>
            <th className="p-2 border">Total</th>
          </tr>
        </thead>
        <tbody>
          {entries.map(([key, value]) => (
            <tr key={key}>
              <td className="p-2 border font-mono">{key}</td>
              <td className="p-2 border text-blue-700 font-semibold">{value.avg}</td>
              <td className="p-2 border text-gray-600">{value.total}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="mt-4">
        <button
          onClick={downloadCRETrainingData}
          className="px-4 py-2 text-sm bg-green-700 text-white rounded"
        >
          ⬇️ Export Training Data (JSON)
        </button>
      </div>
    </div>
  );
};

export default CREStyleRatingTable;
