// CREStyleTrendChart.tsx

import React from 'react';
import { LineChart, Line, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface CREStyleTrendChartProps {
  data: {
    timestamp: string;
    tone: string;
    score: number;
  }[];
}

const CREStyleTrendChart: React.FC<CREStyleTrendChartProps> = ({ data }) => {
  if (!data || data.length === 0) return null;

  const formatted = data.map((item) => ({
    time: new Date(item.timestamp).toLocaleDateString(),
    tone: item.tone,
    score: item.score,
  }));

  const merged: { [key: string]: any } = {};
  formatted.forEach(({ time, tone, score }) => {
    if (!merged[time]) merged[time] = { time };
    merged[time][tone] = score;
  });

  const tones = ['gentle', 'directive', 'motivated', 'visionary'];
  const colors = ['#82ca9d', '#8884d8', '#ff7300', '#d84b4b'];

  return (
    <div className="mt-6">
      <h3 className="text-md font-semibold mb-2">📈 CRE Style Evolution Over Time</h3>
      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={Object.values(merged)}>
          <XAxis dataKey="time" tick={{ fontSize: 10 }} />
          <YAxis domain={[0, 5]} />
          <Tooltip />
          <Legend />
          {tones.map((tone, i) => (
            <Line
              key={tone}
              type="monotone"
              dataKey={tone}
              stroke={colors[i]}
              strokeWidth={2}
              dot={{ r: 2 }}
            />
          ))}
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};

export default CREStyleTrendChart;

