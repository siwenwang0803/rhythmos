// CREVariantTrendChart.tsx

import React from 'react';
import { LineChart, Line, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { getVariantScoreTrend } from '../variantScoreTrend';

const CREVariantTrendChart: React.FC = () => {
  const trendMap = getVariantScoreTrend();
  const variantKeys = Object.keys(trendMap);

  const dateMap: Record<string, Record<string, number>> = {};

  variantKeys.forEach((key) => {
    trendMap[key].forEach(({ date, score }) => {
      if (!dateMap[date]) dateMap[date] = {};
      dateMap[date][key] = score;
    });
  });

  const chartData = Object.entries(dateMap)
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([date, values]) => ({ date, ...values }));

  const colors = ['#8884d8', '#82ca9d', '#ffc658', '#d84b4b', '#4b9eff', '#aa66cc', '#ffa600'];

  return (
    <div className="mt-8">
      <h3 className="text-md font-semibold mb-3">📈 CRE Variant Score Trends</h3>
      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={chartData}>
          <XAxis dataKey="date" tick={{ fontSize: 10 }} />
          <YAxis domain={[0, 5]} />
          <Tooltip />
          <Legend />
          {variantKeys.map((key, index) => (
            <Line
              key={key}
              type="monotone"
              dataKey={key}
              stroke={colors[index % colors.length]}
              strokeWidth={2}
              dot={{ r: 2 }}
            />
          ))}
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};

export default CREVariantTrendChart;