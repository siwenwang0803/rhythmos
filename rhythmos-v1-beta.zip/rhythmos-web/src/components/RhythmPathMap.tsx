// components/RhythmPathMap.tsx

import React from 'react'

interface TaskStep {
  id: string
  goalId: string
  intent: string
  task: string
  difficulty: 'minimal' | 'light' | 'normal' | 'challenge'
  stage: 'initial' | 'middle' | 'final'
  status: 'pending' | 'completed'
  createdAt: number
}

const stageOrder = ['initial', 'middle', 'final']

const RhythmPathMap: React.FC = () => {
  const raw = localStorage.getItem('rhythmSubtasks')
  const subtasks: TaskStep[] = raw ? JSON.parse(raw) : []

  const grouped = subtasks.reduce<Record<string, TaskStep[]>>((acc, step) => {
    if (!acc[step.goalId]) acc[step.goalId] = []
    acc[step.goalId].push(step)
    return acc
  }, {})

  return (
    <div className="space-y-8">
      {Object.entries(grouped).map(([goalId, steps]) => {
        return (
          <div key={goalId} className="p-4 border rounded-xl bg-white shadow-sm">
            <h2 className="text-md font-semibold text-gray-800 mb-2">
              🧩 Goal Path: {goalId}
            </h2>

            <div className="space-y-2">
              {stageOrder.map((stage) => (
                <div key={stage}>
                  <p className="text-xs text-gray-500 font-medium uppercase">{stage}</p>
                  <ul className="ml-4 text-sm text-gray-700 list-disc space-y-1">
                    {steps
                      .filter((s) => s.stage === stage)
                      .map((step) => (
                        <li key={step.id}>
                          {step.task}{' '}
                          <span className="text-xs italic text-gray-400">({step.difficulty})</span>
                        </li>
                      ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        )
      })}
    </div>
  )
}

export default RhythmPathMap
