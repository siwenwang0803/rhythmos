// components/RhythmTaskProgressChart.tsx

import React from 'react'

interface FeedbackEntry {
  task: string
  score: number
  timestamp: number
}

const RhythmTaskProgressChart: React.FC = () => {
  const raw = localStorage.getItem('taskFeedbackLog')
  const log: FeedbackEntry[] = raw ? JSON.parse(raw) : []

  const grouped: Record<string, number[]> = {}

  log.forEach((entry) => {
    const date = new Date(entry.timestamp).toISOString().split('T')[0]
    if (!grouped[date]) grouped[date] = []
    grouped[date].push(entry.score)
  })

  const entries = Object.entries(grouped).sort(([a], [b]) => a.localeCompare(b))

  return (
    <div className="space-y-4">
      {entries.map(([date, scores]) => {
        const avg = scores.reduce((sum, s) => sum + s, 0) / scores.length
        return (
          <div key={date} className="space-y-1">
            <p className="text-sm text-gray-700 font-medium">{date}</p>
            <div className="w-full h-4 bg-gray-200 rounded overflow-hidden">
              <div
                className="h-4 bg-gradient-to-r from-blue-500 to-blue-400 rounded"
                style={{ width: `${(avg / 5) * 100}%` }}
              />
            </div>
            <p className="text-xs text-gray-500 italic">
              Avg Score: {avg.toFixed(2)} ({scores.length} tasks)
            </p>
          </div>
        )
      })}
    </div>
  )
}

export default RhythmTaskProgressChart
