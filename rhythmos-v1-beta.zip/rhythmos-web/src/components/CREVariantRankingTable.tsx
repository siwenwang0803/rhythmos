// components/CREVariantRankingTable.tsx

import React from 'react'
import Section from './ui/Section'

interface VariantStat {
  variant: string
  avg: number
  total: number
}

interface CREVariantRankingTableProps {
    
  data: Record<string, VariantStat[]>
}

const CREVariantRankingTable: React.FC<CREVariantRankingTableProps> = ({ data }) => {
    if (!data || typeof data !== 'object') return <p className="text-sm text-gray-400 italic">No variant data available.</p>
  return (
    <div className="space-y-6">
      {Object.entries(data).map(([group, entries]) => (
        <Section key={group} title={`📊 ${group}`}>
          <table className="w-full text-sm text-left border">
            <thead>
              <tr className="bg-gray-100 text-xs text-gray-600">
                <th className="p-2 border">Variant</th>
                <th className="p-2 border">Avg Score</th>
                <th className="p-2 border">Total Ratings</th>
              </tr>
            </thead>
            <tbody>
              {entries
                .sort((a, b) => b.avg - a.avg)
                .map(({ variant, avg, total }, i) => (
                  <tr key={i}>
                    <td className="p-2 border font-mono">{variant}</td>
                    <td className="p-2 border text-blue-700 font-semibold">{avg}</td>
                    <td className="p-2 border text-gray-600">{total}</td>
                  </tr>
                ))}
            </tbody>
          </table>
        </Section>
      ))}
    </div>
  )
}

export default CREVariantRankingTable
