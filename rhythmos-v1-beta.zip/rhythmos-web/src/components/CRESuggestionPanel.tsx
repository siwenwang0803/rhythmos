// components/CRESuggestionPanel.tsx

import React from 'react'

interface CRESuggestionPanelProps {
  suggestions: string[]
  onAccept: (line: string) => void
  onRegenerate?: () => void
}

const CRESuggestionPanel: React.FC<CRESuggestionPanelProps> = ({
  suggestions,
  onAccept,
  onRegenerate
}) => {
  return (
    <div className="space-y-4">
      <h3 className="text-md font-semibold text-gray-800">💡 Suggested CRE Variants</h3>

      <ul className="space-y-3">
        {suggestions.map((line, i) => (
          <li
            key={i}
            className="p-3 bg-gray-50 border border-gray-200 rounded-xl flex items-start justify-between gap-3"
          >
            <p className="text-sm text-gray-700 italic">{line}</p>
            <button
              onClick={() => onAccept(line)}
              className="text-sm bg-blue-600 text-white px-3 py-1 rounded hover:bg-blue-700"
            >
              ✅ Accept
            </button>
          </li>
        ))}
      </ul>

      {onRegenerate && (
        <div className="pt-4">
          <button
            onClick={onRegenerate}
            className="text-xs text-blue-500 underline hover:text-blue-700"
          >
            🔁 Regenerate suggestions
          </button>
        </div>
      )}
    </div>
  )
}

export default CRESuggestionPanel
