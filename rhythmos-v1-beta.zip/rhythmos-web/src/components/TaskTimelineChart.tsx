// components/TaskTimelineChart.tsx

import React from 'react'

interface FeedbackEntry {
  task: string
  score: number
  timestamp: number
}

const TaskTimelineChart: React.FC = () => {
  const raw = localStorage.getItem('taskFeedbackLog')
  const log: FeedbackEntry[] = raw ? JSON.parse(raw) : []

  const grouped: Record<string, FeedbackEntry[]> = {}

  log.forEach((entry) => {
    const date = new Date(entry.timestamp).toISOString().split('T')[0]
    if (!grouped[date]) grouped[date] = []
    grouped[date].push(entry)
  })

  const entries = Object.entries(grouped).sort(([a], [b]) => a.localeCompare(b))

  return (
    <div className="mt-8">
      <h3 className="text-md font-semibold mb-3">📆 Task Completion Timeline</h3>
      <div className="space-y-4">
        {entries.map(([date, tasks]) => (
          <div key={date}>
            <p className="text-sm font-medium text-gray-700 mb-1">{date}</p>
            <div className="flex flex-wrap gap-2">
              {tasks.map((t, i) => (
                <div key={i} className="px-3 py-1 rounded bg-blue-100 text-xs text-blue-800 shadow-sm">
                  ⭐ {t.score} · {t.task}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

export default TaskTimelineChart
