// components/CREFeedbackTrainer.tsx

import React, { useState } from 'react'
import { generateCREWeightedSet } from '../creStrategySort'

const CREFeedbackTrainer: React.FC = () => {
  const [selected, setSelected] = useState<{ taskType: string; variant: string } | null>(null)
  const weighted = generateCREWeightedSet()

  const addMockRating = (taskType: string, variant: string, score: number) => {
    const raw = localStorage.getItem('creSampleRatings')
    const ratings = raw ? JSON.parse(raw) : []
    ratings.push({ taskType, variant, score, timestamp: Date.now() })
    localStorage.setItem('creSampleRatings', JSON.stringify(ratings))
    window.location.reload()
  }

  return (
    <div className="mt-10">
      <h3 className="text-md font-semibold mb-3">🧪 CRE Strategy Tuner</h3>

      {Object.entries(weighted).map(([taskType, entries]) => (
        <div key={taskType} className="mb-6">
          <p className="text-sm text-blue-600 font-medium mb-1">Task: {taskType}</p>
          <div className="space-y-1">
            {entries.map(({ variant, avg, count }) => (
              <div
                key={variant}
                className="p-2 rounded border hover:bg-gray-50 cursor-pointer"
                onClick={() => setSelected({ taskType, variant })}
              >
                <p className="text-sm font-mono">{variant}</p>
                <p className="text-xs text-gray-600">Avg: {avg.toFixed(2)} · Total: {count}</p>
              </div>
            ))}
          </div>
        </div>
      ))}

      {selected && (
        <div className="mt-4 p-4 border rounded-xl bg-yellow-50 space-y-3">
          <p className="text-sm text-gray-700">
            Adjust score for: <span className="font-mono">{selected.variant}</span>
          </p>
          <div className="flex gap-2 text-sm">
            {[1, 2, 3, 4, 5].map((s) => (
              <button
                key={s}
                onClick={() => addMockRating(selected.taskType, selected.variant, s)}
                className="px-3 py-1 bg-blue-600 text-white rounded"
              >
                +{s}
              </button>
            ))}
            <button
              onClick={() => setSelected(null)}
              className="px-3 py-1 bg-gray-300 text-black rounded"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  )
}

export default CREFeedbackTrainer
