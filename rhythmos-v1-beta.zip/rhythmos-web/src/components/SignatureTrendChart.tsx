// SignatureTrendChart.tsx (with CRE personalization)

import React from 'react';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

interface SignatureTrendChartProps {
  data: { timestamps: string[]; scores: number[] };
  persona: string;
}

const SignatureTrendChart: React.FC<SignatureTrendChartProps> = ({ data, persona }) => {
  if (!data || data.timestamps.length === 0) return null;

  const chartData = data.timestamps.map((timestamp, index) => ({
    time: new Date(timestamp).toLocaleString(),
    score: data.scores[index],
  }));

  return (
    <div className="mt-6">
      <h3 className="text-md font-semibold mb-2">📈 {persona} Score Trend</h3>
      <ResponsiveContainer width="100%" height={250}>
        <LineChart data={chartData}>
          <XAxis dataKey="time" tick={{ fontSize: 10 }} angle={-30} height={50} interval={0} />
          <YAxis domain={[0, 5]} />
          <Tooltip />
          <Line type="monotone" dataKey="score" stroke="#8884d8" strokeWidth={2} dot={true} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};

export default SignatureTrendChart;
