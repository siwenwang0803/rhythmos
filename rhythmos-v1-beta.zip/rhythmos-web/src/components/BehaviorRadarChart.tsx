// components/BehaviorRadarChart.tsx

import React from 'react'
import {
  Radar,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts'

interface FeedbackEntry {
  score: number
  task: string
  timestamp: number
}

const BehaviorRadarChart: React.FC = () => {
  const raw = localStorage.getItem('taskFeedbackLog')
  const log: FeedbackEntry[] = raw ? JSON.parse(raw) : []

  const behaviorMap: Record<
    'minimal' | 'light' | 'normal' | 'challenge',
    { complete: number; tried: number; skipped: number }
  > = {
    minimal: { complete: 0, tried: 0, skipped: 0 },
    light: { complete: 0, tried: 0, skipped: 0 },
    normal: { complete: 0, tried: 0, skipped: 0 },
    challenge: { complete: 0, tried: 0, skipped: 0 }
  }

  // mock difficulty assignment by task keyword
  log.forEach((entry) => {
    const task = entry.task.toLowerCase()
    let type: keyof typeof behaviorMap = 'normal'

    if (task.includes('one breath') || task.includes('just') || task.includes('zone')) {
      type = 'minimal'
    } else if (task.includes('skim') || task.includes('light') || task.includes('write')) {
      type = 'light'
    } else if (task.includes('clarify') || task.includes('focus')) {
      type = 'normal'
    } else if (task.includes('final') || task.includes('challenge') || task.includes('stretch')) {
      type = 'challenge'
    }

    if (entry.score >= 5) behaviorMap[type].complete++
    else if (entry.score >= 3) behaviorMap[type].tried++
    else behaviorMap[type].skipped++
  })

  const data = Object.entries(behaviorMap).map(([type, b]) => ({
    taskType: type,
    Completed: b.complete,
    Tried: b.tried,
    Skipped: b.skipped
  }))

  return (
    <ResponsiveContainer width="100%" height={300}>
      <RadarChart data={data}>
        <PolarGrid />
        <PolarAngleAxis dataKey="taskType" />
        <PolarRadiusAxis />
        <Radar name="Completed" dataKey="Completed" stroke="#38bdf8" fill="#38bdf8" fillOpacity={0.5} />
        <Radar name="Tried" dataKey="Tried" stroke="#facc15" fill="#facc15" fillOpacity={0.4} />
        <Radar name="Skipped" dataKey="Skipped" stroke="#f87171" fill="#f87171" fillOpacity={0.3} />
        <Tooltip />
        <Legend />
      </RadarChart>
    </ResponsiveContainer>
  )
}

export default BehaviorRadarChart
