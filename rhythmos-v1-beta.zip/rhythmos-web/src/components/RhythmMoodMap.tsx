// components/RhythmMoodMap.tsx

import React from 'react'
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid
} from 'recharts'

interface JournalEntry {
  text: string
  timestamp: number
  trend: 'collapsed' | 'wavy' | 'stable' | 'rising'
}

const moodScoreMap: Record<JournalEntry['trend'], number> = {
  collapsed: 1,
  wavy: 2,
  stable: 3,
  rising: 4
}

const RhythmMoodMap: React.FC = () => {
  const raw = localStorage.getItem('rhythmJournal')
  const entries: JournalEntry[] = raw ? JSON.parse(raw) : []

  const data = entries
    .sort((a, b) => a.timestamp - b.timestamp)
    .map((entry) => ({
      date: new Date(entry.timestamp).toLocaleDateString(),
      mood: moodScoreMap[entry.trend]
    }))

  return (
    <ResponsiveContainer width="100%" height={300}>
      <LineChart data={data}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="date" />
        <YAxis domain={[0, 5]} tickCount={5} />
        <Tooltip />
        <Line type="monotone" dataKey="mood" stroke="#6366f1" strokeWidth={2} />
      </LineChart>
    </ResponsiveContainer>
  )
}

export default RhythmMoodMap
