// CREUsageBarChart.tsx

import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend, PieChart, Pie, Cell } from 'recharts';
import { getCREStyleUsageDistribution } from '../creStyleUsage';

const CREUsageBarChart: React.FC = () => {
  const { toneCount, variantCount, overrideCount, signatureCount } = getCREStyleUsageDistribution();

  const toneData = Object.entries(toneCount).map(([key, value]) => ({ name: key, count: value }));
  const variantData = Object.entries(variantCount).map(([key, value]) => ({ name: key, count: value }));
  const sourceData = [
    { name: 'Override', value: overrideCount },
    { name: 'Signature', value: signatureCount }
  ];

  const colors = ['#8884d8', '#82ca9d', '#ffc658', '#ff6b6b', '#4b9eff', '#aa66cc'];

  return (
    <div className="mt-10 space-y-8">
      <div>
        <h3 className="text-sm font-semibold text-gray-700 mb-2">🎯 Tone Usage Distribution</h3>
        <ResponsiveContainer width="100%" height={240}>
          <BarChart data={toneData}>
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="count" fill="#4b9eff" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div>
        <h3 className="text-sm font-semibold text-gray-700 mb-2">🎨 Variant Usage Distribution</h3>
        <ResponsiveContainer width="100%" height={240}>
          <BarChart data={variantData}>
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="count" fill="#ff6b6b" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div>
        <h3 className="text-sm font-semibold text-gray-700 mb-2">⚙️ Source Strategy Distribution</h3>
        <ResponsiveContainer width="100%" height={260}>
          <PieChart>
            <Pie data={sourceData} dataKey="value" nameKey="name" outerRadius={80} label>
              {sourceData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />
              ))}
            </Pie>
            <Tooltip />
            <Legend />
          </PieChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default CREUsageBarChart;