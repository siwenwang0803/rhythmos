// SignatureMapView.tsx

import React from 'react';

interface SignatureMapViewProps {
  data: Record<string, Record<string, {
    total: number;
    complete: number;
    tried: number;
    skipped: number;
    avgScore: number;
  }>>;
}

const SignatureMapView: React.FC<SignatureMapViewProps> = ({ data }) => {
  const trends = Object.keys(data);

  return (
    <div className="mt-8">
      <h3 className="text-md font-semibold mb-2">📊 Signature Map</h3>
      {trends.length === 0 ? (
        <p className="text-gray-500 italic">No signature data available yet.</p>
      ) : (
        <div className="space-y-4">
          {trends.map((trend) => (
            <div key={trend} className="p-4 bg-white border rounded-xl shadow-sm">
              <p className="text-sm font-semibold mb-2">🌡️ Trend: {trend}</p>
              <table className="text-sm w-full">
                <thead>
                  <tr className="text-gray-400">
                    <th className="text-left">Persona</th>
                    <th>Score</th>
                    <th>Complete</th>
                    <th>Tried</th>
                    <th>Skipped</th>
                  </tr>
                </thead>
                <tbody>
                  {Object.entries(data[trend]).map(([persona, stats]) => (
                    <tr key={persona} className="border-t">
                      <td>{persona}</td>
                      <td className="text-center">{stats.avgScore}</td>
                      <td className="text-center">{stats.complete}</td>
                      <td className="text-center">{stats.tried}</td>
                      <td className="text-center">{stats.skipped}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default SignatureMapView;
