// components/NextStepSuggestion.tsx

import React from 'react';
import { recommendSubtask } from '../taskRecommender';
import { generateCREOutput } from '../outputRouter';
import { RhythmSubtask } from '../rhythmSubtasks';

interface Props {
  goalId: string;
  trend: string;
  subtasks: RhythmSubtask[];
  onAccept: (task: RhythmSubtask) => void;
}

const NextStepSuggestion: React.FC<Props> = ({ goalId, trend, subtasks, onAccept }) => {
  const recommended = recommendSubtask(subtasks, trend, goalId);

  if (!recommended) {
    return (
      <div className="mt-6 text-sm text-gray-500 italic">
        No recommended subtasks at this moment.
      </div>
    );
  }

  const { cre } = generateCREOutput({
    trend,
    stage: 'middle',
    taskType: recommended.difficulty,
    signature: JSON.parse(localStorage.getItem('rhythmSignature') || '{}')
  });

  return (
    <div className="mt-6 p-4 border rounded-xl bg-white shadow-sm space-y-2">
      <p className="text-sm text-gray-500 font-medium">🔁 Recommended Next Step</p>
      <p className="text-base text-black font-semibold">{recommended.task}</p>
      <p className="text-xs text-blue-700 italic">{cre}</p>
      <button
        onClick={() => onAccept(recommended)}
        className="mt-3 px-3 py-1 text-sm bg-blue-600 text-white rounded"
      >
        Accept & Continue
      </button>
    </div>
  );
};

export default NextStepSuggestion;
