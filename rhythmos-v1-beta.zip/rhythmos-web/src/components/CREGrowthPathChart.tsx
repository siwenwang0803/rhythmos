// CREGrowthPathChart.tsx

import React from 'react';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { getUserCREGrowthPath } from '../variantGrowthPath';

const toneColorMap: Record<string, string> = {
  gentle: '#82ca9d',
  directive: '#ff6b6b',
  motivated: '#4b9eff',
  visionary: '#aa66cc'
};

const CREGrowthPathChart: React.FC = () => {
  const data = getUserCREGrowthPath();

  const grouped: Record<string, { date: string; score: number }[]> = {};
  data.forEach(({ date, tone, score }) => {
    if (!grouped[tone]) grouped[tone] = [];
    grouped[tone].push({ date, score });
  });

  return (
    <div className="mt-10">
      <h3 className="text-sm font-semibold text-gray-700 mb-3">📈 User Rhythm Growth Path</h3>
      <ResponsiveContainer width="100%" height={300}>
        <LineChart>
          <XAxis dataKey="date" type="category" allowDuplicatedCategory={false} />
          <YAxis domain={[0, 5]} />
          <Tooltip />
          <Legend />
          {Object.entries(grouped).map(([tone, values]) => (
            <Line
              key={tone}
              data={values}
              type="monotone"
              dataKey="score"
              name={tone}
              stroke={toneColorMap[tone] || '#8884d8'}
              dot={{ r: 3 }}
            />
          ))}
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};

export default CREGrowthPathChart;

  