// components/ui/RhythmButton.tsx

import React from 'react'

interface RhythmButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'muted' | 'danger'
  children: React.ReactNode
}

const variantClasses: Record<string, string> = {
  primary: 'bg-blue-600 text-white hover:bg-blue-700',
  secondary: 'bg-green-600 text-white hover:bg-green-700',
  muted: 'bg-gray-200 text-black hover:bg-gray-300',
  danger: 'bg-red-600 text-white hover:bg-red-700'
}

const RhythmButton: React.FC<RhythmButtonProps> = ({
  variant = 'primary',
  children,
  className = '',
  ...props
}) => {
  return (
    <button
      {...props}
      className={`px-4 py-2 text-sm rounded ${variantClasses[variant]} ${className}`}
    >
      {children}
    </button>
  )
}

export default RhythmButton
