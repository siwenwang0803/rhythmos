// components/ui/ToneBadge.tsx

import React from 'react'
import { toneColors } from '../../styles/toneColors'

interface ToneBadgeProps {
  tone: string
}

const ToneBadge: React.FC<ToneBadgeProps> = ({ tone }) => {
  const className = toneColors[tone] || toneColors['unknown']
  return (
    <span className={`inline-block px-2 py-0.5 text-xs font-medium rounded ${className}`}>
      {tone}
    </span>
  )
}

export default ToneBadge
