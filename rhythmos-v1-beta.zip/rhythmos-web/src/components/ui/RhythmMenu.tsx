// components/ui/RhythmMenu.tsx

import React from 'react'
import { useNavigate } from 'react-router-dom'
import RhythmButton from './RhythmButton'

const menuItems = [
  { label: '🏠 Home', path: '/' },
  { label: '🎯 Goals', path: '/goals' },
  { label: '🎧 Onboarding', path: '/onboarding' },
  { label: '📊 Preview System', path: '/cre-preview' },
  { label: '🌱 Growth Map', path: '/growth-map' },
  { label: '🚀 Launch Checklist', path: '/launch' },
  { label: '🛠️ Settings', path: '/settings' }
]

const RhythmMenu: React.FC = () => {
  const navigate = useNavigate()

  return (
    <div className="flex flex-wrap gap-3">
      {menuItems.map((item) => (
        <RhythmButton
          key={item.path}
          variant="muted"
          onClick={() => navigate(item.path)}
        >
          {item.label}
        </RhythmButton>
      ))}
    </div>
  )
}

export default RhythmMenu
