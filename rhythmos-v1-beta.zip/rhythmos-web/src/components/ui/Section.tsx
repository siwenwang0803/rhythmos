// components/ui/Section.tsx

import React from 'react'

interface SectionProps {
  title: string
  description?: string
  children: React.ReactNode
  className?: string
}

const Section: React.FC<SectionProps> = ({ title, description, children, className = '' }) => {
  return (
    <section className={`space-y-3 ${className}`}>
      <div>
        <h2 className="text-md font-semibold text-gray-800">{title}</h2>
        {description && <p className="text-sm text-gray-500">{description}</p>}
      </div>
      <div>{children}</div>
    </section>
  )
}

export default Section
