import React from 'react'

const ToneWarning: React.FC<{ trend: string }> = ({ trend }) => {
  if (trend !== 'collapsed') return null

  return (
    <div className="p-3 bg-yellow-50 border-l-4 border-yellow-400 text-sm text-yellow-700 rounded-xl">
      ⚠️ You are in a collapsed state. CRE tone is locked to <strong>gentle</strong> and only soft guidance will be used.
    </div>
  )
}

export default ToneWarning
