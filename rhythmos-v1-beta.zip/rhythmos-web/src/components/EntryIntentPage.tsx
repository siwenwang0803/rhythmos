import HomePage from './components/HomePage';
import { logEntryIntent } from '../rhythmLog'; //
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

interface IntentOption {
  id: string;
  label: string;
  description: string;
  persona: string;
  tone: string;
  cre: string;
}

const intentOptions: IntentOption[] = [
  {
    id: 'collapse',
    label: '😞 Emotionally overwhelmed',
    description: 'I feel like collapsing or shutting down.',
    persona: 'Aurelia',
    tone: 'soft',
    cre: "You don’t have to explain. You can just rest here for a moment."
  },
  {
    id: 'procrastinate',
    label: '🕓 I want to stop procrastinating',
    description: 'I need to do something, but I can’t start.',
    persona: 'Rhea',
    tone: 'soft',
    cre: "Want me to just sit with you for a bit until we start?"
  },
  {
    id: 'organize',
    label: '📅 Build a calmer daily rhythm',
    description: 'I want to feel more balanced and structured.',
    persona: 'Lucis',
    tone: 'light',
    cre: "Let’s start by finding one gentle rhythm to repeat."
  },
  {
    id: 'purpose',
    label: '🧭 Reconnect with purpose',
    description: 'I want to feel clear about who I am and why I’m here.',
    persona: 'Caelum',
    tone: 'deep',
    cre: "You were never meant to fit in. You were meant to create the rhythm that others follow."
  },
  {
    id: 'unsure',
    label: '🌊 I’m not sure yet',
    description: 'I just want a safe space to see what happens.',
    persona: 'Aurelia',
    tone: 'soft',
    cre: "You don’t have to know. Just start from where you are."
  }
];

const EntryIntentPage: React.FC = () => {
  const [selected, setSelected] = useState<IntentOption | null>(null);
  const navigate = useNavigate();

  return (
    <div style={styles.container}>
      <h2>What brings you to RhythmOS today?</h2>
      {!selected && (
        <div style={styles.optionsGrid}>
          {intentOptions.map((option) => (
            <div key={option.id} style={styles.card} onClick={() => setSelected(option)}>
              <h3>{option.label}</h3>
              <p style={{ color: '#555', fontSize: '14px' }}>{option.description}</p>
            </div>
          ))}
        </div>
      )}

      {selected && (
        <div style={styles.responseBlock}>
          <h3>{selected.label}</h3>
          <p style={{ margin: '8px 0', fontWeight: 'bold' }}>{selected.persona} · {selected.tone} tone</p>
          <p><strong>CRE:</strong> {selected.cre}</p>
          <button
  style={styles.button}
  onClick={() => {
    if (selected) {
      logEntryIntent(selected.id, selected.persona, selected.tone, selected.cre);
      navigate('/input');
    }
  }}
>
  Begin your rhythm →
</button>
        </div>
      )}
    </div>
  );
};

const styles: { [key: string]: React.CSSProperties } = {
  container: {
    maxWidth: 700,
    margin: '60px auto',
    textAlign: 'center',
    fontFamily: 'sans-serif',
    padding: '0 20px'
  },
  optionsGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))',
    gap: '20px',
    marginTop: '30px'
  },
  card: {
    backgroundColor: '#F9FAFC',
    border: '1px solid #DDD',
    borderRadius: '10px',
    padding: '18px',
    cursor: 'pointer',
    transition: 'all 0.3s ease',
    boxShadow: '0 0 5px rgba(0,0,0,0.04)'
  },
  responseBlock: {
    marginTop: '40px',
    padding: '20px',
    backgroundColor: '#F1F5FF',
    borderRadius: '10px',
    textAlign: 'left'
  },
  button: {
    marginTop: '20px',
    backgroundColor: '#4B9EFF',
    color: '#fff',
    padding: '12px 20px',
    fontSize: '16px',
    borderRadius: '8px',
    border: 'none',
    cursor: 'pointer'
  }
};

export default EntryIntentPage;
