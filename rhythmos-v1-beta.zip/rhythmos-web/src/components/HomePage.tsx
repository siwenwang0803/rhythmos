// src/components/HomePage.tsx

import { useNavigate } from 'react-router-dom';

export default function HomePage() {
  const navigate = useNavigate();

  return (
    <div className="flex flex-col items-center justify-center min-h-screen gap-6">
      <h1 className="text-3xl font-bold">Welcome to RhythmOS</h1>
      <p className="text-lg text-gray-600">Your personalized rhythm guidance system.</p>

      <button
        className="px-6 py-3 bg-blue-500 text-white rounded-xl"
        onClick={() => navigate('/intent')}
      >
        Start My Rhythm Journey
      </button>
      <button
  className="px-6 py-3 bg-green-500 text-white rounded-xl"
  onClick={() => navigate('/try')}
>
  🌱 Try RhythmOS (Quick Start)
</button>

      <button
        className="px-6 py-3 bg-gray-200 text-black rounded-xl"
        onClick={() => navigate('/log')}
      >
        View My Rhythm Logs
      </button>

      <button
        className="px-4 py-2 text-sm text-blue-400 underline"
        onClick={() => alert('RhythmOS 是一个节奏引导系统，帮助你建立情绪感知 × 行动决策 × 节奏稳定性。')}
      >
        Learn more about RhythmOS
      </button>
    </div>
  );
}


