// signatureAnalyzer.ts

import { RhythmSignatureMap } from './rhythmSignature';

export function getBestPersonaForTrend(
  trend: string,
  signature: RhythmSignatureMap
): { persona: string; score: number } | null {
  const entries = signature[trend];
  if (!entries) return null;

  const list = Object.entries(entries);
  if (list.length === 0) return null;

  // Sort by avgScore desc, fallback by complete count
  const sorted = list.sort(([, a], [, b]) => {
    if (b.avgScore !== a.avgScore) return b.avgScore - a.avgScore;
    return (b.complete || 0) - (a.complete || 0);
  });

  const [best, data] = sorted[0];
  return { persona: best, score: data.avgScore };
}
export function getPersonaRanking(
  trend: string,
  signature: RhythmSignatureMap
): { persona: string; avgScore: number; total: number }[] {
  const data = signature[trend];
  if (!data) return [];

  return Object.entries(data)
    .map(([persona, stats]) => ({
      persona,
      avgScore: stats.avgScore,
      total: stats.total,
    }))
    .sort((a, b) => b.avgScore - a.avgScore);
}
