// variantScoreTrend.ts

export function getVariantScoreTrend(): Record<string, { date: string; score: number }[]> {
    const raw = localStorage.getItem('creSampleRatings');
    const ratings = raw ? JSON.parse(raw) : [];
  
    const trends: Record<string, { date: string; score: number }[]> = {};
  
    ratings.forEach((entry: any) => {
      const key = `${entry.taskType}-${entry.variant}`;
      const date = new Date(entry.timestamp).toISOString().slice(0, 10); // YYYY-MM-DD
  
      if (!trends[key]) trends[key] = [];
      trends[key].push({ date, score: entry.score });
    });
  
    return trends;
  }
  