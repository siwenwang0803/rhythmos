// variantGrowthPath.ts

export function getUserCREGrowthPath(): {
    date: string;
    tone: string;
    variant: string;
    score: number;
  }[] {
    const raw = localStorage.getItem('creSampleRatings');
    const ratings = raw ? JSON.parse(raw) : [];
  
    const path = ratings.map((entry: any) => ({
      date: new Date(entry.timestamp).toISOString().slice(0, 10),
      tone: entry.tone,
      variant: entry.variant,
      score: entry.score
    }));
  
    return path.sort((a, b) => a.date.localeCompare(b.date));
  }
  