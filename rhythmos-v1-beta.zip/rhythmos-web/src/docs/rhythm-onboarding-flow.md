# 🎧 RhythmOS Onboarding Flow Spec

---

## 🧠 Purpose:

Let user begin their day by checking their rhythm state, preview CRE tone, and flow into the right starting experience.

---

## 🌡️ Rhythm Check-in Options:

- `collapsed` → user is overwhelmed / blocked / low energy
- `wavy` → user is distracted / emotionally drifting
- `stable` → user can maintain baseline flow
- `rising` → user feels energy, intention, momentum

---

## 🪞 System Response Logic:

| Trend     | CRE Tone       | Task Path        | Suggested Flow      |
|-----------|----------------|------------------|---------------------|
| collapsed | `gentle`       | micro-task only  | go to `/journal`    |
| wavy      | `gentle/light` | short taskPath   | go to `/goals` (light path) |
| stable    | `motivated`    | full taskPath    | go to `/goals`      |
| rising    | `directive`    | challenge path   | go to `/goals`      |

---

## ✅ Entry Page UI Flow:

- Step 1: How are you feeling?
- Step 2: Show CRE tone preview
- Step 3: Show next step recommendation
- Step 4: “Begin” → routed accordingly

---

## 🔄 Integrates with:

- `/journal` (collapsed → reflection-based flow)
- `/goals` (all others → behavior execution)

---

This is not a mode selector. This is a rhythm resonance detector.

