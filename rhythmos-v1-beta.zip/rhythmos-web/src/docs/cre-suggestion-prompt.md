# 🔧 CRE Prompt Template Example

This is how RhythmOS generates language suggestions for new CRE variants based on tone, task type, and stage.

---

## 🎨 Inputs:

- **Tone**: e.g. `"gentle"`, `"directive"`, `"visionary"`
- **Stage**: `"initial"`, `"middle"`, `"final"`
- **TaskType**: `"minimal"`, `"light"`, `"normal"`, `"challenge"`

---

## 🧠 System Prompt:

“You are a rhythm-aware language generator. Given a tone, behavioral stage, and task difficulty, generate short, poetic, motivational phrases that match the tone’s personality. Avoid obvious templates. Your goal is to help a user shift state through tone resonance.”

---

## 📝 Prompt Example:

**Tone**: `"gentle"`  
**Stage**: `"initial"`  
**TaskType**: `"minimal"`

→  
Please generate 3 short rhythm language variants for the user.

---

## 🔁 Expected Output:

- “You’re allowed to begin softly. One breath is enough.”  
- “Just pause. That alone counts.”  
- “Let the rhythm begin with ease.”

---

## ✅ Use in LLM or local assistant

You can send this structure into GPT or other language models to generate future CRE suggestions.
