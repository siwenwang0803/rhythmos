// taskRecommender.ts (updated with rhythm stage logic)

import { RhythmSubtask } from './rhythmSubtasks';
import { getGoalRhythmStage } from './goalProgress';

export function recommendSubtask(
  subtasks: RhythmSubtask[],
  currentTrend: string,
  goalId: string
): RhythmSubtask | null {
  if (subtasks.length === 0) return null;

  const stage = getGoalRhythmStage(goalId);

  const trendToDifficultyMap: Record<string, RhythmSubtask['difficulty'][]> = {
    collapsed: ['minimal'],
    frozen: ['minimal'],
    wavy: ['minimal', 'light'],
    stable: ['light', 'normal'],
    rising: ['normal', 'challenge'],
  };

  const stageBias: Record<string, RhythmSubtask['difficulty'][]> = {
    initial: ['minimal', 'light'],
    middle: ['light', 'normal'],
    final: ['normal', 'challenge'],
    complete: [],
  };

  const allowedDifficulties = Array.from(
    new Set([...(trendToDifficultyMap[currentTrend] || []), ...(stageBias[stage] || [])])
  );

  const filtered = subtasks.filter(
    (t) => t.status === 'pending' && allowedDifficulties.includes(t.difficulty)
  );

  if (filtered.length === 0) return null;

  return filtered.sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime())[0];
}
