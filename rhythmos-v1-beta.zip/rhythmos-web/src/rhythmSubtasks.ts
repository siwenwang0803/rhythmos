export interface RhythmSubtask {
    id: string;
    goalId: string;
    title: string;
    createdAt: string;
    status: 'pending' | 'completed';
    difficulty: 'minimal' | 'light' | 'normal' | 'challenge';
    notes?: string;
  }
  
  export function generateInitialSubtasks(goalId: string, title: string): RhythmSubtask[] {
    const subtasks: RhythmSubtask[] = [
      {
        id: crypto.randomUUID(),
        goalId,
        title: `Clarify the scope of: ${title}`,
        createdAt: new Date().toISOString(),
        status: 'pending',
        difficulty: 'minimal'
      },
      {
        id: crypto.randomUUID(),
        goalId,
        title: `Break down "${title}" into 3 milestones`,
        createdAt: new Date().toISOString(),
        status: 'pending',
        difficulty: 'light'
      },
      {
        id: crypto.randomUUID(),
        goalId,
        title: `Start the first action step toward: ${title}`,
        createdAt: new Date().toISOString(),
        status: 'pending',
        difficulty: 'normal'
      }
    ];
  
    return subtasks;
  }
  
  export function saveSubtasks(subtasks: RhythmSubtask[]) {
    const raw = localStorage.getItem('rhythmSubtasks');
    const existing: RhythmSubtask[] = raw ? JSON.parse(raw) : [];
    const updated = [...existing, ...subtasks];
    localStorage.setItem('rhythmSubtasks', JSON.stringify(updated));
  }
  
  export function getSubtasksForGoal(goalId: string): RhythmSubtask[] {
    const raw = localStorage.getItem('rhythmSubtasks');
    if (!raw) return [];
    const all: RhythmSubtask[] = JSON.parse(raw);
    return all.filter(task => task.goalId === goalId);
  }
  