// manualChoiceEvaluator.ts

export function evaluateManualTaskChoice(
    difficulty: 'minimal' | 'light' | 'normal' | 'challenge',
    trend: string,
    stage: string
  ): {
    scoreDelta: number;
    message: string;
  } {
    const baseReward = {
      minimal: 1,
      light: 2,
      normal: 3,
      challenge: 4,
    }[difficulty];
  
    const penaltyTrend = trend === 'collapsed' || trend === 'frozen';
    const bonusTrend = trend === 'rising';
    let score = baseReward;
  
    if (penaltyTrend && (difficulty === 'normal' || difficulty === 'challenge')) {
      score -= 2;
    } else if (bonusTrend && (difficulty === 'normal' || difficulty === 'challenge')) {
      score += 1;
    }
  
    score = Math.max(-2, Math.min(5, score));
  
    let message = '';
    if (score >= 4) {
      message = "💥 You took initiative on a high-difficulty task — that’s leadership energy.";
    } else if (score >= 2) {
      message = "👏 Solid move. You chose something meaningful and followed through.";
    } else if (score >= 0) {
      message = "🌀 This was a bit much for your current rhythm. Let's adjust pace if needed.";
    } else {
      message = "⚠️ This task may have pulled you too far. A rhythm reset could help.";
    }
  
    return {
      scoreDelta: score,
      message,
    };
  }
  