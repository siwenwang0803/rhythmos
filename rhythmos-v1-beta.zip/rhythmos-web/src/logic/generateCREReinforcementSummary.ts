// logic/generateCREReinforcementSummary.ts

interface FeedbackEntry {
    tone: string
    score: number
    timestamp: number
  }
  
  export function generateCREReinforcementSummary(): {
    favoriteTone: string
    toneAverages: Record<string, number>
    toneRank: string[]
    comment: string
  } {
    const raw = localStorage.getItem('creSampleRatings')
    const ratings: FeedbackEntry[] = raw ? JSON.parse(raw) : []
  
    const toneScores: Record<string, number[]> = {}
  
    ratings.forEach((r) => {
      if (!toneScores[r.tone]) toneScores[r.tone] = []
      toneScores[r.tone].push(r.score)
    })
  
    const toneAverages: Record<string, number> = {}
  
    for (const tone in toneScores) {
      const list = toneScores[tone]
      const avg = list.reduce((a, b) => a + b, 0) / list.length
      toneAverages[tone] = parseFloat(avg.toFixed(2))
    }
  
    const ranked = Object.entries(toneAverages)
      .sort((a, b) => b[1] - a[1])
      .map(([tone]) => tone)
  
    const favoriteTone = ranked[0] || 'unknown'
  
    const comments: Record<string, string> = {
      directive: 'You tend to resonate with structure, direction, and assertive clarity.',
      gentle: 'You thrive in soft encouragement, subtle momentum, and inner space.',
      motivated: 'You move with energy, emotional warmth, and upward language.',
      visionary: 'You need deeper meaning, future tension, and transformative tone.',
      unknown: 'Your tone preference is still unfolding.'
    }
  
    return {
      favoriteTone,
      toneAverages,
      toneRank: ranked,
      comment: comments[favoriteTone] || comments.unknown
    }
  }
  