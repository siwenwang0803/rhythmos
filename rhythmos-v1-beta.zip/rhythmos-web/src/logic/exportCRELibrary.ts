// logic/exportCRELibrary.ts

import { creVariants } from '../cre/creVariantRegistry'

export function downloadCRELibrary(): void {
  const data = {
    generatedAt: new Date().toISOString(),
    variants: creVariants
  }

  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
  const url = URL.createObjectURL(blob)
  const link = document.createElement('a')
  link.href = url
  link.download = 'cre-variant-library.json'
  link.click()
  URL.revokeObjectURL(url)
}
