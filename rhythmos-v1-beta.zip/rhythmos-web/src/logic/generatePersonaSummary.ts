// logic/generatePersonaSummary.ts

import { getCREStyleTimeSeries } from '../creRatingStats'

export function generatePersonaSummary(): {
  coreStyle: string
  toneProfile: Record<string, number>
  summary: string
  quote: string
} {
  const series = getCREStyleTimeSeries()
  const toneCount: Record<string, number> = {}

  series.forEach((entry) => {
    toneCount[entry.tone] = (toneCount[entry.tone] || 0) + entry.count
  })

  const sorted = Object.entries(toneCount).sort((a, b) => b[1] - a[1])
  const coreTone = sorted[0]?.[0] || 'unknown'

  const styleMessages: Record<string, string> = {
    directive: 'You move best with clear, sharp momentum. Action clarifies you.',
    gentle: 'You grow through kindness and rhythm. Softness is your power.',
    motivated: 'You need warmth and upward language to activate your flow.',
    visionary: 'You resonate with purpose. Direction alone isn’t enough—you need depth.',
    unknown: 'Your style is still emerging. Keep moving, and it will reveal itself.'
  }

  const styleQuotes: Record<string, string> = {
    directive: '“I act, therefore I arrive.”',
    gentle: '“I grow when pressure steps aside.”',
    motivated: '“I begin when someone reminds me I can.”',
    visionary: '“I create my rhythm through meaning.”',
    unknown: '“Even silence carries rhythm.”'
  }

  return {
    coreStyle: coreTone,
    toneProfile: toneCount,
    summary: styleMessages[coreTone],
    quote: styleQuotes[coreTone]
  }
}
