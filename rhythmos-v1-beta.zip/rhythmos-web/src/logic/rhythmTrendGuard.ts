export function isToneLocked(trend: string): string | null {
  if (trend === 'collapsed') return 'gentle'
  return null
}

export function getAllowedTaskTypes(trend: string): string[] {
  switch (trend) {
    case 'collapsed':
      return ['minimal', 'light']
    case 'wavy':
      return ['minimal', 'light', 'normal']
    case 'stable':
      return ['light', 'normal']
    case 'rising':
      return ['normal', 'challenge']
    default:
      return ['light']
  }
}
