// logic/recommendNextRhythmStep.ts

import { getCREStyleTimeSeries } from '../creRatingStats'
import { getRhythmTrend } from '../rhythmLog'

export function recommendNextRhythmStep(): {
  tone: string
  taskType: 'minimal' | 'light' | 'normal' | 'challenge'
  suggestion: string
} {
  const raw = localStorage.getItem('taskFeedbackLog')
  const log = raw ? JSON.parse(raw) : []

  const toneStats = getCREStyleTimeSeries()
  const trend = getRhythmTrend(log.slice(-5))

  // 计算跳过 vs 完成比例
  const completed = log.filter((e: any) => e.score >= 5).length
  const skipped = log.filter((e: any) => e.score <= 2).length
  const tried = log.filter((e: any) => e.score >= 3 && e.score < 5).length

  const skipRatio = skipped / (completed + skipped + tried + 1)

  // 提取 dominant tone
  const toneCount: Record<string, number> = {}
  toneStats.forEach((entry) => {
    toneCount[entry.tone] = (toneCount[entry.tone] || 0) + entry.count
  })
  const sortedTones = Object.entries(toneCount).sort((a, b) => b[1] - a[1])
  const coreTone = sortedTones[0]?.[0] || 'gentle'

  // 推理任务类型
  let taskType: 'minimal' | 'light' | 'normal' | 'challenge' = 'normal'
  if (trend === 'collapsed') taskType = 'minimal'
  else if (trend === 'wavy') taskType = skipRatio > 0.3 ? 'light' : 'normal'
  else if (trend === 'rising') taskType = skipRatio < 0.2 ? 'challenge' : 'normal'

  const suggestions: Record<typeof taskType, string> = {
    minimal: 'Write one sentence. That’s enough.',
    light: 'Do one small focused block of work.',
    normal: 'Start your usual task. Keep a rhythm.',
    challenge: 'Pick the step you’ve been avoiding—and just begin.'
  }

  return {
    tone: coreTone,
    taskType,
    suggestion: suggestions[taskType]
  }
}
