// logic/taskPathFromIntent.ts

import { goalTemplates } from '../templates/goalTemplateRegistry'

export function taskPathFromIntent(templateId: string, goalId: string): {
  id: string
  goalId: string
  status: 'pending'
  intent: string
  difficulty: 'minimal' | 'light' | 'normal' | 'challenge'
  stage: 'initial' | 'middle' | 'final'
  task: string
  createdAt: number
}[] {
  const template = goalTemplates.find((t) => t.id === templateId)
  if (!template) return []

  return template.structure.map((s, i) => ({
    id: `${goalId}-${i}`,
    goalId,
    intent: template.intent,
    difficulty: s.difficulty,
    stage: s.stage,
    task: s.task,
    status: 'pending',
    createdAt: Date.now() + i
  }))
}
