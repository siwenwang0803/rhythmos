import { getAllowedTaskTypes } from './rhythmTrendGuard'

interface TaskStep {
  stage: 'initial' | 'middle' | 'final'
  task: string
  difficulty: 'minimal' | 'light' | 'normal' | 'challenge'
}

export function generateRhythmGoalPath(goal: string, trend: string): TaskStep[] {
  const allowed = getAllowedTaskTypes(trend)

  const fullPath: TaskStep[] = [
    {
      stage: 'initial',
      task: `Start small: outline your first step for "${goal}"`,
      difficulty: 'minimal'
    },
    {
      stage: 'middle',
      task: `Make real progress on "${goal}"`,
      difficulty: 'normal'
    },
    {
      stage: 'final',
      task: `Wrap up your progress on "${goal}"`,
      difficulty: 'light'
    },
    {
      stage: 'final',
      task: `Challenge yourself to go further with "${goal}"`,
      difficulty: 'challenge'
    }
  ]

  return fullPath.filter((step) => allowed.includes(step.difficulty))
}
