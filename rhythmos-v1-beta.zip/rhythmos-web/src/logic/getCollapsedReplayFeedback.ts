export function getCollapsedReplayFeedback(): string | null {
  const raw = localStorage.getItem('rhythmJournal')
  if (!raw) return null

  const entries = JSON.parse(raw)
  const collapsedEntries = entries.filter(
    (e: any) => e.trend === 'collapsed' && typeof e.text === 'string' && e.text.length > 20
  )

  if (collapsedEntries.length === 0) return null

  const latest = collapsedEntries[collapsedEntries.length - 1]

  return (
    'Last time you felt blocked, you still wrote: “' +
    latest.text.slice(0, 60) +
    '...” That was the moment rhythm returned.'
  )
}
