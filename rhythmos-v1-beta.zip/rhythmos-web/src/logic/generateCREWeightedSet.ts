export function generateCREWeightedSet(): Record<string, { variant: string; avg: number; total: number }[]> {
    const raw = localStorage.getItem('creSampleRatings')
    const ratings = raw ? JSON.parse(raw) : []
  
    const scoreMap: Record<string, Record<string, number[]>> = {}
  
    ratings.forEach((entry: any) => {
      const { tone, stage, taskType, variant, score } = entry
      const key = `${tone}-${stage}-${taskType}`
      if (!scoreMap[key]) scoreMap[key] = {}
      if (!scoreMap[key][variant]) scoreMap[key][variant] = []
      scoreMap[key][variant].push(score)
    })
  
    const weightedSet: Record<string, { variant: string; avg: number; total: number }[]> = {}
  
    for (const key in scoreMap) {
      const variants = scoreMap[key]
      const ranked = Object.entries(variants).map(([variant, scores]) => {
        const avg = scores.reduce((sum, s) => sum + s, 0) / scores.length
        return {
          variant,
          avg: parseFloat(avg.toFixed(2)),
          total: scores.length
        }
      })
      weightedSet[key] = ranked.sort((a, b) => b.avg - a.avg)
    }
  
    return weightedSet
  }
  