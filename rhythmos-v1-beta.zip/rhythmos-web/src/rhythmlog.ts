export interface RhythmSignature {
    timestamp: string;
    user_id?: string;
    entry_intent: string;
    persona: string;
    tone: string;
    cre: string;
  }
  
  const LOCAL_KEY = 'rhythm_signature_log';
  
  const loadLog = (): RhythmSignature[] => {
    const stored = localStorage.getItem(LOCAL_KEY);
    return stored ? JSON.parse(stored) : [];
  };
  
  let rhythmLog: RhythmSignature[] = loadLog();
  
  export const logEntryIntent = (
    intent: string,
    persona: string,
    tone: string,
    cre: string,
    user_id?: string
  ) => {
    const entry: RhythmSignature = {
      timestamp: new Date().toISOString(),
      user_id,
      entry_intent: intent,
      persona,
      tone,
      cre
    };
    rhythmLog.push(entry);
    localStorage.setItem(LOCAL_KEY, JSON.stringify(rhythmLog));
    console.log("📦 Entry intent logged:", entry);
  };
  
  export const getRhythmLog = (): RhythmSignature[] => {
    return rhythmLog;
  };
  
  export const exportRhythmLog = (): string => {
    return JSON.stringify(rhythmLog, null, 2);
  };
  // rhythmLog.ts

export function logFeedbackEntry(entry: {
    inputText: string;
    feedbackType: string;
    score: number;
    rhythmState: string;
    creStrategyMessage: string;
  }) {
    const existing = localStorage.getItem('rhythmFeedbackLog');
    const parsed = existing ? JSON.parse(existing) : [];
  
    const newEntry = {
      ...entry,
      timestamp: new Date().toISOString(),
    };
   
    parsed.push(newEntry);
    localStorage.setItem('rhythmFeedbackLog', JSON.stringify(parsed.slice(-50))); // 最多保留 50 条
  }
  export function getRecentRhythmLogs(limit = 5): FeedbackLogEntry[] {
    const raw = localStorage.getItem("rhythmFeedbackLog");
    if (!raw) return [];
  
    const parsed: FeedbackLogEntry[] = JSON.parse(raw);
    parsed.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    return parsed.slice(0, limit);
  }
  export function getRhythmTrend(log: FeedbackLogEntry[]): string {
    if (!log || log.length === 0) return 'frozen';
  
    const now = Date.now();
    const lastTimestamp = new Date(log[0].timestamp).getTime();
    const hoursSinceLast = (now - lastTimestamp) / (1000 * 60 * 60);
    if (hoursSinceLast > 48) return 'frozen';
  
    const counts = { complete: 0, tried: 0, skipped: 0 };
    let scoreSum = 0;
  
    for (const entry of log) {
      counts[entry.feedbackType]++;
      scoreSum += entry.score || 0;
    }
  
    const avgScore = scoreSum / log.length;
  
    if (counts.skipped >= 2 || avgScore < 0) return 'collapsed';
    if (counts.complete >= 3 && avgScore >= 4) return 'rising';
    if (counts.tried >= 2 && counts.skipped === 0) return 'wavy';
    if (avgScore >= 1 && avgScore <= 4) return 'stable';
  
    return 'wavy'; // fallback
  }
  
  