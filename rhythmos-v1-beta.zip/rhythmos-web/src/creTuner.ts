// creTuner.ts (with style preference integration)

import { getCREStylePreference } from './creStylePreference';
import { RhythmSignatureMap } from './rhythmSignature';

export function getPersonalizedCRE(
  trend: string,
  persona: string,
  baseCRE: string,
  signature?: RhythmSignatureMap
): string {
  const toneMap: Record<string, Record<string, string>> = {
    collapsed: {
      Aurelia: 'gentle',
      Rhea: 'soothing',
      Lucis: 'soft-neutral',
      Manual: 'grounding',
      Caelum: 'protective',
    },
    wavy: {
      Aurelia: 'warm',
      Rhea: 'casual-reassuring',
      Lucis: 'light-structured',
      Manual: 'neutral-soft',
      Caelum: 'encouraging-observer',
    },
    stable: {
      Aurelia: 'calm',
      Rhea: 'confident-supportive',
      Lucis: 'bright-neutral',
      Manual: 'simple-guided',
      Caelum: 'steady-visionary',
    },
    rising: {
      Aurelia: 'uplifting',
      Rhea: 'energized',
      Lucis: 'motivated',
      Manual: 'precise-positive',
      Caelum: 'inspired-bold',
    },
  };

  let modifier = toneMap[trend]?.[persona] || 'neutral';

  // Optional override from style preference
  if (signature) {
    const pref = getCREStylePreference(signature);
    if (pref.tone === 'visionary') modifier = 'inspired-bold';
    else if (pref.tone === 'motivated') modifier = 'motivated';
    else if (pref.tone === 'directive') modifier = 'precise-positive';
    else if (pref.tone === 'gentle') modifier = 'gentle';
  }

  const modifiers: Record<string, (text: string) => string> = {
    gentle: (text) => `🌸 ${text} Just breathe. You’re doing your best.`,
    soothing: (text) => `${text} I’ll sit here with you.`,
    'soft-neutral': (text) => `${text} No pressure at all.`,
    grounding: (text) => `${text} You’re safe right here.`,
    protective: (text) => `I’ve got you. ${text}`,

    warm: (text) => `💬 ${text} You’re not alone in this.`,
    'casual-reassuring': (text) => `${text} Let’s see where it goes.`,
    'light-structured': (text) => `⏳ ${text} Just a small step forward.`,
    'neutral-soft': (text) => `${text} You’re still here, and that counts.`,
    'encouraging-observer': (text) => `${text} You're gathering rhythm.`,

    calm: (text) => `🌿 ${text}`,
    'confident-supportive': (text) => `${text} You’ve done this before — and you can again.`,
    'bright-neutral': (text) => `${text} Keep it steady.`,
    'simple-guided': (text) => `${text} Let’s just follow the next step.`,
    'steady-visionary': (text) => `${text} You’re building something that lasts.`,

    uplifting: (text) => `🚀 ${text} Let’s move with this momentum.`,
    energized: (text) => `${text} Let’s go full rhythm now.`,
    motivated: (text) => `✅ ${text}`,
    'precise-positive': (text) => `${text} Clean. Clear. Good work.`,
    'inspired-bold': (text) => `${text} You’re writing your future in real time.`,

    neutral: (text) => text,
  };

  return modifiers[modifier](baseCRE);
}
  