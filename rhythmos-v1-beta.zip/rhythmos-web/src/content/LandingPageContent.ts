// src/content/LandingPageContent.ts

export const landingContent = {
    headline: 'RhythmOS',
    subhead: 'A system for rhythm-based thinking, CRE-driven guidance, and collaborative emotional intelligence.',
    bullets: [
      '🎯 Generate daily task rhythm and language prompts.',
      '📊 Tune strategy based on behavior feedback.',
      '🧠 Visualize your tone growth and rhythm progression.',
      '🔁 Evolve your personal guidance through use.',
    ],
    actions: [
      { label: 'Start Now', to: '/onboarding', variant: 'primary' },
      { label: 'Preview CRE System', to: '/cre-preview', variant: 'secondary' },
      { label: 'Login', to: '/login', variant: 'muted' }
    ],
    footer: 'Built from rhythm. Ready for the world.'
  }
  
  