// rhythmScore.ts

export type RhythmState = "rising" | "stable" | "wavy" | "collapsed";

export function updateRhythmScore(
  action: "complete" | "tried" | "skipped"
): { score: number; state: RhythmState } {
  const previous = getRhythmScore();
  let updated = previous;

  // 评分逻辑
  if (action === "complete") {
    updated += 2;
  } else if (action === "tried") {
    updated += 1;
  } else if (action === "skipped") {
    updated -= 1;

    const lastTwo = getRecentActions();
    if (lastTwo[0] === "skipped" && lastTwo[1] === "skipped") {
      updated -= 2; // 连续跳过惩罚
    }
  }

  // 限制范围（防止溢出）
  if (updated > 10) updated = 10;
  if (updated < -5) updated = -5;

  localStorage.setItem("rhythmScore", updated.toString());
  recordAction(action);

  return { score: updated, state: getRhythmState(updated) };
}

export function getRhythmScore(): number {
  const raw = localStorage.getItem("rhythmScore");
  return raw ? parseInt(raw) : 0;
}

function getRhythmState(score: number): RhythmState {
  if (score >= 6) return "rising";
  if (score >= 2) return "stable";
  if (score >= 0) return "wavy";
  return "collapsed";
}

// === 最近两次行为记录，用于判断连续跳过 ===

function getRecentActions(): string[] {
  const raw = localStorage.getItem("recentActions");
  if (!raw) return [];
  return JSON.parse(raw).slice(-2);
}

function recordAction(action: string) {
  const raw = localStorage.getItem("recentActions");
  const list = raw ? JSON.parse(raw) : [];
  list.push(action);
  localStorage.setItem("recentActions", JSON.stringify(list.slice(-10))); // 保留最多 10 条
}
