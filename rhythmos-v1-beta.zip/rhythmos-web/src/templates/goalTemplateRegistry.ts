// templates/goalTemplateRegistry.ts

export interface GoalTemplate {
    id: string
    intent: string
    description: string
    structure: {
      stage: 'initial' | 'middle' | 'final'
      difficulty: 'minimal' | 'light' | 'normal' | 'challenge'
      task: string
    }[]
  }
  
  export const goalTemplates: GoalTemplate[] = [
    {
      id: 'focus-writing',
      intent: 'Focused Writing',
      description: 'Draft a small unit of writing from scratch to clarity.',
      structure: [
        { stage: 'initial', difficulty: 'light', task: 'Write a single messy paragraph' },
        { stage: 'middle', difficulty: 'normal', task: 'Clarify the core idea in 3 lines' },
        { stage: 'final', difficulty: 'normal', task: 'Polish the final paragraph and let it rest' }
      ]
    },
    {
      id: 'quick-study',
      intent: 'Quick Study',
      description: 'Short focused review to strengthen one weak concept.',
      structure: [
        { stage: 'initial', difficulty: 'light', task: 'Skim one key concept' },
        { stage: 'middle', difficulty: 'normal', task: 'Write it in your own words' },
        { stage: 'final', difficulty: 'normal', task: 'Quiz yourself or summarize the idea' }
      ]
    },
    {
      id: 'space-reset',
      intent: 'Environment Reset',
      description: 'Declutter or organize one small visible area.',
      structure: [
        { stage: 'initial', difficulty: 'light', task: 'Pick one small zone to clean' },
        { stage: 'middle', difficulty: 'normal', task: 'Clear or reset the area' },
        { stage: 'final', difficulty: 'minimal', task: 'Stand back and look at your progress' }
      ]
    }
  ]
  