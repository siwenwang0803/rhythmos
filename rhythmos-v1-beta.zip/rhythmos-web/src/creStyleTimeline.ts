// creStyleTimeline.ts

import { RhythmSignatureMap } from './rhythmSignature';

interface FeedbackLogEntry {
  inputText: string;
  feedbackType: string;
  score: number;
  rhythmState: string;
  creStrategyMessage: string;
  timestamp: string;
  persona?: string;
}

export function getCREStyleTimeSeries(): {
  timestamp: string;
  tone: string;
  score: number;
}[] {
  const raw = localStorage.getItem('rhythmFeedbackLog');
  if (!raw) return [];

  const logs: FeedbackLogEntry[] = JSON.parse(raw);
  const tones: { [key: string]: string } = {
    Aurelia: 'gentle',
    Rhea: 'directive',
    Lucis: 'motivated',
    Caelum: 'visionary',
    Manual: 'motivated',
  };

  return logs
    .filter((log) => log.persona && log.score !== undefined)
    .map((log) => ({
      timestamp: log.timestamp,
      tone: tones[log.persona || 'Manual'] || 'gentle',
      score: log.score,
    }));
}
