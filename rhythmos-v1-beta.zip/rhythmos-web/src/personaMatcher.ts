
import { RhythmSignatureMap } from './rhythmSignature';

export function getPreferredPersona(
  trend: string,
  signature: RhythmSignatureMap
): string {
  if (!signature[trend]) return 'Lucis'; // fallback if trend data missing

  const entries = Object.entries(signature[trend]);
  if (entries.length === 0) return 'Lucis';

  // Sort personas by average score descending, fallback by complete count
  const sorted = entries.sort(([, a], [, b]) => {
    if (b.avgScore !== a.avgScore) {
      return b.avgScore - a.avgScore;
    }
    return (b.complete || 0) - (a.complete || 0);
  });

  const [bestPersona] = sorted[0];
  return bestPersona;
}