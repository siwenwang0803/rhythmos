export interface RhythmSignatureMap {
    [trend: string]: {
      [persona: string]: {
        total: number;
        complete: number;
        tried: number;
        skipped: number;
        avgScore: number;
        scoreSum: number;
      };
    };
  }
  
  export function updateRhythmSignature(
    trend: string,
    persona: string,
    feedbackType: 'complete' | 'tried' | 'skipped',
    score: number
  ) {
    const raw = localStorage.getItem('rhythmSignature');
    const data: RhythmSignatureMap = raw ? JSON.parse(raw) : {};
  
    if (!data[trend]) data[trend] = {};
    if (!data[trend][persona]) {
      data[trend][persona] = {
        total: 0,
        complete: 0,
        tried: 0,
        skipped: 0,
        avgScore: 0,
        scoreSum: 0,
      };
    }
  
    const current = data[trend][persona];
    current.total++;
    current[feedbackType]++;
    current.scoreSum += score;
    current.avgScore = parseFloat((current.scoreSum / current.total).toFixed(2));
  
    localStorage.setItem('rhythmSignature', JSON.stringify(data));
  }
  
  export function getRhythmSignature(): RhythmSignatureMap {
    const raw = localStorage.getItem('rhythmSignature');
    return raw ? JSON.parse(raw) : {};
  }
  