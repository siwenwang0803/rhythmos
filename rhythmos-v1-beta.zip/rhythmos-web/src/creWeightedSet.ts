// creWeightedSet.ts

export function generateCREWeightedSet() {
    const raw = localStorage.getItem('creSampleRatings');
    const ratings = raw ? JSON.parse(raw) : [];
  
    const scoreMap: Record<string, Record<string, number[]>> = {};
  
    ratings.forEach((entry: any) => {
      const { taskType, variant, score } = entry;
      if (!scoreMap[taskType]) scoreMap[taskType] = {};
      if (!scoreMap[taskType][variant]) scoreMap[taskType][variant] = [];
      scoreMap[taskType][variant].push(score);
    });
  
    const result: Record<string, { variant: string; avg: number; total: number }[]> = {};
  
    for (const taskType in scoreMap) {
      const variants = scoreMap[taskType];
      const scored = Object.entries(variants).map(([variant, scores]) => {
        const avg = parseFloat((scores.reduce((a, b) => a + b, 0) / scores.length).toFixed(2));
        return {
          variant,
          avg,
          total: scores.length
        };
      });
      result[taskType] = scored.sort((a, b) => b.avg - a.avg);
    }
  
    return result;
  }
  