// goalProgress.ts

import { getSubtasksForGoal } from './rhythmSubtasks';

export function getGoalRhythmStage(goalId: string): 'initial' | 'middle' | 'final' | 'complete' {
  const subtasks = getSubtasksForGoal(goalId);
  if (subtasks.length === 0) return 'initial';

  const total = subtasks.length;
  const completed = subtasks.filter(t => t.status === 'completed').length;

  if (completed === 0) return 'initial';
  if (completed < total - 1) return 'middle';
  if (completed === total - 1) return 'final';
  if (completed === total) return 'complete';

  return 'initial';
}