// signatureTrend.ts

interface FeedbackLogEntry {
    inputText: string;
    feedbackType: string;
    score: number;
    rhythmState: string;
    creStrategyMessage: string;
    timestamp: string;
    persona?: string;
  }
  
  export function getSignatureTrend(
    trend: string,
    persona: string
  ): { timestamps: string[]; scores: number[] } {
    const raw = localStorage.getItem('rhythmFeedbackLog');
    if (!raw) return { timestamps: [], scores: [] };
  
    const logs: FeedbackLogEntry[] = JSON.parse(raw);
    const filtered = logs.filter(
      (entry) => entry.rhythmState === trend && entry.persona === persona
    );
  
    return {
      timestamps: filtered.map((entry) => entry.timestamp),
      scores: filtered.map((entry) => entry.score),
    };
  }
  