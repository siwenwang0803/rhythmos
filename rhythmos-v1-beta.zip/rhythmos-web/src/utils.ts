export function getStoredJson(key: string) {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : [];
  }
  const ratings = getStoredJson('creSampleRatings');
