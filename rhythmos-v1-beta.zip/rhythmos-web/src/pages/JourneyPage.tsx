// pages/JourneyPage.tsx

import React from 'react'
import Section from '../components/ui/Section'
import RhythmButton from '../components/ui/RhythmButton'
import { useNavigate } from 'react-router-dom'

const JourneyPage: React.FC = () => {
  const navigate = useNavigate()

  return (
    <div className="min-h-screen px-6 py-10 max-w-3xl mx-auto space-y-10">
      <h1 className="text-2xl font-bold text-gray-800">🧭 Your Rhythm Journey</h1>
      <p className="text-sm text-gray-500">
        This is not a productivity tool. This is a rhythm for your life.
      </p>

      <Section title="🎯 Step 1: Feel your rhythm">
        <ul className="list-disc list-inside text-sm text-gray-600 space-y-1">
          <li>Start at <code>/rhythm</code> and check-in your state: collapsed, wavy, stable, or rising.</li>
          <li>Let RhythmOS generate a tone-matched CRE phrase.</li>
          <li>Set your intention and enter with presence.</li>
        </ul>
        <div className="pt-3">
          <RhythmButton onClick={() => navigate('/rhythm')} variant="primary">
            Go to Rhythm Entry
          </RhythmButton>
        </div>
      </Section>

      <Section title="🪞 Step 2: Act on your intention">
        <ul className="list-disc list-inside text-sm text-gray-600 space-y-1">
          <li>Visit <code>/goals</code> to see tasks based on your rhythm.</li>
          <li>Follow the steps, mark them done, and let the system learn from you.</li>
        </ul>
        <div className="pt-3">
          <RhythmButton onClick={() => navigate('/goals')} variant="secondary">
            View My Goals
          </RhythmButton>
        </div>
      </Section>

      <Section title="✍️ Step 3: Reflect gently">
        <ul className="list-disc list-inside text-sm text-gray-600 space-y-1">
          <li>Go to <code>/journal</code> and write with CRE guidance.</li>
          <li>Don’t write to impress—write to express.</li>
        </ul>
        <div className="pt-3">
          <RhythmButton onClick={() => navigate('/journal')} variant="secondary">
            Open Journal
          </RhythmButton>
        </div>
      </Section>

      <Section title="🧠 Step 4: See your persona">
        <ul className="list-disc list-inside text-sm text-gray-600 space-y-1">
          <li>Check your rhythm tone usage and behavior radar at <code>/persona</code>.</li>
          <li>Let the system reflect: “You tend to rise when pressure softens.”</li>
        </ul>
        <div className="pt-3">
          <RhythmButton onClick={() => navigate('/persona')} variant="secondary">
            View Persona Report
          </RhythmButton>
        </div>
      </Section>

      <Section title="💬 Step 5: Feedback to language">
        <ul className="list-disc list-inside text-sm text-gray-600 space-y-1">
          <li>Visit <code>/cre-preview</code> or <code>/cre-studio</code>.</li>
          <li>Rate the phrases that work for you. Watch language evolve through rhythm.</li>
        </ul>
        <div className="flex gap-3 pt-3">
          <RhythmButton onClick={() => navigate('/cre-preview')} variant="muted">
            Preview CRE
          </RhythmButton>
          <RhythmButton onClick={() => navigate('/cre-studio')} variant="muted">
            CRE Studio
          </RhythmButton>
        </div>
      </Section>

      <div className="pt-8 text-center text-xs text-gray-400 italic">
        You’re not managing time. You’re managing <strong>tone</strong>.
      </div>
    </div>
  )
}

export default JourneyPage
