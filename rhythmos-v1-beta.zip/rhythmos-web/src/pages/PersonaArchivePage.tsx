// pages/PersonaArchivePage.tsx

import React from 'react'
import { generatePersonaSummary } from '../logic/generatePersonaSummary'
import { recommendNextRhythmStep } from '../logic/recommendNextRhythmStep'
import { getCREStyleTimeSeries } from '../creRatingStats'
import Section from '../components/ui/Section'
import RhythmButton from '../components/ui/RhythmButton'

const PersonaArchivePage: React.FC = () => {
  const persona = generatePersonaSummary()
  const next = recommendNextRhythmStep()
  const creHistory = getCREStyleTimeSeries()

  const handleDownload = () => {
    const archive = {
      createdAt: Date.now(),
      persona,
      recommendation: next,
      usageHistory: creHistory
    }

    const blob = new Blob([JSON.stringify(archive, null, 2)], {
      type: 'application/json'
    })

    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = 'rhythm-persona-archive.json'
    link.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="min-h-screen px-6 py-10 max-w-2xl mx-auto space-y-10">
      <h1 className="text-2xl font-bold text-gray-800">📦 Export Your Rhythm Persona</h1>
      <p className="text-sm text-gray-500">
        Download your rhythm fingerprint, style trends, and current recommendations.
      </p>

      <Section title="🧬 Summary">
        <p className="text-sm text-gray-700">{persona.summary}</p>
        <p className="text-xs italic text-blue-700">"{persona.quote}"</p>
      </Section>

      <Section title="🔮 System Recommendation">
        <p className="text-sm text-gray-600">{next.suggestion}</p>
        <p className="text-xs text-gray-400">
          tone: <strong>{next.tone}</strong> | task type: <strong>{next.taskType}</strong>
        </p>
      </Section>

      <Section title="📤 Download Archive">
        <p className="text-sm text-gray-500 mb-2">
          Save your CRE tone pattern + rhythm feedback snapshot.
        </p>
        <RhythmButton onClick={handleDownload} variant="primary">
          ⬇️ Download rhythm-persona-archive.json
        </RhythmButton>
      </Section>

      <div className="pt-6 text-xs text-gray-400 text-center italic">
        Rhythm is remembered not in words, but in presence.
      </div>
    </div>
  )
}

export default PersonaArchivePage
