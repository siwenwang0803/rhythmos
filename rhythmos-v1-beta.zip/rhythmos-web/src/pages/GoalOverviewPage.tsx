import React from 'react'
import { getRhythmGoals, updateGoalStatus } from '../rhythmGoal'
import { useNavigate } from 'react-router-dom'
import RhythmButton from '../components/ui/RhythmButton'
import Section from '../components/ui/Section'

const GoalOverviewPage: React.FC = () => {
  const navigate = useNavigate()
  const goals = getRhythmGoals()

  const handleComplete = (id: string) => {
    updateGoalStatus(id, 'completed')
    window.location.reload()
  }

  const activeGoals = goals.filter((goal) => goal.status === 'active')

  return (
    <div className="min-h-screen px-6 py-10 max-w-3xl mx-auto text-left space-y-10">
      <h1 className="text-2xl font-bold">📚 Your Active Goals</h1>

      {activeGoals.length === 0 ? (
        <Section
          title="No active rhythm goals"
          description="Start by creating a small task to begin your rhythm journey."
        >
          <RhythmButton onClick={() => navigate('/goal-input')} variant="primary">
            ➕ Add First Goal
          </RhythmButton>
        </Section>
      ) : (
        <div className="space-y-4">
          {activeGoals.map((goal) => (
            <div key={goal.id} className="p-4 bg-white border rounded-xl shadow-sm">
              <h2 className="text-lg font-semibold mb-1">{goal.title}</h2>
              {goal.notes && <p className="text-sm text-gray-600 mb-2">{goal.notes}</p>}
              <p className="text-xs text-gray-400 mb-2">
                Created: {new Date(goal.createdAt).toLocaleString()}
              </p>
              <div className="flex gap-3 mt-2">
                <RhythmButton onClick={() => navigate(`/goals/${goal.id}`)} variant="muted">
                  🔍 View Details
                </RhythmButton>
                <RhythmButton onClick={() => handleComplete(goal.id)} variant="secondary">
                  ✅ Mark as Done
                </RhythmButton>
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="pt-8">
        <RhythmButton onClick={() => navigate('/goal-input')} variant="primary">
          ➕ Add New Goal
        </RhythmButton>
      </div>
    </div>
  )
}

export default GoalOverviewPage
