// pages/PersonaReportPage.tsx

import React from 'react'
import Section from '../components/ui/Section'
import RhythmTaskProgressChart from '../components/RhythmTaskProgressChart'
import CREStyleGrowthMap from '../components/CREStyleGrowthMap'
import BehaviorRadarChart from '../components/BehaviorRadarChart'
import { generatePersonaSummary } from '../logic/generatePersonaSummary'
import { recommendNextRhythmStep } from '../logic/recommendNextRhythmStep'

const PersonaReportPage: React.FC = () => {
const persona = generatePersonaSummary()
const nextStep = recommendNextRhythmStep()

  return (
    <div className="min-h-screen px-6 py-10 max-w-4xl mx-auto space-y-12">
      <h1 className="text-2xl font-bold text-gray-800">🧬 Your Rhythm Persona</h1>
      <p className="text-sm text-gray-500">
        This is a profile built from your past task patterns, CRE feedback, and tone style behaviors.
      </p>

      <Section title="🎯 Rhythm Pattern Overview">
        <RhythmTaskProgressChart />
      </Section>

      <Section title="🎨 CRE Style Usage Over Time">
        <CREStyleGrowthMap />
      </Section>

      <Section title="🧭 Task Behavior Radar">
        <BehaviorRadarChart />
      </Section>

      <Section title="💬 Rhythm Language Summary">
  <p className="text-sm text-gray-600 mb-2">{persona.summary}</p>
  <blockquote className="text-blue-600 italic text-sm">“{persona.quote}”</blockquote>
</Section>

<Section title="📌 System Recommendation">
  <p className="text-sm text-gray-700 mb-2">
    Based on your recent rhythm pattern, the system recommends:
  </p>
  <p className="text-base font-semibold text-blue-700">{nextStep.suggestion}</p>
  <p className="text-xs text-gray-500 mt-2 italic">
    Suggested tone: <strong>{nextStep.tone}</strong> | task type: <strong>{nextStep.taskType}</strong>
  </p>
</Section>


      <div className="pt-8 text-xs text-gray-400 italic text-center">
        This is your current rhythm fingerprint. Let’s grow it.
      </div>
    </div>
  )
}

export default PersonaReportPage
