// pages/RhythmCheckinPage.tsx

import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import RhythmButton from '../components/ui/RhythmButton'
import Section from '../components/ui/Section'
import { generateCREOutput } from '../outputRouter'
import { updateRhythmScore } from '../rhythmScore'
import { updateRhythmSignature } from '../rhythmSignature'
import GoalIntentSelector from '../components/GoalIntentSelector'
import { taskPathFromIntent } from '../logic/taskPathFromIntent'
import { goalTemplates } from '../templates/goalTemplateRegistry'

type RhythmTrend = 'collapsed' | 'wavy' | 'stable' | 'rising'

const trendOptions: { label: string; value: RhythmTrend }[] = [
  { label: '🫥 Collapsed', value: 'collapsed' },
  { label: '🌊 Wavy', value: 'wavy' },
  { label: '⚖️ Stable', value: 'stable' },
  { label: '🔥 Rising', value: 'rising' }
]

const RhythmCheckinPage: React.FC = () => {
  const navigate = useNavigate()
  const [goal, setGoal] = useState('')
  const [trend, setTrend] = useState<RhythmTrend | null>(null)

  const handleSubmit = () => {
    if (!goal || !trend) return
  
    const goalObj = {
      id: Date.now().toString(),
      title: goal,
      notes: '',
      createdAt: Date.now(),
      status: 'active'
    }
  
    const existing = JSON.parse(localStorage.getItem('rhythmGoals') || '[]')
    localStorage.setItem('rhythmGoals', JSON.stringify([...existing, goalObj]))
  
    // ✅ 【新增】尝试从 goal 模板中匹配 intent → 自动生成路径
    const matchedTemplate = goalTemplates.find((t) =>
      goal.toLowerCase().includes(t.intent.toLowerCase())
    )
  
    if (matchedTemplate) {
      const subtasks = taskPathFromIntent(matchedTemplate.id, goalObj.id)
      const existingSubtasks = JSON.parse(localStorage.getItem('rhythmSubtasks') || '[]')
      localStorage.setItem('rhythmSubtasks', JSON.stringify([...existingSubtasks, ...subtasks]))
    }
  
    // ✅ record rhythm score + signature
    const { score } = updateRhythmScore(trend)
    const signature = JSON.parse(localStorage.getItem('rhythmSignature') || '{}')
    updateRhythmSignature(trend, 'auto', 'complete', score)
  
    // ✅ branch behavior
    if (trend === 'collapsed' || trend === 'wavy') {
      navigate('/cre-preview')
    } else {
      navigate('/goals')
    }
  }
  

  const cre = trend
    ? generateCREOutput({
        trend,
        stage: 'initial',
        taskType: trend === 'rising' ? 'challenge' : trend === 'stable' ? 'normal' : 'light',
        signature: JSON.parse(localStorage.getItem('rhythmSignature') || '{}')
      }).cre
    : ''

  return (
    <div className="min-h-screen px-6 py-10 max-w-xl mx-auto space-y-10">
      <h1 className="text-2xl font-bold text-gray-800">🎧 Enter Your Daily Rhythm</h1>

      <Section
         title="🎯 What type of rhythm do you want to begin?"
         description="Choose a rhythm intent, or write your own."
       >
         <GoalIntentSelector onSelect={(text) => setGoal(text)} />
         <input
           type="text"
           value={goal}
           onChange={(e) => setGoal(e.target.value)}
           placeholder="or write your custom goal here..."
           className="w-full px-4 py-2 text-sm border rounded shadow-sm mt-4"
         />
      </Section>

      <Section title="🌡️ How are you feeling today?" description="This helps calibrate your rhythm tone.">
        <div className="grid grid-cols-2 gap-2">
          {trendOptions.map((t) => (
            <RhythmButton
              key={t.value}
              onClick={() => setTrend(t.value)}
              variant={trend === t.value ? 'primary' : 'muted'}
            >
              {t.label}
            </RhythmButton>
          ))}
        </div>
      </Section>

      {trend && (
        <Section title="💬 CRE Suggestion">
          <p className="text-sm italic text-blue-700">{cre}</p>
        </Section>
      )}

      <div className="pt-4">
        <RhythmButton onClick={handleSubmit} variant="primary">
          ✅ Enter Rhythm
        </RhythmButton>
      </div>
    </div>
  )
}

export default RhythmCheckinPage
