// GoalInputPage.tsx

import React, { useState } from 'react';
import { saveRhythmGoal } from '../rhythmGoal';
import { useNavigate } from 'react-router-dom';
import GoalPathView from './GoalPathView';

const GoalInputPage: React.FC = () => {
  const [title, setTitle] = useState('');
  const [notes, setNotes] = useState('');
  const navigate = useNavigate();

  const handleSave = () => {
    if (!title.trim()) return;
    saveRhythmGoal({ title, notes, status: 'active' });
    navigate('/goals');
  };

  return (
    <div className="min-h-screen px-6 py-12 max-w-xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">🎯 Create a New Goal</h1>

      <div className="mb-4">
        <label className="block font-semibold mb-1">Goal Title</label>
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="w-full border px-3 py-2 rounded-lg"
          placeholder="e.g. Prepare for a product management interview"
        />
      </div>

      <div className="mb-4">
        <label className="block font-semibold mb-1">Notes (optional)</label>
        <textarea
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          className="w-full border px-3 py-2 rounded-lg"
          placeholder="Any thoughts, blockers, or inspirations?"
        />
      </div>

      <button
        onClick={handleSave}
        className="mt-4 px-6 py-2 bg-blue-500 text-white rounded-xl shadow"
      >
        ➕ Add Goal
      </button>

      {title.trim() && (
        <div className="mt-10 border-t pt-6">
          <GoalPathView goal={title.trim()} />
        </div>
      )}
    </div>
  );
};

export default GoalInputPage;

