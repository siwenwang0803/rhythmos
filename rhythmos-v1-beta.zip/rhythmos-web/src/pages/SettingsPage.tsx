// pages/SettingsPage.tsx

import React, { useState } from 'react'
import RhythmButton from '../components/ui/RhythmButton'
import Section from '../components/ui/Section'

const SettingsPage: React.FC = () => {
  const [cleared, setCleared] = useState(false)

  const handleClearData = () => {
    localStorage.clear()
    setCleared(true)
    setTimeout(() => window.location.reload(), 1500)
  }

  return (
    <div className="min-h-screen px-6 py-10 max-w-2xl mx-auto space-y-10">
      <h1 className="text-2xl font-bold text-gray-800">⚙️ System Settings</h1>
      <p className="text-sm text-gray-500">
        Adjust your rhythm preferences and reset behavior data.
      </p>

      <Section
        title="🧹 Reset System State"
        description="Clear all rhythm data, task logs, and tone feedback."
      >
        {!cleared ? (
          <RhythmButton onClick={handleClearData} variant="danger">
            ❌ Clear Local Data
          </RhythmButton>
        ) : (
          <p className="text-sm text-green-700 italic">All local data cleared. Reloading...</p>
        )}
      </Section>

      <Section
        title="🎨 CRE Style Override"
        description="Force a specific tone for your system prompts."
      >
        <div className="flex flex-wrap gap-2">
          {['directive', 'gentle', 'motivated', 'visionary'].map((tone) => (
            <RhythmButton
              key={tone}
              variant="secondary"
              onClick={() => {
                localStorage.setItem('creStyleOverride', tone)
                window.location.reload()
              }}
            >
              Use {tone}
            </RhythmButton>
          ))}
          <RhythmButton
            variant="muted"
            onClick={() => {
              localStorage.setItem('creStyleOverride', 'skip')
              window.location.reload()
            }}
          >
            ❎ Skip Override
          </RhythmButton>
        </div>
      </Section>
    </div>
  )
}

export default SettingsPage
