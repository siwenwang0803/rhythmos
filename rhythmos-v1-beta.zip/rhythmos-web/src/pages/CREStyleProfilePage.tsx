// CREStyleProfilePage.tsx (with selector)

import React from 'react';
import {
  generateCREStyleProfile,
  exportProfileAsJson,
  exportProfileAsMarkdown,
  downloadMarkdown
} from '../creStyleProfile';
import { getSignatureTrend } from '../signatureTrend';
import { getCREStyleTimeSeries } from '../creStyleTimeline';
import SignatureTrendChart from '../components/SignatureTrendChart';
import CREStyleRadarChart from '../components/CREStyleRadarChart';
import CREStyleTrendChart from '../components/CREStyleTrendChart';
import CREStyleSelector from '../components/CREStyleSelector';

const CREStyleProfilePage: React.FC = () => {
  const signature = JSON.parse(localStorage.getItem('rhythmSignature') || '{}');
  const profile = generateCREStyleProfile(signature);
  const trendChart = getCREStyleTimeSeries();
  const persona = profile.summary.current;
  const trendData = getSignatureTrend('stable', persona);

  return (
    <div className="min-h-screen px-6 py-10 max-w-3xl mx-auto text-left">
      <h1 className="text-2xl font-bold mb-4">🧠 My Rhythm Language Profile</h1>

      <p className="text-sm text-gray-600 mb-2">Most Used: <strong>{profile.summary.mostUsed}</strong></p>
      <p className="text-sm text-gray-600 mb-2">Most Effective: <strong>{profile.summary.mostEffective}</strong></p>
      <p className="text-sm text-gray-600 mb-2">Current Dominant: <strong>{profile.summary.current}</strong></p>
      {profile.summary.emerging && (
        <p className="text-sm text-yellow-700 mb-2">🌱 Emerging Style: <strong>{profile.summary.emerging}</strong> ({profile.summary.confidence}%)</p>
      )}
      <p className="text-sm text-gray-500 mb-6 italic">Override: {profile.summary.override}</p>

      <CREStyleRadarChart toneCounts={profile.toneCounts} />

      {trendChart.length > 0 && <CREStyleTrendChart data={trendChart} />}

      {trendData && trendData.timestamps.length > 0 && (
        <SignatureTrendChart data={trendData} persona={persona} />
      )}

      <CREStyleSelector />

      <div className="mt-6 space-y-2">
        <button
          onClick={() => exportProfileAsJson(profile)}
          className="px-4 py-2 text-sm bg-blue-600 text-white rounded"
        >
          ⬇️ Export JSON
        </button>

        <button
          onClick={() => {
            const md = exportProfileAsMarkdown(profile);
            downloadMarkdown(md);
          }}
          className="px-4 py-2 text-sm bg-green-600 text-white rounded"
        >
          📝 Export Markdown
        </button>
      </div>
    </div>
  );
};

export default CREStyleProfilePage;



