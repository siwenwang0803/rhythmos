// CREBatchGenerator.tsx (with ratings + helpfulness for batch samples)

import React, { useState } from 'react';
import { generateCRE } from '../creGenerator';

const taskTypes = ['minimal', 'light', 'normal', 'challenge'] as const;
const tones = ['gentle', 'directive', 'motivated', 'visionary'] as const;
const variants = ['base', 'metaphorical', 'concise', 'expansive'] as const;

const CREBatchGenerator: React.FC = () => {
  const [ratings, setRatings] = useState<Record<number, number>>({});
  const [helpfulness, setHelpfulness] = useState<Record<number, string>>({});

  const samples = taskTypes.flatMap((taskType) =>
    tones.flatMap((tone) =>
      variants.map((variant) => {
        const cre = generateCRE({ trend: 'stable', stage: 'initial', taskType, signature: {}, override: tone, variant });
        return { taskType, tone, variant, cre };
      })
    )
  );

  const handleRate = (index: number, score: number) => {
    setRatings((prev) => ({ ...prev, [index]: score }));
  };

  const handleHelp = (index: number, value: string) => {
    setHelpfulness((prev) => ({ ...prev, [index]: value }));
  };

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <h2 className="text-xl font-bold mb-4">🧪 CRE Batch Generator (64 Sample Grid)</h2>
      <table className="w-full text-sm border">
        <thead>
          <tr className="bg-gray-100">
            <th className="p-2 border">Task</th>
            <th className="p-2 border">Tone</th>
            <th className="p-2 border">Variant</th>
            <th className="p-2 border">CRE Output</th>
            <th className="p-2 border">⭐</th>
            <th className="p-2 border">👍👎</th>
          </tr>
        </thead>
        <tbody>
          {samples.map(({ taskType, tone, variant, cre }, i) => (
            <tr key={i}>
              <td className="p-2 border font-mono">{taskType}</td>
              <td className="p-2 border font-mono">{tone}</td>
              <td className="p-2 border font-mono">{variant}</td>
              <td className="p-2 border text-blue-800">{cre}</td>
              <td className="p-2 border">
                {[1, 2, 3, 4, 5].map((score) => (
                  <button
                    key={score}
                    onClick={() => handleRate(i, score)}
                    className={`px-1 text-sm ${ratings[i] === score ? 'text-yellow-500 font-bold' : 'text-gray-400'}`}
                  >
                    ⭐{score}
                  </button>
                ))}
              </td>
              <td className="p-2 border space-x-1">
                {['yes', 'no', 'skip'].map((val) => (
                  <button
                    key={val}
                    onClick={() => handleHelp(i, val)}
                    className={`px-1 text-sm rounded ${helpfulness[i] === val ? 'bg-yellow-300 text-black' : 'bg-gray-100'}`}
                  >
                    {val === 'yes' ? '👍' : val === 'no' ? '👎' : '🕒'}
                  </button>
                ))}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="mt-6">
        <button
          onClick={() => {
            const result = samples.map((sample, i) => ({
              ...sample,
              score: ratings[i] || 0,
              helpful: helpfulness[i] || 'unknown',
              timestamp: new Date().toISOString()
            }));

            const blob = new Blob([JSON.stringify(result, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'cre_batch_feedback.json';
            a.click();
            URL.revokeObjectURL(url);
          }}
          className="px-4 py-2 bg-green-600 text-white text-sm rounded"
        >
          ⬇️ Export Feedback (JSON)
        </button>
      </div>
    </div>
  );
};

export default CREBatchGenerator;

