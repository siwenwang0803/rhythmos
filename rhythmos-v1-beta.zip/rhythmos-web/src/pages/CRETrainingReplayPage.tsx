// pages/CRETrainingReplayPage.tsx

import React from 'react'
import Section from '../components/ui/Section'
import { generateCREReinforcementSummary } from '../logic/generateCREReinforcementSummary'
import CREVariantRankingTable from '../components/CREVariantRankingTable'
import variantData from '../data/cre-weighted-variant-output.json'
import { generateCREWeightedSet } from '../logic/generateCREWeightedSet'
import strategySummary from '../data/cre-strategy-summary-map.json'
import CREStrategySummaryMap from '../components/CREStrategySummaryMap'

interface Feedback {
  tone: string
  stage: string
  taskType: string
  variant: string
  score: number
  timestamp: number
}

const CRETrainingReplayPage: React.FC = () => {
  const raw = localStorage.getItem('creSampleRatings')
  const creSummary = generateCREReinforcementSummary()
  const ratings: Feedback[] = raw ? JSON.parse(raw) : []
  const variantData = generateCREWeightedSet()


  const sorted = ratings.sort((a, b) => b.timestamp - a.timestamp)

  return (
    <div className="min-h-screen px-6 py-10 max-w-3xl mx-auto space-y-10">
      <h1 className="text-2xl font-bold text-gray-800">📈 CRE Training Replay</h1>
      <p className="text-sm text-gray-500">See how your feedback has helped shape the system.</p>

      {sorted.length === 0 ? (
        <p className="text-sm text-gray-500 italic pt-6">No ratings submitted yet.</p>
      ) : (
        <div className="space-y-6">
          {sorted.map((entry, i) => (
            <Section
              key={i}
              title={`⭐ [${entry.score}] · ${entry.tone.toUpperCase()} · ${entry.stage} / ${entry.taskType}`}
            >
              <p className="text-sm text-gray-700 italic mb-2">"{entry.variant}"</p>
              <p className="text-xs text-gray-400">
                Rated on: {new Date(entry.timestamp).toLocaleString()}
              </p>
            </Section>
          ))}
        </div>
      )}

<Section title="🎯 CRE Style Reinforcement Summary">
  <p className="text-sm text-gray-700 mb-2">{creSummary.comment}</p>
  <p className="text-xs text-gray-500">
    Favorite tone: <strong>{creSummary.favoriteTone}</strong>
  </p>
</Section>

<Section title="🏆 CRE Variant Ranking">
  <CREVariantRankingTable data={variantData} />
</Section>

<Section title="🧭 CRE Strategy Summary">
  <p className="text-sm text-gray-500 mb-3">
    These are the top-rated expressions used in your system across tones and stages.
  </p>
  <CREStrategySummaryMap data={strategySummary.summary} />
</Section>

</div>
  )
}


export default CRETrainingReplayPage
