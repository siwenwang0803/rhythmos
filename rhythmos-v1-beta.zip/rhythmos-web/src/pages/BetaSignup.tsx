// pages/BetaSignup.tsx

import React, { useState } from 'react'
import RhythmButton from '../components/ui/RhythmButton'
import Section from '../components/ui/Section'

const BetaSignup: React.FC = () => {
  const [email, setEmail] = useState('')
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = () => {
    if (!email) return
    // simulate save (can later connect to backend or sheet)
    const existing = JSON.parse(localStorage.getItem('betaSignupEmails') || '[]')
    localStorage.setItem('betaSignupEmails', JSON.stringify([...existing, email]))
    setSubmitted(true)
  }

  return (
    <div className="min-h-screen px-6 py-10 max-w-md mx-auto space-y-10 text-center">
      <h1 className="text-2xl font-bold text-gray-800">🌍 Join the RhythmOS Beta</h1>
      <p className="text-sm text-gray-500">
        Sign up to get early access and help shape the future of rhythm-driven collaboration.
      </p>

      {!submitted ? (
        <Section title="📧 Email Signup" description="No spam. Just one rhythm update when we go live.">
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
            className="w-full px-4 py-2 text-sm border rounded shadow-sm mb-4"
          />
          <RhythmButton onClick={handleSubmit} variant="primary">
            ✅ Join the Waitlist
          </RhythmButton>
        </Section>
      ) : (
        <div className="text-green-700 text-sm bg-green-50 border border-green-300 p-4 rounded-xl">
          Thank you! You’ve been added to the rhythm beta waitlist.
        </div>
      )}

      <p className="text-xs text-gray-400 italic pt-10">Built from rhythm. Powered by CRE. Run by you.</p>
    </div>
  )
}

export default BetaSignup
