// pages/SharePage.tsx

import React from 'react'
import { useNavigate } from 'react-router-dom'
import RhythmButton from '../components/ui/RhythmButton'

const SharePage: React.FC = () => {
  const navigate = useNavigate()

  return (
    <div className="min-h-screen px-6 py-20 max-w-2xl mx-auto text-center space-y-12">
      <div className="space-y-4">
        <h1 className="text-3xl font-bold text-gray-900">🌱 Welcome to RhythmOS</h1>
        <p className="text-base text-gray-600 italic">
          This is not a to-do system.  
          This is a rhythm space for your mind.
        </p>
      </div>

      <div className="space-y-6">
        <RhythmButton
          variant="primary"
          onClick={() => navigate('/onboarding')}
        >
          ✅ Try Your Rhythm
        </RhythmButton>

        <p className="text-sm text-gray-500">Not sure where to begin?</p>

        <RhythmButton
          variant="muted"
          onClick={() => navigate('/journey')}
        >
          🌿 View Rhythm Journey
        </RhythmButton>

        <div className="pt-6 space-y-1 text-sm text-gray-500">
          <p>💡 All your data is saved locally.</p>
          <p>🧠 You don’t need to perform. You just need to show up.</p>
        </div>
      </div>

      <div className="pt-16 text-xs text-gray-400 italic">
        v1.0 Beta • CRE-powered rhythm engine
      </div>
    </div>
  )
}

export default SharePage
