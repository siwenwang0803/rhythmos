// pages/SystemExportPage.tsx

import React from 'react'
import RhythmButton from '../components/ui/RhythmButton'
import Section from '../components/ui/Section'

const SystemExportPage: React.FC = () => {
  const exportAll = () => {
    const data = {
      goals: localStorage.getItem('rhythmGoals'),
      subtasks: localStorage.getItem('rhythmSubtasks'),
      feedback: localStorage.getItem('taskFeedbackLog'),
      ratings: localStorage.getItem('creSampleRatings'),
      signature: localStorage.getItem('rhythmSignature')
    }

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)

    const link = document.createElement('a')
    link.href = url
    link.download = 'rhythmOS-export.json'
    link.click()

    URL.revokeObjectURL(url)
  }

  return (
    <div className="min-h-screen px-6 py-10 max-w-2xl mx-auto space-y-10">
      <h1 className="text-2xl font-bold text-gray-800">📦 Export Your RhythmOS System</h1>
      <p className="text-sm text-gray-500">
        Download your current goals, CRE data, feedback, and signatures as a single archive file.
      </p>

      <Section title="📁 Export Everything">
        <RhythmButton onClick={exportAll} variant="primary">
          ⬇️ Download rhythmOS-export.json
        </RhythmButton>
      </Section>
    </div>
  )
}

export default SystemExportPage
