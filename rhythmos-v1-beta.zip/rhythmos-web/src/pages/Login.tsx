// pages/Login.tsx

import React from 'react'
import { useNavigate } from 'react-router-dom'
import RhythmButton from '../components/ui/RhythmButton'

const Login: React.FC = () => {
  const navigate = useNavigate()

  const handleGuestLogin = () => {
    // optional: set demo session, log state, etc.
    navigate('/goals') // redirect to main app
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 px-6 py-12">
      <div className="max-w-md w-full space-y-8 p-6 bg-white shadow rounded-xl text-center">
        <h1 className="text-2xl font-bold text-gray-800">🎵 Welcome to RhythmOS</h1>
        <p className="text-sm text-gray-500">Your journey begins with rhythm, not pressure.</p>

        <div className="mt-6">
          <RhythmButton onClick={handleGuestLogin} variant="primary">
            🚀 Enter as Guest
          </RhythmButton>
        </div>

        <p className="text-xs text-gray-400 mt-4 italic">Authentication coming soon...</p>
      </div>
    </div>
  )
}

export default Login
