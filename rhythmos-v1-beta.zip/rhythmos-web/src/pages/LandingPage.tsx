// pages/LandingPage.tsx (patched for minimal rhythm-based entry)

import React from 'react'
import { useNavigate } from 'react-router-dom'
import RhythmButton from '../components/ui/RhythmButton'

const LandingPage: React.FC = () => {
  const navigate = useNavigate()

  return (
    <div className="min-h-screen px-6 py-20 max-w-2xl mx-auto text-center space-y-12">
      <div className="space-y-4">
        <h1 className="text-4xl font-bold text-gray-900 tracking-tight">🎧 RhythmOS</h1>
        <p className="text-lg text-gray-600 italic">
          This is not a to-do app.  
          This is your rhythm.
        </p>
      </div>

      <div className="space-y-6">
        <RhythmButton
          variant="primary"
          onClick={() => navigate('/onboarding')}
        >
          ✅ Try Rhythm
        </RhythmButton>

        <p className="text-sm text-gray-500">Not sure where to begin?</p>

        <RhythmButton
          variant="muted"
          onClick={() => navigate('/journey')}
        >
          🌿 View Journey
        </RhythmButton>
      </div>

      <div className="pt-16 text-xs text-gray-400 italic">
        Built for rhythm-based living. v1.0 Beta
      </div>
    </div>
  )
}

export default LandingPage

