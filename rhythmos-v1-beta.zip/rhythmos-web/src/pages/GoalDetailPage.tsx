// GoalDetailPage.tsx (with CRE Generator Output integration)

import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getRhythmGoals } from '../rhythmGoal';
import { getSubtasksForGoal } from '../rhythmSubtasks';
import { getRhythmTrend, getRecentRhythmLogs } from '../rhythmLog';
import { recommendSubtask } from '../taskRecommender';
import { markSubtaskComplete } from '../taskUpdater';
import { updateRhythmScore } from '../rhythmScore';
import { updateRhythmSignature } from '../rhythmSignature';
import { getStrategyFromTrend } from '../rhythmStrategy';
import { getGoalRhythmStage } from '../goalProgress';
import { getCREJourneyPrompt } from '../creJourneyPrompt';
import { getNextTaskMode } from '../rhythmScheduler';
import { getBestPersonaForTrend, getPersonaRanking } from '../signatureAnalyzer';
import { getSignatureTrend } from '../signatureTrend';
import { getCREStyleUsage, getStyleMigrationTrend } from '../creStyleUsage';
import { getPersonalizedCRE } from '../creTuner';
import { generateCREStyleProfile } from '../creStyleProfile';
import { exportProfileAsJson, exportProfileAsMarkdown, downloadMarkdown } from '../creStyleProfile';
import { generateCREOutput } from '../outputRouter';
import SignatureMapView from '../components/SignatureMapView';
import SignatureTrendChart from '../components/SignatureTrendChart';
import CREStyleRadarChart from '../components/CREStyleRadarChart';
import CREStyleTrendChart from '../components/CREStyleTrendChart';
import CREStyleSelector from '../components/CREStyleSelector';
import { getCREStyleTimeSeries } from '../creRatingStats'
import RhythmPathView from '../components/RhythmPathView';
import NextStepSuggestion from '../components/NextStepSuggestion';
import TaskTimelineChart from '../components/TaskTimelineChart';
import { generateRhythmGoalPath } from '../logic/generateRhythmGoalPath'

const GoalDetailPage: React.FC = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const [showCRE, setShowCRE] = useState(false);
  const [completedSuggestion, setCompletedSuggestion] = useState('');

  const goals = getRhythmGoals();
  const goal = goals.find((g) => g.id === id);
  const subtasks = id ? getSubtasksForGoal(id) : [];

  const recent = getRecentRhythmLogs(5);
  const trend = getRhythmTrend(recent);
  const stage = id ? getGoalRhythmStage(id) : 'initial';
  const strategy = getStrategyFromTrend(trend);
  const recommended = id ? recommendSubtask(subtasks, trend, id) : null;
  const journeyHint = getCREJourneyPrompt(stage, trend);
  const steps = generateRhythmGoalPath('write a blog post', 'collapsed')

  const completedCount = subtasks.filter(t => t.status === 'completed').length;
  const totalCount = subtasks.length;
  const progressPercent = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  const taskMode = getNextTaskMode(trend, stage, progressPercent);

  const signature = JSON.parse(localStorage.getItem('rhythmSignature') || '{}');
  const bestPersona = getBestPersonaForTrend(trend, signature);
  const ranking = getPersonaRanking(trend, signature);
  const trendData = bestPersona
    ? getSignatureTrend(trend, bestPersona.persona)
    : { timestamps: [], scores: [] };

  const styleUsage = getCREStyleUsage(signature);
  const migration = getStyleMigrationTrend(signature);
  const profile = generateCREStyleProfile(signature);

  const cre = generateCREOutput({
    trend,
    stage,
    taskType: recommended?.difficulty || 'normal',
    signature
  });

  if (!goal) {
    return <p className="text-red-600">Goal not found.</p>;
  }

  const handleComplete = () => {
    if (!recommended) return;
    markSubtaskComplete(recommended.id);
    const { score } = updateRhythmScore('complete');
    updateRhythmSignature(trend, strategy.persona, 'complete', score);
    setCompletedSuggestion(cre);
    setShowCRE(true);
    setTimeout(() => window.location.reload(), 2000);
  };

  return (
    <div className="min-h-screen px-6 py-10 max-w-3xl mx-auto text-left">
      <h1 className="text-2xl font-bold mb-4">🎯 {goal.title}</h1>
      {goal.notes && <p className="text-sm text-gray-600 mb-4">{goal.notes}</p>}

      <div className="mb-6 p-4 border-l-4 border-blue-400 bg-blue-50 rounded">
        <p className="text-sm text-gray-500 mb-1">🌡️ Trend: <strong>{trend}</strong> | Stage: <strong>{stage}</strong></p>
        <p className="text-sm text-gray-500">📈 Progress: <strong>{progressPercent}%</strong></p>
        <p className="text-sm text-blue-700 italic">💬 {journeyHint}</p>

        {bestPersona && (
          <p className="text-sm mt-1 text-gray-700">
            🤝 Based on your past actions in this state, <strong>{bestPersona.persona}</strong> has worked best for you.
          </p>
        )}

        {ranking.length > 1 && (
          <div className="mt-3 text-sm text-gray-600">
            <p className="mb-1 font-semibold">📊 CRE Effectiveness Ranking (this trend):</p>
            <ul className="list-disc list-inside space-y-1">
              {ranking.map((item, i) => (
                <li key={item.persona}>
                  #{i + 1} — <strong>{item.persona}</strong> (Avg Score: {item.avgScore.toFixed(2)}, Uses: {item.total})
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>

      {trendData && trendData.timestamps.length > 0 && bestPersona && (
        <SignatureTrendChart data={trendData} persona={bestPersona.persona} />
      )}

      <CREStyleRadarChart toneCounts={profile.toneCounts} />
      <CREStyleTrendChart data={getCREStyleTimeSeries()} />
      <CREStyleSelector />

      {migration.shouldSwitch && migration.emerging && (
        <div className="mt-6 p-4 bg-yellow-50 border-l-4 border-yellow-400 rounded space-y-2">
          <p className="text-sm text-yellow-700">
            🌀 You’ve been gradually shifting toward a more <strong>{migration.emerging}</strong> tone.
          </p>
          <p className="text-xs text-gray-500">Confidence: {migration.confidence}%</p>
          <p className="text-xs text-gray-600 italic">Would you like us to adapt your rhythm guidance accordingly in future sessions?</p>
          <div className="flex gap-3 mt-2 text-sm">
            <button
              onClick={() => localStorage.setItem('creStyleOverride', migration.emerging)}
              className="px-3 py-1 rounded bg-green-500 text-white"
            >
              ✅ Yes, adopt it
            </button>
            <button
              onClick={() => localStorage.removeItem('creStyleOverride')}
              className="px-3 py-1 rounded bg-gray-300 text-black"
            >
              ❌ No, stay current
            </button>
            <button
              onClick={() => localStorage.setItem('creStyleOverride', 'skip')}
              className="px-3 py-1 rounded bg-yellow-200 text-black"
            >
              🕒 Skip for now
            </button>
          </div>
        </div>
      )}

      <RhythmPathView
        subtasks={subtasks}
        recommendedId={recommended?.id}
        trend={trend}
        stage={stage}
      />

      {showCRE && (
        <div className="mt-4 p-3 border rounded-lg bg-green-50">
          <p className="text-sm text-green-700 italic">{completedSuggestion}</p>
        </div>
      )}

      <SignatureMapView data={signature} />
      <TaskTimelineChart />

      <NextStepSuggestion
        goalId={id || ''}
        trend={trend}
        subtasks={subtasks}
        onAccept={(step) => {
          markSubtaskComplete(step.id);
          const { score } = updateRhythmScore('complete');
          updateRhythmSignature(trend, strategy.persona, 'complete', score);
          navigate(0); // reload page
        }}
      />
      

      <div className="mt-6 space-y-2">
        <button
          onClick={() => exportProfileAsJson(profile)}
          className="px-4 py-2 text-sm bg-blue-600 text-white rounded"
        >
          ⬇️ Export JSON
        </button>

        <button
          onClick={() => {
            const md = exportProfileAsMarkdown(profile);
            downloadMarkdown(md);
          }}
          className="px-4 py-2 text-sm bg-green-600 text-white rounded"
        >
          📝 Export Markdown
        </button>
      </div>

      <div className="mt-10">
        <button
          onClick={() => navigate('/goals')}
          className="px-5 py-2 bg-gray-200 text-black rounded-xl shadow"
        >
          ← Back to All Goals
        </button>
      </div>
    </div>
  );
};

export default GoalDetailPage;







