// pages/RhythmJournalPage.tsx (patched for collapsed fallback flow)

import React, { useState } from 'react'
import RhythmButton from '../components/ui/RhythmButton'
import Section from '../components/ui/Section'
import { generateCREOutput } from '../outputRouter'
import { updateRhythmScore } from '../rhythmScore'
import { updateRhythmSignature } from '../rhythmSignature'
import { getCollapsedReplayFeedback } from '../logic/getCollapsedReplayFeedback'

const RhythmJournalPage: React.FC = () => {
  const [entry, setEntry] = useState('')
  const [submitted, setSubmitted] = useState(false)

  const trend =
    JSON.parse(localStorage.getItem('lastTrend') || '"wavy"') as
      | 'collapsed'
      | 'wavy'
      | 'stable'
      | 'rising'

  const signature = JSON.parse(localStorage.getItem('rhythmSignature') || '{}')

  const cre = generateCREOutput({
    trend,
    stage: 'initial',
    taskType: 'light',
    signature
  }).cre

  const handleSubmit = () => {
    if (!entry) return

    const journalEntry = {
      text: entry,
      timestamp: Date.now(),
      trend
    }

    const existing = JSON.parse(localStorage.getItem('rhythmJournal') || '[]')
    localStorage.setItem('rhythmJournal', JSON.stringify([...existing, journalEntry]))

    const { score } = updateRhythmScore(trend)
    updateRhythmSignature(trend, 'auto', 'complete', score)
    setSubmitted(true)
  }
  const replay = getCollapsedReplayFeedback()


  return (
    <div className="min-h-screen px-6 py-10 max-w-2xl mx-auto space-y-8">
      <h1 className="text-2xl font-bold text-gray-800">🪞 Rhythm Reflection</h1>

      {trend === 'collapsed' && (
        <div className="p-3 bg-yellow-50 border-l-4 border-yellow-400 rounded-xl text-sm text-yellow-700">
          ⚠️ You’re in a collapsed state. Don’t push. Let one paragraph be your win today.
        </div>
      )}
      {replay && (
  <p className="text-xs text-gray-500 mt-3 italic">{replay}</p>
)}


      <Section title="💬 CRE Cue">
        <p className="text-sm italic text-blue-700">“{cre}”</p>
      </Section>

      {!submitted ? (
        <Section title="✍️ Write something small">
          <textarea
            value={entry}
            onChange={(e) => setEntry(e.target.value)}
            rows={6}
            className="w-full px-4 py-2 text-sm border rounded shadow-sm"
            placeholder="Write your thoughts or feelings here..."
          />
          <div className="pt-4">
            <RhythmButton onClick={handleSubmit} variant="primary">
              ✅ Save Reflection
            </RhythmButton>
          </div>
        </Section>
      ) : (
        <div className="text-green-700 text-sm bg-green-50 border border-green-300 p-4 rounded-xl">
          That’s enough. You’ve begun. Let rhythm grow from here.
        </div>
      )}
    </div>
  )
}

export default RhythmJournalPage

