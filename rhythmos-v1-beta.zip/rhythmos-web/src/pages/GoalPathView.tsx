// GoalPathView.tsx (with feedback buttons, based on your current structure)

import React from 'react';
import { generateRhythmGoalPath } from '../rhythmGoalGenerator';
import { generateCREOutput } from '../outputRouter';
import { markTaskComplete } from '../taskUpdater';

const FEEDBACK_OPTIONS = [
  { label: '✔️ Completed', score: 5 },
  { label: '👌 Tried', score: 3 },
  { label: '⚪ Skipped', score: 1 }
];

const GoalPathView: React.FC<{ goal: string }> = ({ goal }) => {
  const path = generateRhythmGoalPath(goal);

  return (
    <div className="mt-6 space-y-6">
      <h3 className="text-md font-semibold text-gray-800">🎯 Rhythm Task Path for: {goal}</h3>
      <div className="space-y-4">
        {path.map((step, index) => {
          const { cre } = generateCREOutput({
            trend: 'stable',
            stage: index === 0 ? 'initial' : index === path.length - 1 ? 'final' : 'middle',
            taskType: step.difficulty as any,
            signature: JSON.parse(localStorage.getItem('rhythmSignature') || '{}')
          });

          return (
            <div key={index} className="p-4 border rounded-xl bg-white">
              <p className="text-sm text-gray-500">Step {index + 1} · {step.intent} · {step.difficulty}</p>
              <p className="text-base text-black font-semibold mt-1">📝 {step.task}</p>
              <p className="text-xs text-blue-700 italic mt-2">{cre}</p>

              <div className="flex gap-3 mt-3">
                {FEEDBACK_OPTIONS.map(option => (
                  <button
                    key={option.label}
                    className="px-3 py-1 rounded-full bg-gray-100 hover:bg-gray-200 text-xs"
                    onClick={() => markTaskComplete(step.task, option.score)}
                  >
                    {option.label}
                  </button>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default GoalPathView;


