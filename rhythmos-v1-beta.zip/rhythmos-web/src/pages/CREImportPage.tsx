// pages/CREImportPage.tsx

import React, { useState } from 'react'
import Section from '../components/ui/Section'
import RhythmButton from '../components/ui/RhythmButton'
import { creVariants } from '../cre/creVariantRegistry'

const CREImportPage: React.FC = () => {
  const [status, setStatus] = useState<string | null>(null)

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onload = () => {
      try {
        const json = JSON.parse(reader.result as string)

        if (!json.variants) {
          setStatus('❌ Invalid file structure.')
          return
        }

        // Overwrite current variant registry in localStorage (future: backend)
        localStorage.setItem('creVariantLibrary', JSON.stringify(json.variants))
        setStatus('✅ CRE variant library imported successfully.')
      } catch {
        setStatus('❌ Failed to parse JSON.')
      }
    }

    reader.readAsText(file)
  }

  return (
    <div className="min-h-screen px-6 py-10 max-w-xl mx-auto space-y-10">
      <h1 className="text-2xl font-bold text-gray-800">📥 Import CRE Variant Library</h1>
      <p className="text-sm text-gray-500">
        Load new CRE tone × stage × taskType structure into your system.
      </p>

      <Section title="📂 Upload JSON">
        <input type="file" accept=".json" onChange={handleImport} />
        {status && <p className="text-sm text-blue-600 mt-3">{status}</p>}
      </Section>

      <Section title="ℹ️ How It Works">
        <ul className="list-disc list-inside text-sm text-gray-600 space-y-1">
          <li>This will override your current variant registry.</li>
          <li>The data will be stored locally (no backend yet).</li>
          <li>To apply permanently, refresh the app or rerun training mode.</li>
        </ul>
      </Section>

      <div className="pt-6 text-xs text-gray-400 text-center italic">
        Rhythm learns to speak through your language.
      </div>
    </div>
  )
}

export default CREImportPage
