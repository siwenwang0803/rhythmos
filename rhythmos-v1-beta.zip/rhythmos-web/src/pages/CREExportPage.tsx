// pages/CREExportPage.tsx

import React from 'react'
import Section from '../components/ui/Section'
import RhythmButton from '../components/ui/RhythmButton'
import { downloadCRELibrary } from '../logic/exportCRELibrary'
import { downloadCRERatings } from '../logic/exportCRERatings'

const CREExportPage: React.FC = () => {
  return (
    <div className="min-h-screen px-6 py-10 max-w-xl mx-auto space-y-10">
      <h1 className="text-2xl font-bold text-gray-800">📤 CRE Data Export</h1>
      <p className="text-sm text-gray-500">Export your rhythm system's full language engine.</p>

      <Section title="📚 Export Full Variant Library">
        <p className="text-sm text-gray-500 mb-3">Includes all tone × stage × taskType variants.</p>
        <RhythmButton variant="primary" onClick={downloadCRELibrary}>
          ⬇️ Download cre-variant-library.json
        </RhythmButton>
      </Section>

      <Section title="⭐ Export Variant Ratings">
        <p className="text-sm text-gray-500 mb-3">
          Includes all feedback you've submitted through rating panel.
        </p>
        <RhythmButton variant="secondary" onClick={downloadCRERatings}>
          ⬇️ Download cre-variant-feedback.json
        </RhythmButton>
      </Section>

      <div className="pt-6 text-xs text-center text-gray-400 italic">
        Rhythm isn’t just words—it’s how the system speaks back.
      </div>
    </div>
  )
}

export default CREExportPage
