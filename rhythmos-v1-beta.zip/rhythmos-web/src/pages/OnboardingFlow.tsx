// pages/OnboardingFlow.tsx (rewritten with language-based rhythm check-in)

import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import Section from '../components/ui/Section'
import RhythmButton from '../components/ui/RhythmButton'
import { generateCREOutput } from '../outputRouter'

type RhythmTrend = 'collapsed' | 'wavy' | 'stable' | 'rising'

interface TrendOption {
  label: string
  description: string
  trend: RhythmTrend
  icon: string
}

const trendOptions: TrendOption[] = [
  {
    icon: '🫥',
    label: 'Blocked',
    description: 'I feel stuck. I want to try, but I don’t know where to begin.',
    trend: 'collapsed'
  },
  {
    icon: '🌊',
    label: 'Scattered',
    description: 'I’ve been bouncing around, and I want to get into flow.',
    trend: 'wavy'
  },
  {
    icon: '⚖️',
    label: 'Ready but soft',
    description: 'I can focus, I just need to start with something light.',
    trend: 'stable'
  },
  {
    icon: '🔥',
    label: 'Energized',
    description: 'I feel ready. Give me something to push into.',
    trend: 'rising'
  }
]

const OnboardingFlow: React.FC = () => {
  const navigate = useNavigate()
  const [trend, setTrend] = useState<RhythmTrend | null>(null)
  const [goal, setGoal] = useState('')
  const signature = JSON.parse(localStorage.getItem('rhythmSignature') || '{}')

  const crePreview =
    trend &&
    generateCREOutput({
      trend,
      stage: 'initial',
      taskType: trend === 'rising' ? 'challenge' : trend === 'stable' ? 'normal' : 'light',
      signature
    }).cre

  const handleStart = () => {
    const finalTrend = trend || JSON.parse(localStorage.getItem('lastTrend') || '"wavy"')
    localStorage.setItem('lastTrend', JSON.stringify(finalTrend))

    if (goal) {
      const goalObj = {
        id: Date.now().toString(),
        title: goal,
        notes: '',
        createdAt: Date.now(),
        status: 'active'
      }
      const goals = JSON.parse(localStorage.getItem('rhythmGoals') || '[]')
      localStorage.setItem('rhythmGoals', JSON.stringify([...goals, goalObj]))
    }

    if (finalTrend === 'collapsed') {
      navigate('/journal')
    } else {
      navigate('/goals')
    }
  }

  return (
    <div className="min-h-screen px-6 py-10 max-w-xl mx-auto space-y-10">
      <h1 className="text-2xl font-bold text-gray-800">🎧 What best describes your rhythm today?</h1>
      <p className="text-sm text-gray-500">Pick the description that resonates with how you feel.</p>

      <Section title="🌡️ Select your rhythm description">
        <div className="space-y-4">
          {trendOptions.map((opt) => (
            <button
              key={opt.trend}
              onClick={() => setTrend(opt.trend)}
              className={`w-full text-left px-4 py-3 rounded-xl shadow-sm border text-sm ${
                trend === opt.trend
                  ? 'bg-blue-50 border-blue-400 text-blue-800'
                  : 'bg-white border-gray-300 hover:bg-gray-50'
              }`}
            >
              <div className="font-semibold mb-1">
                {opt.icon} {opt.label}
              </div>
              <p className="text-gray-600">{opt.description}</p>
            </button>
          ))}

          <button
            onClick={() => setTrend(null)}
            className="text-sm mt-3 text-blue-600 underline"
          >
            ❓ I’m not sure — let RhythmOS suggest
          </button>
        </div>
      </Section>

      <Section title="💬 Suggested CRE Preview">
        {trend && crePreview ? (
          <p className="text-blue-700 italic text-sm">“{crePreview}”</p>
        ) : (
          <p className="text-gray-400 text-sm italic">CRE tone will adjust once you begin.</p>
        )}
      </Section>

      <Section title="🎯 What’s your intention today?">
        <input
          type="text"
          value={goal}
          onChange={(e) => setGoal(e.target.value)}
          className="w-full px-4 py-2 text-sm border rounded shadow-sm"
          placeholder="e.g. Plan my day, clear inbox, write a page..."
        />
      </Section>

      <div className="pt-6">
        <RhythmButton onClick={handleStart} variant="primary">
          ✅ Begin Rhythm
        </RhythmButton>
      </div>
    </div>
  )
}

export default OnboardingFlow



