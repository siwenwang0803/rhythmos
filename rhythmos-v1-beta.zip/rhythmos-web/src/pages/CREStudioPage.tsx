// 🔧 Patch CREStudioPage.tsx｜接入 <CRESuggestionPanel />

import React, { useState } from 'react'
import { creVariants } from '../cre/creVariantRegistry'
import Section from '../components/ui/Section'
import CRESuggestionPanel from '../components/CRESuggestionPanel'
import mockSuggestions from '../data/mock-cre-suggestions.json'
import ToneWarning from '../components/ToneWarning'
const CREStudioPage: React.FC = () => {
  const [selectedTone, setSelectedTone] = useState('gentle')
  const [suggestions, setSuggestions] = useState<string[]>([])
  const [newLines, setNewLines] = useState<Record<string, string>>({})

  const toneOptions = Object.keys(creVariants)

  const handleAdd = (stage: string, taskType: string) => {
    const text = newLines[`${stage}-${taskType}`]
    if (!text) return
    const variants = creVariants[selectedTone][stage]?.[taskType] || []
    variants.push(text)
    setNewLines({ ...newLines, [`${stage}-${taskType}`]: '' })
  }

  const handleAcceptSuggestion = (line: string, stage: string, taskType: string) => {
    const variants = creVariants[selectedTone][stage]?.[taskType] || []
    variants.push(line)
    setSuggestions(suggestions.filter((s) => s !== line))
  }
  const trend = JSON.parse(localStorage.getItem('lastTrend') || '"stable"')

  const handleGenerateSuggestions = () => {
    // Replace this with LLM API in the future
    const mock = [
      'Begin with rhythm, not pressure.',
      'Let this moment set your tone.',
      'One step, one breath. That’s rhythm.',
      'You’re not late. You’re entering.',
      'Flow is better than force.'
    ]
    setSuggestions(mock)
    setSuggestions(mockSuggestions.suggestions)
  }

  return (
    <div className="min-h-screen px-6 py-10 max-w-4xl mx-auto space-y-10">
      <h1 className="text-2xl font-bold text-gray-800">✍️ CRE Studio</h1>
      <ToneWarning trend={trend} />
      <p className="text-sm text-gray-500">Craft and explore the system’s rhythm language.</p>

      <Section title="🎨 Select Tone to Edit">
        <div className="flex flex-wrap gap-3">
          {toneOptions.map((tone) => (
            <button
              key={tone}
              onClick={() => setSelectedTone(tone)}
              className={`px-3 py-1 text-sm rounded ${
                tone === selectedTone
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
              }`}
            >
              {tone}
            </button>
          ))}
        </div>
      </Section>

      <Section title={`🧱 Editing: ${selectedTone}`}>
        {Object.entries(creVariants[selectedTone] || {}).map(([stage, stageBlock]) => (
          <div key={stage} className="mb-4">
            <p className="text-xs font-medium text-gray-500 uppercase mb-1">Stage: {stage}</p>
            {Object.entries(stageBlock || {}).map(([taskType, variants]) => (
              <div key={taskType} className="mb-5">
                <p className="text-xs font-semibold text-gray-600 mb-1">
                  Task Type: {taskType}
                </p>
                <ul className="list-disc ml-5 text-sm text-gray-700 space-y-1">
                  {variants.map((v, i) => (
                    <li key={i} className="italic">{v}</li>
                  ))}
                </ul>
                <div className="flex items-center gap-2 mt-2">
                  <input
                    type="text"
                    value={newLines[`${stage}-${taskType}`] || ''}
                    onChange={(e) =>
                      setNewLines({ ...newLines, [`${stage}-${taskType}`]: e.target.value })
                    }
                    placeholder="Add new line..."
                    className="text-sm px-2 py-1 border rounded w-full"
                  />
                  <button
                    className="text-xs bg-blue-500 text-white px-3 py-1 rounded"
                    onClick={() => handleAdd(stage, taskType)}
                  >
                    Add
                  </button>
                  <button
                    className="text-xs text-blue-500 underline"
                    onClick={handleGenerateSuggestions}
                  >
                    Suggest CRE
                  </button>
                </div>

                {suggestions.length > 0 && (
                  <div className="mt-4">
                    <CRESuggestionPanel
                      suggestions={suggestions}
                      onAccept={(line) => handleAcceptSuggestion(line, stage, taskType)}
                    />
                  </div>
                )}
              </div>
            ))}
          </div>
        ))}
      </Section>
    </div>
  )
}

export default CREStudioPage

