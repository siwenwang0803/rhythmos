// pages/LaunchPrepPage.tsx

import React from 'react'
import RhythmButton from '../components/ui/RhythmButton'
import Section from '../components/ui/Section'
import { useNavigate } from 'react-router-dom'

const LaunchPrepPage: React.FC = () => {
  const navigate = useNavigate()

  return (
    <div className="min-h-screen px-6 py-10 max-w-3xl mx-auto space-y-12">
      <h1 className="text-2xl font-bold text-gray-800">🚀 Launch Readiness Checklist</h1>
      <p className="text-sm text-gray-500">
        Final checklist before deploying RhythmOS to beta testers and the world.
      </p>

      <Section title="✅ System Features Completed">
        <ul className="list-disc list-inside text-sm text-gray-600 space-y-1">
          <li>🎯 CRE Generator + Output Router</li>
          <li>📊 Strategy Feedback System + Variant Sorter</li>
          <li>🧭 Rhythm Goal Generator + Task Path Engine</li>
          <li>🪞 Growth Map + CRE Style Trend + Signature Maps</li>
          <li>🛠️ CRE Tuner + Feedback Trainer</li>
        </ul>
      </Section>

      <Section title="🎨 UI System Ready">
        <ul className="list-disc list-inside text-sm text-gray-600 space-y-1">
          <li>📦 Unified Buttons: Primary / Secondary / Muted</li>
          <li>🧱 Cards, Badges, Headers standardized</li>
          <li>🔄 Consistent Tone Styles + CRE Rhythm Color Palette</li>
          <li>🌱 Onboarding Flow + Login Page + Empty State Flows</li>
        </ul>
      </Section>

      <Section title="🧪 Ready for Public Landing Page + Preview Access">
        <p className="text-sm text-gray-600 mb-3">
          You can now connect the landing page to onboarding, login, and preview directly.
        </p>
        <div className="flex flex-wrap gap-4">
          <RhythmButton onClick={() => navigate('/')} variant="primary">
            🌐 Go to Landing Page
          </RhythmButton>
          <RhythmButton onClick={() => navigate('/onboarding')} variant="secondary">
            🎧 Test Onboarding Flow
          </RhythmButton>
          <RhythmButton onClick={() => navigate('/cre-preview')} variant="muted">
            🎯 Preview Strategy System
          </RhythmButton>
        </div>
      </Section>

      <div className="pt-10">
        <p className="text-xs text-gray-400 italic">Built from rhythm. Ready for the world.</p>
      </div>
    </div>
  )
}

export default LaunchPrepPage
