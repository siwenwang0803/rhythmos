// pages/CRELibraryPage.tsx

import React from 'react'
import { creVariants } from '../cre/creVariantRegistry'
import Section from '../components/ui/Section'

const CRELibraryPage: React.FC = () => {
  return (
    <div className="min-h-screen px-6 py-10 max-w-4xl mx-auto space-y-10">
      <h1 className="text-2xl font-bold text-gray-800">📚 CRE Library</h1>
      <p className="text-sm text-gray-500">
        Explore all current CRE variants across tone, task type, and stage.
      </p>

      {Object.entries(creVariants).map(([tone, toneData]) => (
        <Section key={tone} title={`🎨 Tone: ${tone}`}>
          {Object.entries(toneData).map(([stage, stageBlock]) => (
            <div key={stage} className="mb-4">
              <p className="text-xs font-medium text-gray-500 uppercase mb-1">Stage: {stage}</p>
              {Object.entries(stageBlock || {}).map(([taskType, variants]) => (
                <div key={taskType} className="mb-3">
                  <p className="text-xs font-semibold text-gray-600 mb-1">
                    Task Type: {taskType}
                  </p>
                  <ul className="list-disc ml-5 text-sm text-gray-700 space-y-1">
                    {variants.map((v, i) => (
                      <li key={i} className="italic">{v}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          ))}
        </Section>
      ))}
    </div>
  )
}

export default CRELibraryPage
