// pages/ExperienceMapPage.tsx

import React from 'react'
import Section from '../components/ui/Section'
import RhythmButton from '../components/ui/RhythmButton'
import { useNavigate } from 'react-router-dom'

const ExperienceMapPage: React.FC = () => {
  const navigate = useNavigate()

  return (
    <div className="min-h-screen px-6 py-10 max-w-3xl mx-auto space-y-10">
      <h1 className="text-2xl font-bold text-gray-800">🧭 RhythmOS · Experience Flow Map</h1>
      <p className="text-sm text-gray-500">
        This map shows how each rhythm entry, system feedback, and CRE module flow together.
      </p>

      <Section title="🎧 Rhythm Start → Task Path">
        <ul className="list-disc list-inside text-sm text-gray-600 space-y-1">
          <li>
            🌱{' '}
            <span className="font-medium">Landing Page</span> →{' '}
            <code className="text-blue-600">/rhythm</code>
          </li>
          <li>
            🎯{' '}
            <span className="font-medium">Goal + Rhythm Type Input</span> → CRE + Signature
          </li>
          <li>
            🔀{' '}
            <span className="font-medium">System Routing:</span>{' '}
            <span className="italic">collapsed/wavy → preview</span>,{' '}
            <span className="italic">stable/rising → goals</span>
          </li>
        </ul>
      </Section>

      <Section title="📈 Behavior → Feedback → Growth">
        <ul className="list-disc list-inside text-sm text-gray-600 space-y-1">
          <li>✅ User marks task step as Completed / Tried / Skipped</li>
          <li>📊 Score stored → CRE variant strategy trained</li>
          <li>🧬 Signature + Strategy logs updated</li>
          <li>🌱 Growth map visualized via /growth-map</li>
        </ul>
      </Section>

      <Section title="🧪 Micro-tuning + Export Tools">
        <ul className="list-disc list-inside text-sm text-gray-600 space-y-1">
          <li>⚙️ Strategy Trainer (manual feedback boost)</li>
          <li>📦 Export JSON → Personal rhythm archive</li>
          <li>🧹 Settings → Style override + full reset</li>
        </ul>
      </Section>

      <Section title="🗺️ Explore Any Stage">
        <div className="grid grid-cols-2 gap-3">
          <RhythmButton onClick={() => navigate('/rhythm')} variant="primary">
            Start My Rhythm
          </RhythmButton>
          <RhythmButton onClick={() => navigate('/goals')} variant="secondary">
            My Goal Path
          </RhythmButton>
          <RhythmButton onClick={() => navigate('/growth-map')} variant="muted">
            Growth Map
          </RhythmButton>
          <RhythmButton onClick={() => navigate('/cre-preview')} variant="muted">
            Strategy Preview
          </RhythmButton>
        </div>
      </Section>

      <div className="text-xs text-gray-400 text-center italic pt-6">
        Rhythm is not a tool. It’s a life structure.
      </div>
    </div>
  )
}

export default ExperienceMapPage

