// pages/JournalLogPage.tsx

import React from 'react'
import Section from '../components/ui/Section'
import RhythmMoodMap from '../components/RhythmMoodMap'

interface JournalEntry {
  text: string
  timestamp: number
  trend: 'collapsed' | 'wavy' | 'stable' | 'rising'
}

const JournalLogPage: React.FC = () => {
  const raw = localStorage.getItem('rhythmJournal')
  const entries: JournalEntry[] = raw ? JSON.parse(raw) : []

  const sorted = entries.sort((a, b) => b.timestamp - a.timestamp)

  return (
    <div className="min-h-screen px-6 py-10 max-w-3xl mx-auto space-y-10">
      <h1 className="text-2xl font-bold text-gray-800">📖 Rhythm Journal Log</h1>
      <p className="text-sm text-gray-500">Every entry you’ve written with rhythm.</p>

      {sorted.length === 0 ? (
        <div className="text-sm text-gray-500 italic pt-8">No journal entries yet.</div>
      ) : (
        <div className="space-y-6">
          {sorted.map((entry, i) => (
            <Section
              key={i}
              title={`🪞 ${new Date(entry.timestamp).toLocaleString()} · ${entry.trend.toUpperCase()}`}
            >
              <p className="text-sm text-gray-700 whitespace-pre-wrap">{entry.text}</p>
            </Section>
          ))}
        </div>
      )}
      
      <Section title="📈 Mood Over Time">
  <p className="text-sm text-gray-500 mb-3">
    This chart reflects how your rhythm trend has evolved through your written reflections.
  </p>
  <RhythmMoodMap />
</Section>

    </div>
  )
}

export default JournalLogPage
