// creJourneyPrompt.ts

export function getCREJourneyPrompt(stage: string, trend: string): string {
    const prompts: Record<string, Record<string, string>> = {
      initial: {
        collapsed: "It’s okay to start gently. One breath, one step, that’s enough.",
        wavy: "You’re here. That’s a start. Let’s ease into this together.",
        stable: "Let’s build something small today, and come back again tomorrow.",
        rising: "Great to see you ready — let’s define the first meaningful step.",
      },
      middle: {
        collapsed: "You’ve come this far. We can slow down, not stop.",
        wavy: "Still here? That matters. Let’s keep the rhythm light.",
        stable: "The path is unfolding — one more step and it will feel like flow.",
        rising: "You’re building a rhythm that others will feel. Let’s push one more beat.",
      },
      final: {
        collapsed: "You’re close. And resting is part of finishing.",
        wavy: "Almost there. Let’s finish this gently, not perfectly.",
        stable: "You’re wrapping this up with clarity. Let’s not rush, but let’s complete.",
        rising: "You’re near the crest of this wave. Let’s land it strong.",
      },
      complete: {
        collapsed: "You arrived. Even if it was slow, you didn’t give up.",
        wavy: "This one’s done — beautifully uneven, but complete.",
        stable: "That was a steady journey. Be proud of this closure.",
        rising: "You finished with momentum. This rhythm is real."
      }
    };
  
    return prompts[stage]?.[trend] || "You’re on your own path — let’s take it one step at a time.";
  }
  