// creStyleProfile.ts (with export helpers + UI buttons)

import { RhythmSignatureMap } from './rhythmSignature';
import { getCREStyleUsage, getStyleMigrationTrend } from './creStyleUsage';
import { getCREStyleTimeSeries } from './creStyleTimeline';

export function generateCREStyleProfile(signature: RhythmSignatureMap) {
  const usage = getCREStyleUsage(signature);
  const migration = getStyleMigrationTrend(signature);
  const timeline = getCREStyleTimeSeries();
  const override = localStorage.getItem('creStyleOverride') || 'none';

  return {
    summary: {
      mostUsed: usage.mostUsed,
      mostEffective: usage.mostEffective,
      current: migration.current,
      emerging: migration.emerging,
      override,
      shouldSwitch: migration.shouldSwitch,
      confidence: migration.confidence,
    },
    toneCounts: usage.toneCounts,
    timeline,
    exportedAt: new Date().toISOString(),
  };
}

export function exportProfileAsJson(profile: any) {
  const blob = new Blob([JSON.stringify(profile, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'cre_style_profile.json';
  a.click();
  URL.revokeObjectURL(url);
}

export function exportProfileAsMarkdown(profile: any): string {
  const { summary, toneCounts, timeline, exportedAt } = profile;

  let md = `# CRE Style Profile\n\n`;
  md += `**Exported at:** ${exportedAt}\n\n`;
  md += `## Summary\n`;
  md += `- Most Used: ${summary.mostUsed}\n`;
  md += `- Most Effective: ${summary.mostEffective}\n`;
  md += `- Current Dominant: ${summary.current}\n`;
  if (summary.emerging) md += `- Emerging Style: ${summary.emerging}\n`;
  md += `- Confidence: ${summary.confidence}%\n`;
  md += `- Override: ${summary.override}\n`;

  md += `\n## Style Counts\n`;
  for (const tone in toneCounts) {
    md += `- ${tone}: ${toneCounts[tone]}\n`;
  }

  md += `\n## Timeline\n`;
  timeline.forEach((entry: any) => {
    md += `- ${entry.timestamp}: ${entry.tone} (${entry.score})\n`;
  });

  return md;
}

export function downloadMarkdown(md: string) {
  const blob = new Blob([md], { type: 'text/markdown' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'cre_style_profile.md';
  a.click();
  URL.revokeObjectURL(url);
}
