// creExplanation.ts

export function getCREExplanation({
    tone,
    variant,
    stage,
    taskType,
    override,
    source
  }: {
    tone: string;
    variant: string;
    stage: string;
    taskType: string;
    override?: string;
    source?: 'preset' | 'signature';
  }): string {
    const reasons = [];
  
    if (override && override !== 'skip') {
      reasons.push(`You manually selected the '${tone}' tone as your preferred rhythm.`);
    } else if (source === 'signature') {
      reasons.push(`The '${tone}' tone was selected based on your recent rhythm signature.`);
    }
  
    if (variant !== 'base') {
      reasons.push(`We used the '${variant}' expression style to match your current mental state.`);
    }
  
    if (stage === 'initial') {
      reasons.push(`This is the start of your goal rhythm. We're easing into motion.`);
    } else if (stage === 'middle') {
      reasons.push(`You're mid-rhythm. We're helping you stay consistent.`);
    } else if (stage === 'final') {
      reasons.push(`You're near completion. This tone is here to carry you through.`);
    }
  
    if (taskType === 'minimal') {
      reasons.push(`The task is light to reduce resistance and help you re-enter flow.`);
    } else if (taskType === 'challenge') {
      reasons.push(`This is a challenge task to help you stretch your rhythm.`);
    }
  
    return reasons.join(' ');
  }
  