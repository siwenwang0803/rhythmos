// rhythmGoalGenerator.ts

export function generateRhythmGoalPath(goal: string): { task: string; difficulty: string; intent: string }[] {
    if (!goal || goal.length === 0) return [];
  
    const steps: { task: string; difficulty: string; intent: string }[] = [];
  
    if (goal.toLowerCase().includes('interview')) {
      steps.push(
        { task: 'Clarify interview types for: ' + goal, difficulty: 'minimal', intent: 'define' },
        { task: 'List 3 key concepts to review', difficulty: 'light', intent: 'identify' },
        { task: 'Mock write 3 bullet points for a strong intro', difficulty: 'normal', intent: 'prepare' },
        { task: 'Record a 2-minute intro pitch on camera', difficulty: 'challenge', intent: 'perform' }
      );
    } else if (goal.toLowerCase().includes('resume')) {
      steps.push(
        { task: 'Choose 1 job to tailor resume to', difficulty: 'minimal', intent: 'select' },
        { task: 'Identify 3 key skill keywords to use', difficulty: 'light', intent: 'analyze' },
        { task: 'Rewrite 1 bullet to match job tone', difficulty: 'normal', intent: 'rephrase' },
        { task: 'Format entire resume and save PDF', difficulty: 'challenge', intent: 'finalize' }
      );
    } else {
      steps.push(
        { task: 'Clarify what this goal means to you', difficulty: 'minimal', intent: 'reflect' },
        { task: 'List 2–3 things you’d need to start', difficulty: 'light', intent: 'prepare' },
        { task: 'Do one 10-minute task toward it', difficulty: 'normal', intent: 'initiate' },
        { task: 'Share goal with someone you trust', difficulty: 'challenge', intent: 'declare' }
      );
    }
  
    return steps;
  }
  