// taskUpdater.ts

import { updateRhythmScore } from './rhythmScore';
import { updateRhythmSignature } from './rhythmSignature';
import { getStrategyFromTrend } from './rhythmStrategy';
import { getRhythmTrend, getRecentRhythmLogs, logFeedbackEntry } from './rhythmLog';
import { updateTaskGrowthRecord } from './taskTrajectory';


export function markTaskComplete(
  taskId: string,
  feedback: 'done' | 'tried' | 'skipped',
  taskType: 'minimal' | 'light' | 'normal' | 'challenge',
  tone: string,
  cre: string
) {
  const { score, state } = updateRhythmScore(feedback);
  updateTaskGrowthRecord(feedback);
  updateRhythmSignature(state, tone, feedback, score);

  logFeedbackEntry({
    inputText: taskId,
    feedbackType: feedback,
    score,
    rhythmState: state,
    creStrategyMessage: cre,
    timestamp: new Date().toISOString() // added for tracking time
  });

  return { score, state };
}
export function markSubtaskComplete(subtaskId: string, tone: string, cre: string) {
  return markTaskComplete(subtaskId, 'done', 'minimal', tone, cre);
}

