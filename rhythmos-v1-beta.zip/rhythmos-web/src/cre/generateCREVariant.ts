// cre/generateCRE.ts (restructured to use CRE variant selector)

import { RhythmSignatureMap } from '../rhythmSignature'
import { getCREStylePreference } from '../creStylePreference'
import { generateCREVariant } from './generateCREVariant'
import { CRETone, CREStage, CRETaskType } from './creVariantRegistry'

export function generateCRE({
  trend,
  stage,
  taskType,
  signature,
  override
}: {
  trend: string
  stage: CREStage
  taskType: CRETaskType
  signature: RhythmSignatureMap
  override?: string
}): string {
  const tone: CRETone =
    (override as CRETone) || getCREStylePreference(signature).tone || 'gentle'

  return generateCREVariant({
    tone,
    stage,
    taskType
  })
}

