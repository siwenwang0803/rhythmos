// cre/creVariantRegistry.ts

export type CRETone = 'directive' | 'gentle' | 'motivated' | 'visionary'
export type CREStage = 'initial' | 'middle' | 'final'
export type CRETaskType = 'minimal' | 'light' | 'normal' | 'challenge'

export interface CREVariantSet {
  [tone: string]: {
    [stage in CREStage]?: {
      [type in CRETaskType]?: string[]
    }
  }
}

export const creVariants: CREVariantSet = {
  gentle: {
    initial: {
      minimal: [
        'You’re allowed to begin softly. One breath is enough.',
        'Just pause. That alone counts.',
        'Let the rhythm begin with ease.'
      ],
      light: [
        'A small start is still a start. I’m with you.',
        'Begin gently, no rush.',
        'Let’s ease into it together.'
      ]
    },
    middle: {
      light: [
        'Each step matters. Let’s keep flowing.',
        'Stay soft but steady.',
        'The rhythm doesn’t need to be forced.'
      ]
    },
    final: {
      minimal: [
        'You’ve done enough. Let yourself rest now.',
        'This ending is gentle, and it’s yours.',
        'Let it settle. That’s the final rhythm.'
      ]
    }
  },

  directive: {
    initial: {
      challenge: [
        'Start now. One breath, then move.',
        'No delay. Begin with intent.',
        'Step in. Go hard. Don’t think.'
      ]
    },
    middle: {
      normal: [
        'Push forward—one timer, one task.',
        'No distractions. Continue.',
        'Finish the block. Stay locked in.'
      ]
    },
    final: {
      challenge: [
        'Close it strong. You’ve got this.',
        'No drag. End with force.',
        'Final push. All in.'
      ]
    }
  },

  motivated: {
    initial: {
      light: [
        'Start light. Let it build.',
        'Warm into the motion. It counts.',
        'Get moving gently—then grow.'
      ],
      minimal: [
        'Even a spark can start a fire.',
        'Let’s begin small—but begin.',
        'This one move can change the day.'
      ]
    },
    middle: {
      normal: [
        'Momentum is here. Ride it.',
        'You’re moving. Don’t stop.',
        'Keep going. You’re becoming stronger.'
      ],
      light: [
        'You’ve started. Now give it rhythm.',
        'One step creates another.',
        'Stay in the flow—you’re already in it.'
      ]
    },
    final: {
      normal: [
        'Bring this to a satisfying close.',
        'You’ve carried it—now complete it.',
        'The finish makes it real.'
      ],
      challenge: [
        'Last push. You’re capable.',
        'End strong. You’ll remember this.',
        'You did more than enough—finish it with fire.'
      ]
    }
  },
  visionary: {
    initial: {
      light: [
        'Every beginning echoes into who you become.',
        'This is more than a start—it’s a signal.',
        'You’re not just doing—you’re shaping.'
      ],
      minimal: [
        'Even stillness is motion in the right frame.',
        'A breath can begin a transformation.',
        'This is not small—it’s precise.'
      ]
    },
    middle: {
      normal: [
        'You’re walking the edge of who you were and who you’re becoming.',
        'Keep choosing the shape of your next self.',
        'The rhythm isn’t external. It’s yours now.'
      ],
      challenge: [
        'The path that stretches you is the one that remakes you.',
        'This difficulty is sculpting you.',
        'You’re not repeating—you’re reshaping.'
      ]
    },
    final: {
      normal: [
        'This finish leaves a trace. Make it yours.',
        'You arrived not by chance, but by rhythm.',
        'Endings are just shaped continuations.'
      ],
      challenge: [
        'You complete more than a task—you finish a self-expression.',
        'This closure is legacy rhythm.',
        'You didn’t just do—you created memory.'// Add motivated & visionary...
      ]
    }
}
}
