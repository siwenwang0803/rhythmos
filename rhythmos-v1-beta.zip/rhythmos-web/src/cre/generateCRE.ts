import { RhythmSignatureMap } from '../rhythmSignature'
import { getCREStylePreference } from '../creStylePreference'
import { generateCREVariant } from './generateCREVariant'
import { CRETone, CREStage, CRETaskType, creVariants } from './creVariantRegistry'
import { isToneLocked } from '../logic/rhythmTrendGuard'

export function generateCRE({
  trend,
  stage,
  taskType,
  signature,
  override
}: {
  trend: string
  stage: CREStage
  taskType: CRETaskType
  signature: RhythmSignatureMap
  override?: string
}): string {
  const tone: CRETone =
    (override as CRETone) || getCREStylePreference(signature).tone || 'gentle'

  const key = `${tone}-${stage}-${taskType}`

  // 尝试从评分中获取最优变体
  const raw = localStorage.getItem('creSampleRatings')
  if (raw) {
    const ratings = JSON.parse(raw)
    const filtered = ratings.filter(
      (r: any) =>
        r.tone === tone && r.stage === stage && r.taskType === taskType
    )

    const variantMap: Record<string, number[]> = {}

    filtered.forEach((r: any) => {
      if (!variantMap[r.variant]) variantMap[r.variant] = []
      variantMap[r.variant].push(r.score)
    })

    const scored = Object.entries(variantMap)
      .map(([variant, scores]) => ({
        variant,
        avg: scores.reduce((a, b) => a + b, 0) / scores.length
      }))
      .sort((a, b) => b.avg - a.avg)

    if (scored.length > 0) {
      return scored[0].variant
    }
  }
  const tone: CRETone =
  (isToneLocked(trend) as CRETone) || // ✅ 优先使用 rhythm guard 限制
  (override as CRETone) ||
  getCREStylePreference(signature).tone || 'gentle'


  // fallback → 从语料库随机选一条
  return generateCREVariant({
    tone,
    stage,
    taskType
  })
}
